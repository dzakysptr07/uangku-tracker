import type { Config } from "@netlify/functions";
import storage from "../../src/storage.js";
import pgStorage from "../../src/pg-storage.js";
import analytics from "../../src/analytics.js";

function jsonResponse(status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

function checkPin(ws: { pinHash: string | null }, req: Request, url: URL): boolean {
  if (!ws.pinHash) return true;
  const pin = req.headers.get("x-workspace-pin") || url.searchParams.get("pin") || "";
  return storage.hashPin(pin) === ws.pinHash;
}

async function parseJsonBody(req: Request): Promise<Record<string, unknown>> {
  const raw = await req.text();
  if (!raw) return {};
  if (raw.length > 2 * 1024 * 1024) {
    throw new Error("Payload too large");
  }
  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("Invalid JSON body");
  }
}

export default async (req: Request): Promise<Response> => {
  const url = new URL(req.url);
  const pathname = url.pathname;
  const wsId = storage.sanitizeWorkspaceId(url.searchParams.get("ws") || "pribadi");

  try {
    if (pathname === "/api/health" && req.method === "GET") {
      return jsonResponse(200, {
        ok: true,
        service: "uangku-tracker",
        runtime: "netlify-functions",
        time: new Date().toISOString(),
        lanUrls: [],
      });
    }

    if (pathname === "/api/events" && req.method === "GET") {
      const ws = await pgStorage.readWorkspaceMeta(wsId);
      if (!checkPin(ws, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      // Serverless functions do not hold persistent SSE streams; 204 tells EventSource to stop retrying
      // so the client seamlessly uses 20s Cloud Sync polling.
      return new Response(null, {
        status: 204,
        headers: { "Cache-Control": "no-store" },
      });
    }

    if (pathname === "/api/workspace" && req.method === "GET") {
      const ws = await pgStorage.readWorkspace(wsId);
      if (!checkPin(ws, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const month = url.searchParams.get("month") || "";
      const view = storage.sanitizeClientView(ws) as Record<string, unknown>;
      view.report = analytics.analyzeMonth(ws, month);
      return jsonResponse(200, view);
    }

    if (pathname === "/api/recap" && req.method === "GET") {
      const ws = await pgStorage.readWorkspace(wsId);
      if (!checkPin(ws, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const month = url.searchParams.get("month") || "";
      const format = url.searchParams.get("format") || "json";
      const report = analytics.analyzeMonth(ws, month);
      if (format === "md" || format === "markdown") {
        return new Response(analytics.renderMarkdownRecap(report), {
          status: 200,
          headers: {
            "Content-Type": "text/markdown; charset=utf-8",
            "Cache-Control": "no-store",
          },
        });
      }
      return jsonResponse(200, report);
    }

    if (pathname === "/api/transactions" && req.method === "POST") {
      const wsCheck = await pgStorage.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const body = await parseJsonBody(req);
      const result = await pgStorage.upsertTransaction(wsId, body);
      return jsonResponse(200, {
        ok: true,
        transaction: result.transaction,
        revision: result.workspace.revision,
        updatedAt: result.workspace.updatedAt,
      });
    }

    if (pathname.startsWith("/api/transactions/") && req.method === "DELETE") {
      const wsCheck = await pgStorage.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const txId = decodeURIComponent(pathname.slice("/api/transactions/".length));
      const result = await pgStorage.deleteTransaction(wsId, txId);
      return jsonResponse(200, {
        ok: true,
        deleted: result.deleted,
        revision: result.workspace.revision,
      });
    }

    if (pathname === "/api/sync" && req.method === "POST") {
      const wsCheck = await pgStorage.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const body = await parseJsonBody(req);
      const ws = await pgStorage.syncBatch(wsId, body);
      const month = url.searchParams.get("month") || "";
      const view = storage.sanitizeClientView(ws) as Record<string, unknown>;
      view.report = analytics.analyzeMonth(ws, month);
      return jsonResponse(200, view);
    }

    if (pathname === "/api/settings" && req.method === "POST") {
      const wsCheck = await pgStorage.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const body = await parseJsonBody(req);
      const ws = await pgStorage.updateSettings(wsId, body);
      return jsonResponse(200, storage.sanitizeClientView(ws));
    }

    if (pathname === "/api/demo" && req.method === "POST") {
      const wsCheck = await pgStorage.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const ws = await pgStorage.seedDemoData(wsId);
      const view = storage.sanitizeClientView(ws) as Record<string, unknown>;
      view.report = analytics.analyzeMonth(ws, "");
      return jsonResponse(200, view);
    }

    return jsonResponse(404, { error: "Endpoint tidak ditemukan" });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Bad request";
    return jsonResponse(400, { error: message });
  }
};

export const config: Config = {
  path: "/api/*",
};
