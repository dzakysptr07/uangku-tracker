CREATE TABLE IF NOT EXISTS workspaces (
  workspace_id TEXT PRIMARY KEY,
  revision INTEGER NOT NULL DEFAULT 1,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  target_savings_rate INTEGER NOT NULL DEFAULT 20,
  pin_hash TEXT,
  categories JSONB NOT NULL,
  wallets JSONB NOT NULL,
  budgets JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS transactions (
  workspace_id TEXT NOT NULL REFERENCES workspaces(workspace_id) ON DELETE CASCADE,
  id TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('expense', 'income', 'transfer')),
  amount BIGINT NOT NULL DEFAULT 0,
  category TEXT NOT NULL,
  wallet TEXT NOT NULL,
  to_wallet TEXT,
  tx_date TEXT NOT NULL,
  note TEXT NOT NULL DEFAULT '',
  device TEXT NOT NULL DEFAULT 'web',
  deleted BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (workspace_id, id)
);

CREATE INDEX IF NOT EXISTS idx_transactions_ws_date
  ON transactions (workspace_id, tx_date DESC, created_at DESC);
