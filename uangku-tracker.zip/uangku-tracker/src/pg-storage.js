'use strict';

const { getDatabase } = require('@netlify/database');
const storage = require('./storage');

let dbInstance = null;

function getDb() {
  if (!dbInstance) {
    dbInstance = getDatabase();
  }
  return dbInstance;
}

function mapTxRow(row) {
  return {
    id: row.id,
    type: row.type,
    amount: Number(row.amount) || 0,
    category: row.category,
    wallet: row.wallet,
    toWallet: row.to_wallet || undefined,
    date: row.tx_date,
    note: row.note || '',
    device: row.device || 'web',
    deleted: Boolean(row.deleted),
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

function mapWorkspaceRow(row, transactions) {
  const def = storage.createDefaultWorkspace(row.workspace_id);
  return {
    workspaceId: row.workspace_id,
    revision: Number(row.revision) || 1,
    updatedAt: new Date(row.updated_at).toISOString(),
    targetSavingsRate: Number(row.target_savings_rate) || 20,
    pinHash: row.pin_hash || null,
    categories: Array.isArray(row.categories) && row.categories.length ? row.categories : def.categories,
    wallets: Array.isArray(row.wallets) && row.wallets.length ? row.wallets : def.wallets,
    budgets: row.budgets && typeof row.budgets === 'object' ? row.budgets : {},
    transactions: transactions || []
  };
}

async function ensureWorkspaceRow(client, wsId, lockForUpdate) {
  const cleanId = storage.sanitizeWorkspaceId(wsId);
  const def = storage.createDefaultWorkspace(cleanId);

  await client.query(
    `INSERT INTO workspaces (
      workspace_id, revision, updated_at, target_savings_rate, pin_hash, categories, wallets, budgets
    ) VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8::jsonb)
    ON CONFLICT (workspace_id) DO NOTHING`,
    [
      cleanId,
      def.revision,
      def.updatedAt,
      def.targetSavingsRate,
      def.pinHash,
      JSON.stringify(def.categories),
      JSON.stringify(def.wallets),
      JSON.stringify(def.budgets)
    ]
  );

  const suffix = lockForUpdate ? ' FOR UPDATE' : '';
  const res = await client.query(
    `SELECT workspace_id, revision, updated_at, target_savings_rate, pin_hash, categories, wallets, budgets
     FROM workspaces WHERE workspace_id = $1${suffix}`,
    [cleanId]
  );
  return res.rows[0];
}

async function loadWorkspaceWithClient(client, wsId) {
  const wsRow = await ensureWorkspaceRow(client, wsId, false);
  const txRes = await client.query(
    `SELECT id, type, amount, category, wallet, to_wallet, tx_date, note, device, deleted, created_at, updated_at
     FROM transactions
     WHERE workspace_id = $1
     ORDER BY tx_date DESC, created_at DESC`,
    [wsRow.workspace_id]
  );
  return mapWorkspaceRow(wsRow, txRes.rows.map(mapTxRow));
}

async function withTransaction(fn) {
  const db = getDb();
  const client = await db.pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

async function upsertTxRow(client, wsId, tx) {
  const res = await client.query(
    `INSERT INTO transactions (
      workspace_id, id, type, amount, category, wallet, to_wallet,
      tx_date, note, device, deleted, created_at, updated_at
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
    ON CONFLICT (workspace_id, id) DO UPDATE SET
      type = EXCLUDED.type,
      amount = EXCLUDED.amount,
      category = EXCLUDED.category,
      wallet = EXCLUDED.wallet,
      to_wallet = EXCLUDED.to_wallet,
      tx_date = EXCLUDED.tx_date,
      note = EXCLUDED.note,
      device = EXCLUDED.device,
      deleted = EXCLUDED.deleted,
      updated_at = EXCLUDED.updated_at
    WHERE transactions.updated_at < EXCLUDED.updated_at`,
    [
      wsId,
      tx.id,
      tx.type,
      tx.amount,
      tx.category,
      tx.wallet,
      tx.toWallet || null,
      tx.date,
      tx.note,
      tx.device,
      tx.deleted,
      tx.createdAt,
      tx.updatedAt
    ]
  );
  return res.rowCount > 0;
}

async function readWorkspaceMeta(wsId) {
  const db = getDb();
  const client = await db.pool.connect();
  try {
    const row = await ensureWorkspaceRow(client, wsId, false);
    return mapWorkspaceRow(row, []);
  } finally {
    client.release();
  }
}

async function readWorkspace(wsId) {
  const db = getDb();
  const client = await db.pool.connect();
  try {
    return await loadWorkspaceWithClient(client, wsId);
  } finally {
    client.release();
  }
}

async function upsertTransaction(wsId, txInput) {
  const cleanId = storage.sanitizeWorkspaceId(wsId);
  const nowIso = new Date().toISOString();
  const tx = storage.normalizeTransaction(Object.assign({}, txInput, { updatedAt: nowIso }));

  return withTransaction(async function (client) {
    const wsRow = await ensureWorkspaceRow(client, cleanId, true);
    await upsertTxRow(client, cleanId, tx);
    const nextRev = Number(wsRow.revision) + 1;
    await client.query(
      `UPDATE workspaces SET revision = $2, updated_at = $3 WHERE workspace_id = $1`,
      [cleanId, nextRev, nowIso]
    );
    wsRow.revision = nextRev;
    wsRow.updated_at = nowIso;
    return { workspace: mapWorkspaceRow(wsRow, []), transaction: tx };
  });
}

async function deleteTransaction(wsId, txId) {
  const cleanId = storage.sanitizeWorkspaceId(wsId);
  const nowIso = new Date().toISOString();

  return withTransaction(async function (client) {
    const wsRow = await ensureWorkspaceRow(client, cleanId, true);
    const delRes = await client.query(
      `UPDATE transactions
       SET deleted = TRUE, updated_at = $3
       WHERE workspace_id = $1 AND id = $2 AND deleted = FALSE`,
      [cleanId, txId, nowIso]
    );
    const deleted = delRes.rowCount > 0;
    if (deleted) {
      const nextRev = Number(wsRow.revision) + 1;
      await client.query(
        `UPDATE workspaces SET revision = $2, updated_at = $3 WHERE workspace_id = $1`,
        [cleanId, nextRev, nowIso]
      );
      wsRow.revision = nextRev;
      wsRow.updated_at = nowIso;
    }
    return { workspace: mapWorkspaceRow(wsRow, []), deleted: deleted };
  });
}

async function syncBatch(wsId, payload) {
  const cleanId = storage.sanitizeWorkspaceId(wsId);
  const nowIso = new Date().toISOString();
  const incomingTx = Array.isArray(payload.transactions) ? payload.transactions : [];

  return withTransaction(async function (client) {
    const wsRow = await ensureWorkspaceRow(client, cleanId, true);
    const current = mapWorkspaceRow(wsRow, []);
    let changed = false;

    for (let i = 0; i < incomingTx.length; i++) {
      const norm = storage.normalizeTransaction(incomingTx[i]);
      const updated = await upsertTxRow(client, cleanId, norm);
      if (updated) changed = true;
    }

    let metaChanged = false;
    if (payload.budgets && typeof payload.budgets === 'object') {
      current.budgets = Object.assign({}, current.budgets, payload.budgets);
      metaChanged = true;
    }
    if (payload.targetSavingsRate !== undefined) {
      current.targetSavingsRate = Math.max(1, Math.min(80, Number(payload.targetSavingsRate) || 20));
      metaChanged = true;
    }
    if (Array.isArray(payload.wallets) && payload.wallets.length > 0) {
      current.wallets = payload.wallets;
      metaChanged = true;
    }

    if (changed || metaChanged) {
      const nextRev = current.revision + 1;
      await client.query(
        `UPDATE workspaces
         SET revision = $2, updated_at = $3, target_savings_rate = $4, wallets = $5::jsonb, budgets = $6::jsonb
         WHERE workspace_id = $1`,
        [
          cleanId,
          nextRev,
          nowIso,
          current.targetSavingsRate,
          JSON.stringify(current.wallets),
          JSON.stringify(current.budgets)
        ]
      );
    }

    return loadWorkspaceWithClient(client, cleanId);
  });
}

async function updateSettings(wsId, payload) {
  const cleanId = storage.sanitizeWorkspaceId(wsId);
  const nowIso = new Date().toISOString();

  return withTransaction(async function (client) {
    const wsRow = await ensureWorkspaceRow(client, cleanId, true);
    const current = mapWorkspaceRow(wsRow, []);

    if (payload.budgets && typeof payload.budgets === 'object') {
      const cleanBudgets = {};
      Object.keys(payload.budgets).forEach(function (k) {
        const v = Math.max(0, Math.round(Number(payload.budgets[k]) || 0));
        if (v > 0) cleanBudgets[k] = v;
      });
      current.budgets = cleanBudgets;
    }
    if (payload.targetSavingsRate !== undefined) {
      current.targetSavingsRate = Math.max(1, Math.min(80, Number(payload.targetSavingsRate) || 20));
    }
    if (Array.isArray(payload.wallets) && payload.wallets.length > 0) {
      current.wallets = payload.wallets.map(function (w) {
        return {
          id: String(w.id || 'wallet').slice(0, 32),
          name: String(w.name || 'Dompet').slice(0, 40),
          icon: String(w.icon || '💳').slice(0, 8),
          initialBalance: Number(w.initialBalance) || 0
        };
      });
    }
    if (payload.newPin !== undefined) {
      current.pinHash = payload.newPin ? storage.hashPin(payload.newPin) : null;
    }

    const nextRev = current.revision + 1;
    await client.query(
      `UPDATE workspaces
       SET revision = $2, updated_at = $3, target_savings_rate = $4, pin_hash = $5, wallets = $6::jsonb, budgets = $7::jsonb
       WHERE workspace_id = $1`,
      [
        cleanId,
        nextRev,
        nowIso,
        current.targetSavingsRate,
        current.pinHash,
        JSON.stringify(current.wallets),
        JSON.stringify(current.budgets)
      ]
    );

    return loadWorkspaceWithClient(client, cleanId);
  });
}

async function seedDemoData(wsId, refDate) {
  return syncBatch(wsId, { transactions: storage.buildDemoSamples(refDate) });
}

module.exports = {
  readWorkspaceMeta: readWorkspaceMeta,
  readWorkspace: readWorkspace,
  upsertTransaction: upsertTransaction,
  deleteTransaction: deleteTransaction,
  syncBatch: syncBatch,
  updateSettings: updateSettings,
  seedDemoData: seedDemoData
};
