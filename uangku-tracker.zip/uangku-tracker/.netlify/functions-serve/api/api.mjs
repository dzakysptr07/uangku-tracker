
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __commonJS = (cb, mod) => function __require2() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// src/analytics.js
var require_analytics = __commonJS({
  "src/analytics.js"(exports, module) {
    (function(root, factory) {
      if (typeof module === "object" && module.exports) {
        module.exports = factory();
      } else {
        root.UangKuAnalytics = factory();
      }
    })(typeof globalThis !== "undefined" ? globalThis : exports, function() {
      "use strict";
      const DEFAULT_CATEGORIES = [
        { id: "makan", name: "Makan & Minum", icon: "\u{1F35C}", type: "expense", bucket: "needs", color: "#f97316" },
        { id: "kopi", name: "Kopi & Jajan", icon: "\u2615", type: "expense", bucket: "wants", color: "#eab308" },
        { id: "transport", name: "Transportasi", icon: "\u{1F6F5}", type: "expense", bucket: "needs", color: "#3b82f6" },
        { id: "tagihan", name: "Tagihan & Kos", icon: "\u{1F3E0}", type: "expense", bucket: "needs", color: "#8b5cf6" },
        { id: "belanja", name: "Belanja & Kebutuhan", icon: "\u{1F6D2}", type: "expense", bucket: "needs", color: "#14b8a6" },
        { id: "hiburan", name: "Hiburan & Langganan", icon: "\u{1F3AC}", type: "expense", bucket: "wants", color: "#ec4899" },
        { id: "kesehatan", name: "Kesehatan", icon: "\u{1F48A}", type: "expense", bucket: "needs", color: "#ef4444" },
        { id: "pendidikan", name: "Pendidikan & Buku", icon: "\u{1F4DA}", type: "expense", bucket: "needs", color: "#06b6d4" },
        { id: "tabungan", name: "Tabungan & Investasi", icon: "\u{1F48E}", type: "expense", bucket: "savings", color: "#10b981" },
        { id: "lainnya", name: "Lain-lain", icon: "\u{1F4E6}", type: "expense", bucket: "wants", color: "#64748b" },
        { id: "gaji", name: "Gaji & Utama", icon: "\u{1F4BC}", type: "income", bucket: "income", color: "#22c55e" },
        { id: "bonus", name: "Bonus & Freelance", icon: "\u{1F680}", type: "income", bucket: "income", color: "#0ea5e9" },
        { id: "invest_return", name: "Hasil Investasi", icon: "\u{1F4C8}", type: "income", bucket: "income", color: "#10b981" },
        { id: "masuk_lain", name: "Pemasukan Lain", icon: "\u{1F381}", type: "income", bucket: "income", color: "#84cc16" }
      ];
      const DEFAULT_WALLETS = [
        { id: "tunai", name: "Tunai / Dompet", icon: "\u{1F4B5}", initialBalance: 0 },
        { id: "bank", name: "Rekening Bank", icon: "\u{1F3E6}", initialBalance: 0 },
        { id: "ewallet", name: "E-Wallet / QRIS", icon: "\u{1F4F1}", initialBalance: 0 }
      ];
      function formatIDR(amount) {
        const n = Math.round(Number(amount) || 0);
        const sign = n < 0 ? "-" : "";
        const abs = Math.abs(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
        return sign + "Rp" + abs;
      }
      function toMonthKey(dateStr) {
        if (!dateStr || typeof dateStr !== "string") return "";
        return dateStr.slice(0, 7);
      }
      function getPreviousMonthKey(monthKey) {
        const parts = monthKey.split("-").map(Number);
        if (parts.length !== 2 || !parts[0] || !parts[1]) return "";
        let y = parts[0];
        let m = parts[1] - 1;
        if (m === 0) {
          m = 12;
          y -= 1;
        }
        return String(y) + "-" + String(m).padStart(2, "0");
      }
      function daysInMonth(monthKey) {
        const parts = monthKey.split("-").map(Number);
        if (parts.length !== 2 || !parts[0] || !parts[1]) return 30;
        return new Date(parts[0], parts[1], 0).getDate();
      }
      function buildCategoryMap(categories) {
        const map = {};
        const list = Array.isArray(categories) && categories.length ? categories : DEFAULT_CATEGORIES;
        for (let i = 0; i < list.length; i++) {
          map[list[i].id] = list[i];
        }
        return map;
      }
      function computeWalletBalances(transactions, wallets) {
        const walletList = Array.isArray(wallets) && wallets.length ? wallets : DEFAULT_WALLETS;
        const balances = {};
        for (let i = 0; i < walletList.length; i++) {
          const w = walletList[i];
          balances[w.id] = {
            id: w.id,
            name: w.name,
            icon: w.icon || "\u{1F4B3}",
            balance: Number(w.initialBalance) || 0,
            income: 0,
            expense: 0
          };
        }
        for (let i = 0; i < transactions.length; i++) {
          const tx = transactions[i];
          if (tx.deleted) continue;
          const amt = Number(tx.amount) || 0;
          const wId = tx.wallet || "tunai";
          if (!balances[wId]) {
            balances[wId] = { id: wId, name: wId, icon: "\u{1F4B3}", balance: 0, income: 0, expense: 0 };
          }
          if (tx.type === "income") {
            balances[wId].balance += amt;
            balances[wId].income += amt;
          } else if (tx.type === "expense") {
            balances[wId].balance -= amt;
            balances[wId].expense += amt;
          } else if (tx.type === "transfer") {
            balances[wId].balance -= amt;
            const toW = tx.toWallet || "bank";
            if (!balances[toW]) {
              balances[toW] = { id: toW, name: toW, icon: "\u{1F4B3}", balance: 0, income: 0, expense: 0 };
            }
            balances[toW].balance += amt;
          }
        }
        return Object.keys(balances).map(function(k) {
          return balances[k];
        });
      }
      function analyzeMonth(data, targetMonth, nowDate) {
        const now = nowDate instanceof Date ? nowDate : /* @__PURE__ */ new Date();
        const monthKey = targetMonth || now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0");
        const prevMonthKey = getPreviousMonthKey(monthKey);
        const allTx = (data && Array.isArray(data.transactions) ? data.transactions : []).filter(function(t) {
          return t && !t.deleted;
        });
        const categories = data && Array.isArray(data.categories) && data.categories.length ? data.categories : DEFAULT_CATEGORIES;
        const catMap = buildCategoryMap(categories);
        const budgets = data && data.budgets || {};
        const wallets = data && data.wallets || DEFAULT_WALLETS;
        const monthlyGoalSavingsRate = data && Number(data.targetSavingsRate) || 20;
        const currentTx = allTx.filter(function(t) {
          return toMonthKey(t.date) === monthKey;
        });
        const prevTx = allTx.filter(function(t) {
          return toMonthKey(t.date) === prevMonthKey;
        });
        let totalIncome = 0;
        let totalExpense = 0;
        let totalSavedCategory = 0;
        const categoryTotals = {};
        const walletSpending = {};
        const dailyTotals = {};
        const bucketTotals = { needs: 0, wants: 0, savings: 0 };
        for (let i = 0; i < currentTx.length; i++) {
          const tx = currentTx[i];
          const amt = Number(tx.amount) || 0;
          const day = (tx.date || "").slice(0, 10);
          if (day && !dailyTotals[day]) {
            dailyTotals[day] = { date: day, income: 0, expense: 0 };
          }
          if (tx.type === "income") {
            totalIncome += amt;
            if (day) dailyTotals[day].income += amt;
          } else if (tx.type === "expense") {
            const cat = catMap[tx.category] || { id: tx.category || "lainnya", name: tx.category || "Lainnya", icon: "\u{1F4E6}", bucket: "wants", color: "#64748b" };
            const bucket = cat.bucket || "wants";
            if (bucket === "savings") {
              totalSavedCategory += amt;
              bucketTotals.savings += amt;
            } else {
              totalExpense += amt;
              if (day) dailyTotals[day].expense += amt;
              if (bucket === "needs") bucketTotals.needs += amt;
              else bucketTotals.wants += amt;
            }
            if (!categoryTotals[cat.id]) {
              categoryTotals[cat.id] = {
                id: cat.id,
                name: cat.name,
                icon: cat.icon,
                color: cat.color || "#64748b",
                bucket,
                amount: 0,
                count: 0,
                budget: Number(budgets[cat.id]) || 0
              };
            }
            categoryTotals[cat.id].amount += amt;
            categoryTotals[cat.id].count += 1;
            const wId = tx.wallet || "tunai";
            walletSpending[wId] = (walletSpending[wId] || 0) + amt;
          }
        }
        let prevTotalExpense = 0;
        let prevTotalIncome = 0;
        const prevCategoryTotals = {};
        for (let i = 0; i < prevTx.length; i++) {
          const tx = prevTx[i];
          const amt = Number(tx.amount) || 0;
          if (tx.type === "income") {
            prevTotalIncome += amt;
          } else if (tx.type === "expense") {
            const cat = catMap[tx.category] || { id: tx.category || "lainnya", bucket: "wants" };
            if (cat.bucket !== "savings") {
              prevTotalExpense += amt;
            }
            prevCategoryTotals[cat.id] = (prevCategoryTotals[cat.id] || 0) + amt;
          }
        }
        const totalOutflowWithSavings = totalExpense + totalSavedCategory;
        const netCashflow = totalIncome - totalExpense;
        const effectiveSavings = Math.max(0, netCashflow);
        const savingsRate = totalIncome > 0 ? Math.round(effectiveSavings / totalIncome * 1e3) / 10 : 0;
        const categoryBreakdown = Object.keys(categoryTotals).map(function(id) {
          const item = categoryTotals[id];
          const base = item.bucket === "savings" ? Math.max(totalOutflowWithSavings, 1) : Math.max(totalExpense, 1);
          const prevAmt = prevCategoryTotals[id] || 0;
          const deltaPct = prevAmt > 0 ? Math.round((item.amount - prevAmt) / prevAmt * 100) : null;
          const budgetUsedPct = item.budget > 0 ? Math.round(item.amount / item.budget * 100) : null;
          return Object.assign({}, item, {
            sharePct: item.bucket === "savings" ? 0 : Math.round(item.amount / base * 1e3) / 10,
            prevAmount: prevAmt,
            deltaPct,
            budgetUsedPct
          });
        }).sort(function(a, b) {
          return b.amount - a.amount;
        });
        const expenseCategories = categoryBreakdown.filter(function(c) {
          return c.bucket !== "savings";
        });
        const topExpenses = currentTx.filter(function(t) {
          const c = catMap[t.category];
          return t.type === "expense" && (!c || c.bucket !== "savings");
        }).sort(function(a, b) {
          return (Number(b.amount) || 0) - (Number(a.amount) || 0);
        }).slice(0, 5).map(function(t) {
          const c = catMap[t.category] || { name: t.category || "Lainnya", icon: "\u{1F4E6}" };
          return {
            id: t.id,
            date: t.date,
            note: t.note || c.name,
            categoryName: c.name,
            icon: c.icon,
            amount: Number(t.amount) || 0,
            wallet: t.wallet
          };
        });
        const totalDays = daysInMonth(monthKey);
        const currentMonthKey = now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0");
        let remainingDays = totalDays;
        let elapsedDays = totalDays;
        if (monthKey === currentMonthKey) {
          const today = now.getDate();
          elapsedDays = Math.max(1, today);
          remainingDays = Math.max(1, totalDays - today + 1);
        }
        const totalBudgetCap = Object.keys(budgets).reduce(function(acc, k) {
          const c = catMap[k];
          if (c && c.bucket === "savings") return acc;
          return acc + (Number(budgets[k]) || 0);
        }, 0);
        const targetMonthlySpend = totalIncome > 0 ? Math.round(totalIncome * (1 - monthlyGoalSavingsRate / 100)) : totalBudgetCap > 0 ? totalBudgetCap : totalExpense;
        const remainingSpendRoom = targetMonthlySpend - totalExpense;
        const safeDailySpend = currentTx.length > 0 && remainingSpendRoom > 0 ? Math.floor(remainingSpendRoom / remainingDays) : 0;
        const avgDailySpend = Math.round(totalExpense / Math.max(1, elapsedDays));
        const ratioBase = totalIncome > 0 ? totalIncome : Math.max(1, totalOutflowWithSavings);
        const needsPct = Math.round(bucketTotals.needs / ratioBase * 1e3) / 10;
        const wantsPct = Math.round(bucketTotals.wants / ratioBase * 1e3) / 10;
        const savingsBucketPct = totalIncome > 0 ? Math.max(0, Math.round(effectiveSavings / totalIncome * 1e3) / 10) : Math.round(bucketTotals.savings / ratioBase * 1e3) / 10;
        let healthScore = 50;
        if (currentTx.length === 0) {
          healthScore = 0;
        } else {
          let score = 40;
          if (totalIncome > 0) {
            if (savingsRate >= 20) score += 30;
            else if (savingsRate >= 10) score += 20;
            else if (savingsRate > 0) score += 10;
            else score -= 15;
          }
          if (wantsPct <= 30) score += 15;
          else if (wantsPct <= 40) score += 5;
          else score -= 10;
          const overBudgetCount = expenseCategories.filter(function(c) {
            return c.budget > 0 && c.amount > c.budget;
          }).length;
          if (overBudgetCount === 0) score += 15;
          else score -= Math.min(20, overBudgetCount * 7);
          healthScore = Math.max(0, Math.min(100, Math.round(score)));
        }
        const recommendations = [];
        if (currentTx.length === 0) {
          recommendations.push({
            priority: "info",
            title: "Mulai Catat Transaksi Bulan Ini",
            summary: "Belum ada transaksi tercatat di periode " + monthKey + ". Catat pemasukan dan pengeluaran harianmu agar analisis dan rekomendasi berjalan akurat.",
            action: "Tambahkan pemasukan utama dan minimal 3 transaksi pengeluaran hari ini."
          });
        } else {
          if (totalIncome > 0 && netCashflow < 0) {
            recommendations.push({
              priority: "high",
              title: "Pengeluaran Melebihi Pemasukan (" + formatIDR(Math.abs(netCashflow)) + " Defisit)",
              summary: "Total pengeluaran bulan ini (" + formatIDR(totalExpense) + ") sudah melampaui pemasukan (" + formatIDR(totalIncome) + ").",
              action: "Hentikan sementara pengeluaran kategori Keinginan (wants) dan evaluasi kategori terbesar: " + (expenseCategories[0] ? expenseCategories[0].name : "-") + "."
            });
          } else if (totalIncome > 0 && savingsRate < monthlyGoalSavingsRate) {
            const gap = Math.round(totalIncome * (monthlyGoalSavingsRate / 100) - effectiveSavings);
            recommendations.push({
              priority: "medium",
              title: "Tingkatkan Rasio Tabungan Menuju " + monthlyGoalSavingsRate + "%",
              summary: "Rasio tabungan saat ini " + savingsRate + "% (" + formatIDR(effectiveSavings) + "). Kamu butuh menghemat sekitar " + formatIDR(gap) + " lagi agar mencapai target " + monthlyGoalSavingsRate + "%.",
              action: "Sisihkan tabungan di awal saat menerima gaji (metode Pay Yourself First) sebesar " + formatIDR(Math.round(totalIncome * (monthlyGoalSavingsRate / 100))) + "."
            });
          } else if (totalIncome > 0) {
            recommendations.push({
              priority: "good",
              title: "Arus Kas Sehat \u2014 Rasio Tabungan " + savingsRate + "%",
              summary: "Selamat! Kamu berhasil menyisihkan " + formatIDR(effectiveSavings) + " (" + savingsRate + "% dari pemasukan) bulan ini.",
              action: "Pertahankan batas belanja harian maksimal " + formatIDR(safeDailySpend) + "/hari hingga akhir bulan, dan alokasikan kelebihan ke dana darurat/investasi."
            });
          }
          if (expenseCategories.length > 0 && totalExpense > 0) {
            const topCat = expenseCategories[0];
            if (topCat.sharePct >= 35) {
              const suggestedCut = Math.round(topCat.amount * 0.15);
              recommendations.push({
                priority: "medium",
                title: topCat.icon + " " + topCat.name + " Menyerap " + topCat.sharePct + "% Pengeluaran",
                summary: "Pos pengeluaran terbesar adalah " + topCat.name + " sebesar " + formatIDR(topCat.amount) + " (" + topCat.count + " transaksi).",
                action: "Jika bulan depan kamu memangkas 15% pos ini, kamu bisa berhemat ekstra " + formatIDR(suggestedCut) + "/bulan."
              });
            }
          }
          const overCats = expenseCategories.filter(function(c) {
            return c.budget > 0 && c.amount > c.budget;
          });
          const nearCats = expenseCategories.filter(function(c) {
            return c.budget > 0 && c.amount <= c.budget && c.budgetUsedPct >= 80;
          });
          if (overCats.length > 0) {
            const names = overCats.map(function(c) {
              return c.name + " (" + c.budgetUsedPct + "%)";
            }).join(", ");
            recommendations.push({
              priority: "high",
              title: "Anggaran Terlampaui di " + overCats.length + " Kategori",
              summary: "Kategori yang sudah melewati batas budget bulan ini: " + names + ".",
              action: "Bekukan belanja non-esensial pada kategori tersebut dan revisi batas budget bulan depan agar lebih realistis."
            });
          } else if (nearCats.length > 0) {
            const names = nearCats.map(function(c) {
              return c.name + " (" + c.budgetUsedPct + "%)";
            }).join(", ");
            recommendations.push({
              priority: "medium",
              title: "Mendekati Batas Anggaran",
              summary: "Kategori " + names + " sudah memakai \u226580% anggaran bulanan.",
              action: "Gunakan sisa anggaran secara ketat dengan batas harian " + formatIDR(safeDailySpend) + "/hari."
            });
          }
          if (wantsPct > 30) {
            const excessWants = Math.round(bucketTotals.wants - ratioBase * 0.3);
            recommendations.push({
              priority: "medium",
              title: "Pengeluaran Gaya Hidup (Wants) " + wantsPct + "% (Ideal \u2264 30%)",
              summary: "Total pengeluaran kategori keinginan/gaya hidup mencapai " + formatIDR(bucketTotals.wants) + ".",
              action: "Kurangi sekitar " + formatIDR(excessWants) + " pada pos kopi/jajan, hiburan, atau belanja impulsif bulan depan."
            });
          }
          const smallFrequent = expenseCategories.filter(function(c) {
            return c.count >= 5 && c.amount / c.count <= 75e3 && c.bucket === "wants";
          });
          if (smallFrequent.length > 0) {
            const f = smallFrequent[0];
            const avgTicket = Math.round(f.amount / f.count);
            recommendations.push({
              priority: "info",
              title: "Deteksi Kebiasaan Kecil Berulang: " + f.name,
              summary: "Tercatat " + f.count + " transaksi kecil (rata-rata " + formatIDR(avgTicket) + ") dengan total " + formatIDR(f.amount) + ".",
              action: 'Terapkan aturan "minggu tanpa jajan" 2 hari/minggu untuk memangkas 25% pos ini (' + formatIDR(Math.round(f.amount * 0.25)) + ")."
            });
          }
          const spiked = expenseCategories.filter(function(c) {
            return c.deltaPct !== null && c.deltaPct >= 25 && c.amount >= 1e5;
          });
          if (spiked.length > 0) {
            const s = spiked[0];
            recommendations.push({
              priority: "medium",
              title: "Lonjakan +" + s.deltaPct + "% di " + s.name + " vs Bulan Lalu",
              summary: "Bulan lalu " + formatIDR(s.prevAmount) + ", bulan ini naik menjadi " + formatIDR(s.amount) + ".",
              action: "Cek kembali daftar transaksi " + s.name + " untuk memastikan tidak ada biaya langganan/kebocoran yang terlewat."
            });
          }
          if (totalExpense > 0) {
            const emergencyTarget = totalExpense * 3;
            const monthlySave = effectiveSavings > 0 ? effectiveSavings : Math.round((totalIncome || totalExpense) * 0.15);
            const monthsNeeded = monthlySave > 0 ? Math.ceil(emergencyTarget / monthlySave) : null;
            recommendations.push({
              priority: "info",
              title: "Proyeksi Dana Darurat Minimal (3x Pengeluaran)",
              summary: "Dengan pola pengeluaran " + formatIDR(totalExpense) + "/bulan, target dana darurat awalmu adalah " + formatIDR(emergencyTarget) + ".",
              action: monthsNeeded ? "Dengan tabungan " + formatIDR(monthlySave) + "/bulan, target ini tercapai dalam ~" + monthsNeeded + " bulan." : "Tetapkan target tabungan bulanan agar proyeksi dana darurat dapat dihitung."
            });
          }
        }
        const nextMonthPlan = expenseCategories.map(function(c) {
          let suggested = c.amount;
          let rationale = "Pertahankan sesuai pola bulan ini";
          if (c.bucket === "wants" && (wantsPct > 30 || c.deltaPct !== null && c.deltaPct > 15)) {
            suggested = Math.round(c.amount * 0.85 / 1e4) * 1e4;
            rationale = "Pangkas 15% untuk efisiensi gaya hidup";
          } else if (c.budget > 0 && c.amount > c.budget) {
            suggested = Math.round((c.budget + c.amount) / 2 / 1e4) * 1e4;
            rationale = "Penyesuaian moderat antara budget lama & realisasi";
          } else if (c.budget > 0) {
            suggested = c.budget;
            rationale = "Sesuai anggaran yang sudah ditetapkan";
          }
          return {
            categoryId: c.id,
            name: c.name,
            icon: c.icon,
            currentAmount: c.amount,
            suggestedBudget: Math.max(0, suggested),
            rationale
          };
        });
        const dailySeries = Object.keys(dailyTotals).sort().map(function(d) {
          return dailyTotals[d];
        });
        const walletBalances = computeWalletBalances(allTx, wallets);
        return {
          month: monthKey,
          previousMonth: prevMonthKey,
          summary: {
            totalIncome,
            totalExpense,
            totalSavedCategory,
            netCashflow,
            effectiveSavings,
            savingsRate,
            prevTotalIncome,
            prevTotalExpense,
            expenseDeltaPct: prevTotalExpense > 0 ? Math.round((totalExpense - prevTotalExpense) / prevTotalExpense * 100) : null,
            avgDailySpend,
            safeDailySpend,
            remainingDays,
            transactionCount: currentTx.length,
            healthScore
          },
          rule503020: {
            needsAmount: bucketTotals.needs,
            wantsAmount: bucketTotals.wants,
            savingsAmount: effectiveSavings,
            needsPct,
            wantsPct,
            savingsPct: savingsBucketPct
          },
          categoryBreakdown,
          topExpenses,
          walletSpending,
          walletBalances,
          dailySeries,
          recommendations,
          nextMonthPlan
        };
      }
      function renderMarkdownRecap(report) {
        const s = report.summary;
        const r = report.rule503020;
        const lines = [];
        lines.push("# Rekap & Rekomendasi Keuangan \u2014 " + report.month);
        lines.push("");
        lines.push("## Ringkasan Bulan " + report.month);
        lines.push("- **Total Pemasukan**: " + formatIDR(s.totalIncome));
        lines.push("- **Total Pengeluaran**: " + formatIDR(s.totalExpense) + (s.expenseDeltaPct !== null ? " (" + (s.expenseDeltaPct >= 0 ? "+" : "") + s.expenseDeltaPct + "% vs bulan lalu)" : ""));
        lines.push("- **Sisa Arus Kas / Tabungan Efektif**: " + formatIDR(s.effectiveSavings) + " (" + s.savingsRate + "%)");
        lines.push("- **Rata-rata Belanja Harian**: " + formatIDR(s.avgDailySpend) + "/hari");
        lines.push("- **Batas Aman Belanja Harian (Safe-to-Spend)**: " + formatIDR(s.safeDailySpend) + "/hari (sisa " + s.remainingDays + " hari)");
        lines.push("- **Skor Kesehatan Keuangan**: " + s.healthScore + "/100");
        lines.push("");
        lines.push("## Proporsi 50 / 30 / 20");
        lines.push("- **Kebutuhan (Needs, ideal \u226450%)**: " + r.needsPct + "% (" + formatIDR(r.needsAmount) + ")");
        lines.push("- **Keinginan (Wants, ideal \u226430%)**: " + r.wantsPct + "% (" + formatIDR(r.wantsAmount) + ")");
        lines.push("- **Tabungan (Savings, ideal \u226520%)**: " + r.savingsPct + "% (" + formatIDR(r.savingsAmount) + ")");
        lines.push("");
        lines.push("## Pengeluaran Terbesar per Kategori");
        if (report.categoryBreakdown.length === 0) {
          lines.push("- Belum ada pengeluaran tercatat.");
        } else {
          report.categoryBreakdown.forEach(function(c, idx) {
            const budgetInfo = c.budget > 0 ? " | Budget: " + formatIDR(c.budget) + " (" + c.budgetUsedPct + "%)" : "";
            lines.push(idx + 1 + ". " + c.icon + " **" + c.name + "**: " + formatIDR(c.amount) + " (" + c.sharePct + "%, " + c.count + "x)" + budgetInfo);
          });
        }
        lines.push("");
        lines.push("## Rekomendasi Kedepannya");
        report.recommendations.forEach(function(rec, idx) {
          lines.push(idx + 1 + ". **[" + rec.priority.toUpperCase() + "] " + rec.title + "**");
          lines.push("   - Situasi: " + rec.summary);
          lines.push("   - Langkah: " + rec.action);
        });
        if (report.nextMonthPlan.length > 0) {
          lines.push("");
          lines.push("## Saran Target Budget Bulan Depan");
          report.nextMonthPlan.forEach(function(p) {
            lines.push("- " + p.icon + " **" + p.name + "**: " + formatIDR(p.suggestedBudget) + " (" + p.rationale + ")");
          });
        }
        return lines.join("\n");
      }
      return {
        DEFAULT_CATEGORIES,
        DEFAULT_WALLETS,
        formatIDR,
        analyzeMonth,
        renderMarkdownRecap,
        computeWalletBalances
      };
    });
  }
});

// src/storage.js
var require_storage = __commonJS({
  "src/storage.js"(exports, module) {
    "use strict";
    var fs = __require("fs");
    var path = __require("path");
    var crypto = __require("crypto");
    var analytics2 = require_analytics();
    var DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "..", "data");
    function ensureDataDir() {
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }
    }
    function sanitizeWorkspaceId(wsId) {
      const clean = String(wsId || "pribadi").toLowerCase().replace(/[^a-z0-9_-]/g, "").slice(0, 48);
      return clean || "pribadi";
    }
    function hashPin(pin) {
      if (!pin) return null;
      return crypto.createHash("sha256").update("uangku:" + String(pin)).digest("hex");
    }
    function createDefaultWorkspace(wsId) {
      return {
        workspaceId: sanitizeWorkspaceId(wsId),
        revision: 1,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        targetSavingsRate: 20,
        pinHash: null,
        categories: analytics2.DEFAULT_CATEGORIES,
        wallets: analytics2.DEFAULT_WALLETS,
        budgets: {
          makan: 15e5,
          kopi: 4e5,
          transport: 6e5,
          tagihan: 15e5,
          belanja: 75e4,
          hiburan: 4e5
        },
        transactions: []
      };
    }
    function getWorkspacePath(wsId) {
      ensureDataDir();
      return path.join(DATA_DIR, sanitizeWorkspaceId(wsId) + ".json");
    }
    function readWorkspace(wsId) {
      const cleanId = sanitizeWorkspaceId(wsId);
      const filePath = getWorkspacePath(cleanId);
      if (!fs.existsSync(filePath)) {
        const fresh = createDefaultWorkspace(cleanId);
        writeWorkspaceAtomic(cleanId, fresh);
        return fresh;
      }
      try {
        const raw = fs.readFileSync(filePath, "utf8");
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed.transactions)) parsed.transactions = [];
        if (!Array.isArray(parsed.categories) || !parsed.categories.length) parsed.categories = analytics2.DEFAULT_CATEGORIES;
        if (!Array.isArray(parsed.wallets) || !parsed.wallets.length) parsed.wallets = analytics2.DEFAULT_WALLETS;
        if (!parsed.budgets || typeof parsed.budgets !== "object") parsed.budgets = {};
        if (!parsed.revision) parsed.revision = 1;
        parsed.workspaceId = cleanId;
        return parsed;
      } catch (err) {
        const fallback = createDefaultWorkspace(cleanId);
        return fallback;
      }
    }
    function writeWorkspaceAtomic(wsId, data) {
      const cleanId = sanitizeWorkspaceId(wsId);
      const filePath = getWorkspacePath(cleanId);
      const tmpPath = filePath + "." + process.pid + "." + Date.now() + ".tmp";
      fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), "utf8");
      fs.renameSync(tmpPath, filePath);
    }
    function sanitizeClientView(ws) {
      return {
        workspaceId: ws.workspaceId,
        revision: ws.revision,
        updatedAt: ws.updatedAt,
        hasPin: Boolean(ws.pinHash),
        targetSavingsRate: ws.targetSavingsRate || 20,
        categories: ws.categories,
        wallets: ws.wallets,
        budgets: ws.budgets,
        transactions: ws.transactions.filter(function(t) {
          return !t.deleted;
        }),
        tombstones: ws.transactions.filter(function(t) {
          return t.deleted;
        }).map(function(t) {
          return { id: t.id, updatedAt: t.updatedAt, deleted: true };
        })
      };
    }
    function normalizeTransaction(tx) {
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const id = String(tx.id || "tx_" + crypto.randomUUID()).slice(0, 64);
      const type = ["expense", "income", "transfer"].includes(tx.type) ? tx.type : "expense";
      const amount = Math.max(0, Math.round(Number(tx.amount) || 0));
      const date = typeof tx.date === "string" && /^\d{4}-\d{2}-\d{2}/.test(tx.date) ? tx.date.slice(0, 19) : nowIso.slice(0, 10);
      return {
        id,
        type,
        amount,
        category: String(tx.category || (type === "income" ? "gaji" : "lainnya")).slice(0, 48),
        wallet: String(tx.wallet || "tunai").slice(0, 48),
        toWallet: type === "transfer" ? String(tx.toWallet || "bank").slice(0, 48) : void 0,
        date,
        note: String(tx.note || "").slice(0, 200),
        device: String(tx.device || "web").slice(0, 32),
        deleted: Boolean(tx.deleted),
        createdAt: tx.createdAt || nowIso,
        updatedAt: tx.updatedAt || nowIso
      };
    }
    function mergeTransactions(existing, incoming) {
      const map = /* @__PURE__ */ new Map();
      for (let i = 0; i < existing.length; i++) {
        map.set(existing[i].id, existing[i]);
      }
      let changed = false;
      for (let i = 0; i < incoming.length; i++) {
        const norm = normalizeTransaction(incoming[i]);
        const prev = map.get(norm.id);
        if (!prev || String(norm.updatedAt) > String(prev.updatedAt)) {
          map.set(norm.id, norm);
          changed = true;
        }
      }
      const merged = Array.from(map.values()).sort(function(a, b) {
        if (a.date !== b.date) return a.date < b.date ? 1 : -1;
        return String(a.createdAt) < String(b.createdAt) ? 1 : -1;
      });
      return { merged, changed };
    }
    function upsertTransaction(wsId, txInput) {
      const ws = readWorkspace(wsId);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const tx = normalizeTransaction(Object.assign({}, txInput, { updatedAt: nowIso }));
      const res = mergeTransactions(ws.transactions, [tx]);
      ws.transactions = res.merged;
      ws.revision += 1;
      ws.updatedAt = nowIso;
      writeWorkspaceAtomic(wsId, ws);
      return { workspace: ws, transaction: tx };
    }
    function deleteTransaction(wsId, txId) {
      const ws = readWorkspace(wsId);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const existing = ws.transactions.find(function(t) {
        return t.id === txId;
      });
      if (!existing) return { workspace: ws, deleted: false };
      existing.deleted = true;
      existing.updatedAt = nowIso;
      ws.revision += 1;
      ws.updatedAt = nowIso;
      writeWorkspaceAtomic(wsId, ws);
      return { workspace: ws, deleted: true };
    }
    function syncBatch(wsId, payload) {
      const ws = readWorkspace(wsId);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const incomingTx = Array.isArray(payload.transactions) ? payload.transactions : [];
      const res = mergeTransactions(ws.transactions, incomingTx);
      let metaChanged = false;
      if (payload.budgets && typeof payload.budgets === "object") {
        ws.budgets = Object.assign({}, ws.budgets, payload.budgets);
        metaChanged = true;
      }
      if (payload.targetSavingsRate !== void 0) {
        const rate = Math.max(1, Math.min(80, Number(payload.targetSavingsRate) || 20));
        ws.targetSavingsRate = rate;
        metaChanged = true;
      }
      if (Array.isArray(payload.wallets) && payload.wallets.length > 0) {
        ws.wallets = payload.wallets;
        metaChanged = true;
      }
      if (res.changed || metaChanged) {
        ws.transactions = res.merged;
        ws.revision += 1;
        ws.updatedAt = nowIso;
        writeWorkspaceAtomic(wsId, ws);
      }
      return ws;
    }
    function updateSettings(wsId, payload) {
      const ws = readWorkspace(wsId);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      if (payload.budgets && typeof payload.budgets === "object") {
        const cleanBudgets = {};
        Object.keys(payload.budgets).forEach(function(k) {
          const v = Math.max(0, Math.round(Number(payload.budgets[k]) || 0));
          if (v > 0) cleanBudgets[k] = v;
        });
        ws.budgets = cleanBudgets;
      }
      if (payload.targetSavingsRate !== void 0) {
        ws.targetSavingsRate = Math.max(1, Math.min(80, Number(payload.targetSavingsRate) || 20));
      }
      if (Array.isArray(payload.wallets) && payload.wallets.length > 0) {
        ws.wallets = payload.wallets.map(function(w) {
          return {
            id: String(w.id || "wallet").slice(0, 32),
            name: String(w.name || "Dompet").slice(0, 40),
            icon: String(w.icon || "\u{1F4B3}").slice(0, 8),
            initialBalance: Number(w.initialBalance) || 0
          };
        });
      }
      if (payload.newPin !== void 0) {
        ws.pinHash = payload.newPin ? hashPin(payload.newPin) : null;
      }
      ws.revision += 1;
      ws.updatedAt = nowIso;
      writeWorkspaceAtomic(wsId, ws);
      return ws;
    }
    function buildDemoSamples(refDate) {
      const now = refDate instanceof Date ? refDate : /* @__PURE__ */ new Date();
      const ym = now.getFullYear() + "-" + String(now.getMonth() + 1).padStart(2, "0");
      const prevDate = new Date(now.getFullYear(), now.getMonth() - 1, 15);
      const prevYm = prevDate.getFullYear() + "-" + String(prevDate.getMonth() + 1).padStart(2, "0");
      const day = function(m, d) {
        const maxD = new Date(Number(m.slice(0, 4)), Number(m.slice(5, 7)), 0).getDate();
        const safeD = Math.min(d, maxD);
        return m + "-" + String(safeD).padStart(2, "0");
      };
      return [
        // Previous month baseline for MoM comparison
        { id: "demo_p1", type: "income", amount: 75e5, category: "gaji", wallet: "bank", date: day(prevYm, 1), note: "Gaji Bulanan", device: "desktop" },
        { id: "demo_p2", type: "expense", amount: 14e5, category: "tagihan", wallet: "bank", date: day(prevYm, 3), note: "Kos & Listrik", device: "desktop" },
        { id: "demo_p3", type: "expense", amount: 12e5, category: "makan", wallet: "ewallet", date: day(prevYm, 10), note: "Makan harian & warteg", device: "android" },
        { id: "demo_p4", type: "expense", amount: 32e4, category: "kopi", wallet: "ewallet", date: day(prevYm, 14), note: "Kopi susu & snack", device: "android" },
        { id: "demo_p5", type: "expense", amount: 48e4, category: "transport", wallet: "ewallet", date: day(prevYm, 18), note: "Bensin & ojol", device: "android" },
        { id: "demo_p6", type: "expense", amount: 1e6, category: "tabungan", wallet: "bank", date: day(prevYm, 25), note: "Tabungan reksadana", device: "desktop" },
        // Current month rich data
        { id: "demo_c1", type: "income", amount: 75e5, category: "gaji", wallet: "bank", date: day(ym, 1), note: "Gaji Bulanan", device: "desktop" },
        { id: "demo_c2", type: "income", amount: 95e4, category: "bonus", wallet: "bank", date: day(ym, 8), note: "Project Freelance UI", device: "desktop" },
        { id: "demo_c3", type: "transfer", amount: 15e5, category: "lainnya", wallet: "bank", toWallet: "ewallet", date: day(ym, 2), note: "Top up E-Wallet bulanan", device: "android" },
        { id: "demo_c4", type: "transfer", amount: 5e5, category: "lainnya", wallet: "bank", toWallet: "tunai", date: day(ym, 2), note: "Tarik tunai ATM", device: "android" },
        { id: "demo_c5", type: "expense", amount: 145e4, category: "tagihan", wallet: "bank", date: day(ym, 3), note: "Sewa kos + internet", device: "desktop" },
        { id: "demo_c6", type: "expense", amount: 65e4, category: "belanja", wallet: "ewallet", date: day(ym, 4), note: "Groceries & perlengkapan mandi", device: "android" },
        { id: "demo_c7", type: "expense", amount: 42e4, category: "makan", wallet: "ewallet", date: day(ym, 5), note: "Makan siang kantor minggu 1", device: "android" },
        { id: "demo_c8", type: "expense", amount: 55e3, category: "kopi", wallet: "ewallet", date: day(ym, 6), note: "Kopi susu + roti", device: "android" },
        { id: "demo_c9", type: "expense", amount: 48e3, category: "kopi", wallet: "ewallet", date: day(ym, 8), note: "Es kopi sore", device: "android" },
        { id: "demo_c10", type: "expense", amount: 31e4, category: "transport", wallet: "ewallet", date: day(ym, 9), note: "Ojol & tol minggu 1-2", device: "android" },
        { id: "demo_c11", type: "expense", amount: 185e3, category: "hiburan", wallet: "bank", date: day(ym, 10), note: "Streaming & musik", device: "desktop" },
        { id: "demo_c12", type: "expense", amount: 49e4, category: "makan", wallet: "tunai", date: day(ym, 12), note: "Makan malam & traktir", device: "android" },
        { id: "demo_c13", type: "expense", amount: 65e3, category: "kopi", wallet: "ewallet", date: day(ym, 14), note: "Boba & cemilan", device: "android" },
        { id: "demo_c14", type: "expense", amount: 45e3, category: "kopi", wallet: "ewallet", date: day(ym, 16), note: "Kopi kenangan", device: "android" },
        { id: "demo_c15", type: "expense", amount: 27e4, category: "transport", wallet: "tunai", date: day(ym, 18), note: "Isi bensin & parkir", device: "android" },
        { id: "demo_c16", type: "expense", amount: 38e4, category: "makan", wallet: "ewallet", date: day(ym, 20), note: "Makan siang & pesan antar", device: "android" },
        { id: "demo_c17", type: "expense", amount: 295e3, category: "hiburan", wallet: "ewallet", date: day(ym, 21), note: "Nonton bioskop weekend", device: "android" },
        { id: "demo_c18", type: "expense", amount: 72e3, category: "kopi", wallet: "ewallet", date: day(ym, 23), note: "Matcha latte & pastry", device: "android" },
        { id: "demo_c19", type: "expense", amount: 15e5, category: "tabungan", wallet: "bank", date: day(ym, 24), note: "Autodebit tabungan & RDPU", device: "desktop" }
      ];
    }
    function seedDemoData(wsId, refDate) {
      const ws = syncBatch(wsId, { transactions: buildDemoSamples(refDate) });
      return ws;
    }
    module.exports = {
      DATA_DIR,
      sanitizeWorkspaceId,
      hashPin,
      createDefaultWorkspace,
      normalizeTransaction,
      buildDemoSamples,
      readWorkspace,
      sanitizeClientView,
      upsertTransaction,
      deleteTransaction,
      syncBatch,
      updateSettings,
      seedDemoData
    };
  }
});

// src/pg-storage.js
var require_pg_storage = __commonJS({
  "src/pg-storage.js"(exports, module) {
    "use strict";
    var { getDatabase } = __require("@netlify/database");
    var storage2 = require_storage();
    var dbInstance = null;
    function getDb() {
      if (!dbInstance) {
        dbInstance = getDatabase();
      }
      return dbInstance;
    }
    function mapTxRow(row) {
      return {
        id: row.id,
        type: row.type,
        amount: Number(row.amount) || 0,
        category: row.category,
        wallet: row.wallet,
        toWallet: row.to_wallet || void 0,
        date: row.tx_date,
        note: row.note || "",
        device: row.device || "web",
        deleted: Boolean(row.deleted),
        createdAt: row.created_at,
        updatedAt: row.updated_at
      };
    }
    function mapWorkspaceRow(row, transactions) {
      const def = storage2.createDefaultWorkspace(row.workspace_id);
      return {
        workspaceId: row.workspace_id,
        revision: Number(row.revision) || 1,
        updatedAt: new Date(row.updated_at).toISOString(),
        targetSavingsRate: Number(row.target_savings_rate) || 20,
        pinHash: row.pin_hash || null,
        categories: Array.isArray(row.categories) && row.categories.length ? row.categories : def.categories,
        wallets: Array.isArray(row.wallets) && row.wallets.length ? row.wallets : def.wallets,
        budgets: row.budgets && typeof row.budgets === "object" ? row.budgets : {},
        transactions: transactions || []
      };
    }
    async function ensureWorkspaceRow(client, wsId, lockForUpdate) {
      const cleanId = storage2.sanitizeWorkspaceId(wsId);
      const def = storage2.createDefaultWorkspace(cleanId);
      await client.query(
        `INSERT INTO workspaces (
      workspace_id, revision, updated_at, target_savings_rate, pin_hash, categories, wallets, budgets
    ) VALUES ($1, $2, $3, $4, $5, $6::jsonb, $7::jsonb, $8::jsonb)
    ON CONFLICT (workspace_id) DO NOTHING`,
        [
          cleanId,
          def.revision,
          def.updatedAt,
          def.targetSavingsRate,
          def.pinHash,
          JSON.stringify(def.categories),
          JSON.stringify(def.wallets),
          JSON.stringify(def.budgets)
        ]
      );
      const suffix = lockForUpdate ? " FOR UPDATE" : "";
      const res = await client.query(
        `SELECT workspace_id, revision, updated_at, target_savings_rate, pin_hash, categories, wallets, budgets
     FROM workspaces WHERE workspace_id = $1${suffix}`,
        [cleanId]
      );
      return res.rows[0];
    }
    async function loadWorkspaceWithClient(client, wsId) {
      const wsRow = await ensureWorkspaceRow(client, wsId, false);
      const txRes = await client.query(
        `SELECT id, type, amount, category, wallet, to_wallet, tx_date, note, device, deleted, created_at, updated_at
     FROM transactions
     WHERE workspace_id = $1
     ORDER BY tx_date DESC, created_at DESC`,
        [wsRow.workspace_id]
      );
      return mapWorkspaceRow(wsRow, txRes.rows.map(mapTxRow));
    }
    async function withTransaction(fn) {
      const db = getDb();
      const client = await db.pool.connect();
      try {
        await client.query("BEGIN");
        const result = await fn(client);
        await client.query("COMMIT");
        return result;
      } catch (err) {
        await client.query("ROLLBACK");
        throw err;
      } finally {
        client.release();
      }
    }
    async function upsertTxRow(client, wsId, tx) {
      const res = await client.query(
        `INSERT INTO transactions (
      workspace_id, id, type, amount, category, wallet, to_wallet,
      tx_date, note, device, deleted, created_at, updated_at
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
    ON CONFLICT (workspace_id, id) DO UPDATE SET
      type = EXCLUDED.type,
      amount = EXCLUDED.amount,
      category = EXCLUDED.category,
      wallet = EXCLUDED.wallet,
      to_wallet = EXCLUDED.to_wallet,
      tx_date = EXCLUDED.tx_date,
      note = EXCLUDED.note,
      device = EXCLUDED.device,
      deleted = EXCLUDED.deleted,
      updated_at = EXCLUDED.updated_at
    WHERE transactions.updated_at < EXCLUDED.updated_at`,
        [
          wsId,
          tx.id,
          tx.type,
          tx.amount,
          tx.category,
          tx.wallet,
          tx.toWallet || null,
          tx.date,
          tx.note,
          tx.device,
          tx.deleted,
          tx.createdAt,
          tx.updatedAt
        ]
      );
      return res.rowCount > 0;
    }
    async function readWorkspaceMeta(wsId) {
      const db = getDb();
      const client = await db.pool.connect();
      try {
        const row = await ensureWorkspaceRow(client, wsId, false);
        return mapWorkspaceRow(row, []);
      } finally {
        client.release();
      }
    }
    async function readWorkspace(wsId) {
      const db = getDb();
      const client = await db.pool.connect();
      try {
        return await loadWorkspaceWithClient(client, wsId);
      } finally {
        client.release();
      }
    }
    async function upsertTransaction(wsId, txInput) {
      const cleanId = storage2.sanitizeWorkspaceId(wsId);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const tx = storage2.normalizeTransaction(Object.assign({}, txInput, { updatedAt: nowIso }));
      return withTransaction(async function(client) {
        const wsRow = await ensureWorkspaceRow(client, cleanId, true);
        await upsertTxRow(client, cleanId, tx);
        const nextRev = Number(wsRow.revision) + 1;
        await client.query(
          `UPDATE workspaces SET revision = $2, updated_at = $3 WHERE workspace_id = $1`,
          [cleanId, nextRev, nowIso]
        );
        wsRow.revision = nextRev;
        wsRow.updated_at = nowIso;
        return { workspace: mapWorkspaceRow(wsRow, []), transaction: tx };
      });
    }
    async function deleteTransaction(wsId, txId) {
      const cleanId = storage2.sanitizeWorkspaceId(wsId);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      return withTransaction(async function(client) {
        const wsRow = await ensureWorkspaceRow(client, cleanId, true);
        const delRes = await client.query(
          `UPDATE transactions
       SET deleted = TRUE, updated_at = $3
       WHERE workspace_id = $1 AND id = $2 AND deleted = FALSE`,
          [cleanId, txId, nowIso]
        );
        const deleted = delRes.rowCount > 0;
        if (deleted) {
          const nextRev = Number(wsRow.revision) + 1;
          await client.query(
            `UPDATE workspaces SET revision = $2, updated_at = $3 WHERE workspace_id = $1`,
            [cleanId, nextRev, nowIso]
          );
          wsRow.revision = nextRev;
          wsRow.updated_at = nowIso;
        }
        return { workspace: mapWorkspaceRow(wsRow, []), deleted };
      });
    }
    async function syncBatch(wsId, payload) {
      const cleanId = storage2.sanitizeWorkspaceId(wsId);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      const incomingTx = Array.isArray(payload.transactions) ? payload.transactions : [];
      return withTransaction(async function(client) {
        const wsRow = await ensureWorkspaceRow(client, cleanId, true);
        const current = mapWorkspaceRow(wsRow, []);
        let changed = false;
        for (let i = 0; i < incomingTx.length; i++) {
          const norm = storage2.normalizeTransaction(incomingTx[i]);
          const updated = await upsertTxRow(client, cleanId, norm);
          if (updated) changed = true;
        }
        let metaChanged = false;
        if (payload.budgets && typeof payload.budgets === "object") {
          current.budgets = Object.assign({}, current.budgets, payload.budgets);
          metaChanged = true;
        }
        if (payload.targetSavingsRate !== void 0) {
          current.targetSavingsRate = Math.max(1, Math.min(80, Number(payload.targetSavingsRate) || 20));
          metaChanged = true;
        }
        if (Array.isArray(payload.wallets) && payload.wallets.length > 0) {
          current.wallets = payload.wallets;
          metaChanged = true;
        }
        if (changed || metaChanged) {
          const nextRev = current.revision + 1;
          await client.query(
            `UPDATE workspaces
         SET revision = $2, updated_at = $3, target_savings_rate = $4, wallets = $5::jsonb, budgets = $6::jsonb
         WHERE workspace_id = $1`,
            [
              cleanId,
              nextRev,
              nowIso,
              current.targetSavingsRate,
              JSON.stringify(current.wallets),
              JSON.stringify(current.budgets)
            ]
          );
        }
        return loadWorkspaceWithClient(client, cleanId);
      });
    }
    async function updateSettings(wsId, payload) {
      const cleanId = storage2.sanitizeWorkspaceId(wsId);
      const nowIso = (/* @__PURE__ */ new Date()).toISOString();
      return withTransaction(async function(client) {
        const wsRow = await ensureWorkspaceRow(client, cleanId, true);
        const current = mapWorkspaceRow(wsRow, []);
        if (payload.budgets && typeof payload.budgets === "object") {
          const cleanBudgets = {};
          Object.keys(payload.budgets).forEach(function(k) {
            const v = Math.max(0, Math.round(Number(payload.budgets[k]) || 0));
            if (v > 0) cleanBudgets[k] = v;
          });
          current.budgets = cleanBudgets;
        }
        if (payload.targetSavingsRate !== void 0) {
          current.targetSavingsRate = Math.max(1, Math.min(80, Number(payload.targetSavingsRate) || 20));
        }
        if (Array.isArray(payload.wallets) && payload.wallets.length > 0) {
          current.wallets = payload.wallets.map(function(w) {
            return {
              id: String(w.id || "wallet").slice(0, 32),
              name: String(w.name || "Dompet").slice(0, 40),
              icon: String(w.icon || "\u{1F4B3}").slice(0, 8),
              initialBalance: Number(w.initialBalance) || 0
            };
          });
        }
        if (payload.newPin !== void 0) {
          current.pinHash = payload.newPin ? storage2.hashPin(payload.newPin) : null;
        }
        const nextRev = current.revision + 1;
        await client.query(
          `UPDATE workspaces
       SET revision = $2, updated_at = $3, target_savings_rate = $4, pin_hash = $5, wallets = $6::jsonb, budgets = $7::jsonb
       WHERE workspace_id = $1`,
          [
            cleanId,
            nextRev,
            nowIso,
            current.targetSavingsRate,
            current.pinHash,
            JSON.stringify(current.wallets),
            JSON.stringify(current.budgets)
          ]
        );
        return loadWorkspaceWithClient(client, cleanId);
      });
    }
    async function seedDemoData(wsId, refDate) {
      return syncBatch(wsId, { transactions: storage2.buildDemoSamples(refDate) });
    }
    module.exports = {
      readWorkspaceMeta,
      readWorkspace,
      upsertTransaction,
      deleteTransaction,
      syncBatch,
      updateSettings,
      seedDemoData
    };
  }
});

// netlify/functions/api.mts
var import_storage = __toESM(require_storage(), 1);
var import_pg_storage = __toESM(require_pg_storage(), 1);
var import_analytics = __toESM(require_analytics(), 1);
function jsonResponse(status, body) {
  return new Response(JSON.stringify(body), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store"
    }
  });
}
function checkPin(ws, req, url) {
  if (!ws.pinHash) return true;
  const pin = req.headers.get("x-workspace-pin") || url.searchParams.get("pin") || "";
  return import_storage.default.hashPin(pin) === ws.pinHash;
}
async function parseJsonBody(req) {
  const raw = await req.text();
  if (!raw) return {};
  if (raw.length > 2 * 1024 * 1024) {
    throw new Error("Payload too large");
  }
  try {
    return JSON.parse(raw);
  } catch {
    throw new Error("Invalid JSON body");
  }
}
var api_default = async (req) => {
  const url = new URL(req.url);
  const pathname = url.pathname;
  const wsId = import_storage.default.sanitizeWorkspaceId(url.searchParams.get("ws") || "pribadi");
  try {
    if (pathname === "/api/health" && req.method === "GET") {
      return jsonResponse(200, {
        ok: true,
        service: "uangku-tracker",
        runtime: "netlify-functions",
        time: (/* @__PURE__ */ new Date()).toISOString(),
        lanUrls: []
      });
    }
    if (pathname === "/api/events" && req.method === "GET") {
      const ws = await import_pg_storage.default.readWorkspaceMeta(wsId);
      if (!checkPin(ws, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      return new Response(null, {
        status: 204,
        headers: { "Cache-Control": "no-store" }
      });
    }
    if (pathname === "/api/workspace" && req.method === "GET") {
      const ws = await import_pg_storage.default.readWorkspace(wsId);
      if (!checkPin(ws, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const month = url.searchParams.get("month") || "";
      const view = import_storage.default.sanitizeClientView(ws);
      view.report = import_analytics.default.analyzeMonth(ws, month);
      return jsonResponse(200, view);
    }
    if (pathname === "/api/recap" && req.method === "GET") {
      const ws = await import_pg_storage.default.readWorkspace(wsId);
      if (!checkPin(ws, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const month = url.searchParams.get("month") || "";
      const format = url.searchParams.get("format") || "json";
      const report = import_analytics.default.analyzeMonth(ws, month);
      if (format === "md" || format === "markdown") {
        return new Response(import_analytics.default.renderMarkdownRecap(report), {
          status: 200,
          headers: {
            "Content-Type": "text/markdown; charset=utf-8",
            "Cache-Control": "no-store"
          }
        });
      }
      return jsonResponse(200, report);
    }
    if (pathname === "/api/transactions" && req.method === "POST") {
      const wsCheck = await import_pg_storage.default.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const body = await parseJsonBody(req);
      const result = await import_pg_storage.default.upsertTransaction(wsId, body);
      return jsonResponse(200, {
        ok: true,
        transaction: result.transaction,
        revision: result.workspace.revision,
        updatedAt: result.workspace.updatedAt
      });
    }
    if (pathname.startsWith("/api/transactions/") && req.method === "DELETE") {
      const wsCheck = await import_pg_storage.default.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const txId = decodeURIComponent(pathname.slice("/api/transactions/".length));
      const result = await import_pg_storage.default.deleteTransaction(wsId, txId);
      return jsonResponse(200, {
        ok: true,
        deleted: result.deleted,
        revision: result.workspace.revision
      });
    }
    if (pathname === "/api/sync" && req.method === "POST") {
      const wsCheck = await import_pg_storage.default.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const body = await parseJsonBody(req);
      const ws = await import_pg_storage.default.syncBatch(wsId, body);
      const month = url.searchParams.get("month") || "";
      const view = import_storage.default.sanitizeClientView(ws);
      view.report = import_analytics.default.analyzeMonth(ws, month);
      return jsonResponse(200, view);
    }
    if (pathname === "/api/settings" && req.method === "POST") {
      const wsCheck = await import_pg_storage.default.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const body = await parseJsonBody(req);
      const ws = await import_pg_storage.default.updateSettings(wsId, body);
      return jsonResponse(200, import_storage.default.sanitizeClientView(ws));
    }
    if (pathname === "/api/demo" && req.method === "POST") {
      const wsCheck = await import_pg_storage.default.readWorkspaceMeta(wsId);
      if (!checkPin(wsCheck, req, url)) {
        return jsonResponse(401, { error: "PIN workspace salah atau diperlukan", requiresPin: true });
      }
      const ws = await import_pg_storage.default.seedDemoData(wsId);
      const view = import_storage.default.sanitizeClientView(ws);
      view.report = import_analytics.default.analyzeMonth(ws, "");
      return jsonResponse(200, view);
    }
    return jsonResponse(404, { error: "Endpoint tidak ditemukan" });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Bad request";
    return jsonResponse(400, { error: message });
  }
};
var config = {
  path: "/api/*"
};
export {
  config,
  api_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL2FuYWx5dGljcy5qcyIsICJzcmMvc3RvcmFnZS5qcyIsICJzcmMvcGctc3RvcmFnZS5qcyIsICJuZXRsaWZ5L2Z1bmN0aW9ucy9hcGkubXRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIoZnVuY3Rpb24gKHJvb3QsIGZhY3RvcnkpIHtcbiAgaWYgKHR5cGVvZiBtb2R1bGUgPT09ICdvYmplY3QnICYmIG1vZHVsZS5leHBvcnRzKSB7XG4gICAgbW9kdWxlLmV4cG9ydHMgPSBmYWN0b3J5KCk7XG4gIH0gZWxzZSB7XG4gICAgcm9vdC5VYW5nS3VBbmFseXRpY3MgPSBmYWN0b3J5KCk7XG4gIH1cbn0pKHR5cGVvZiBnbG9iYWxUaGlzICE9PSAndW5kZWZpbmVkJyA/IGdsb2JhbFRoaXMgOiB0aGlzLCBmdW5jdGlvbiAoKSB7XG4gICd1c2Ugc3RyaWN0JztcblxuICBjb25zdCBERUZBVUxUX0NBVEVHT1JJRVMgPSBbXG4gICAgeyBpZDogJ21ha2FuJywgbmFtZTogJ01ha2FuICYgTWludW0nLCBpY29uOiAnXHVEODNDXHVERjVDJywgdHlwZTogJ2V4cGVuc2UnLCBidWNrZXQ6ICduZWVkcycsIGNvbG9yOiAnI2Y5NzMxNicgfSxcbiAgICB7IGlkOiAna29waScsIG5hbWU6ICdLb3BpICYgSmFqYW4nLCBpY29uOiAnXHUyNjE1JywgdHlwZTogJ2V4cGVuc2UnLCBidWNrZXQ6ICd3YW50cycsIGNvbG9yOiAnI2VhYjMwOCcgfSxcbiAgICB7IGlkOiAndHJhbnNwb3J0JywgbmFtZTogJ1RyYW5zcG9ydGFzaScsIGljb246ICdcdUQ4M0RcdURFRjUnLCB0eXBlOiAnZXhwZW5zZScsIGJ1Y2tldDogJ25lZWRzJywgY29sb3I6ICcjM2I4MmY2JyB9LFxuICAgIHsgaWQ6ICd0YWdpaGFuJywgbmFtZTogJ1RhZ2loYW4gJiBLb3MnLCBpY29uOiAnXHVEODNDXHVERkUwJywgdHlwZTogJ2V4cGVuc2UnLCBidWNrZXQ6ICduZWVkcycsIGNvbG9yOiAnIzhiNWNmNicgfSxcbiAgICB7IGlkOiAnYmVsYW5qYScsIG5hbWU6ICdCZWxhbmphICYgS2VidXR1aGFuJywgaWNvbjogJ1x1RDgzRFx1REVEMicsIHR5cGU6ICdleHBlbnNlJywgYnVja2V0OiAnbmVlZHMnLCBjb2xvcjogJyMxNGI4YTYnIH0sXG4gICAgeyBpZDogJ2hpYnVyYW4nLCBuYW1lOiAnSGlidXJhbiAmIExhbmdnYW5hbicsIGljb246ICdcdUQ4M0NcdURGQUMnLCB0eXBlOiAnZXhwZW5zZScsIGJ1Y2tldDogJ3dhbnRzJywgY29sb3I6ICcjZWM0ODk5JyB9LFxuICAgIHsgaWQ6ICdrZXNlaGF0YW4nLCBuYW1lOiAnS2VzZWhhdGFuJywgaWNvbjogJ1x1RDgzRFx1REM4QScsIHR5cGU6ICdleHBlbnNlJywgYnVja2V0OiAnbmVlZHMnLCBjb2xvcjogJyNlZjQ0NDQnIH0sXG4gICAgeyBpZDogJ3BlbmRpZGlrYW4nLCBuYW1lOiAnUGVuZGlkaWthbiAmIEJ1a3UnLCBpY29uOiAnXHVEODNEXHVEQ0RBJywgdHlwZTogJ2V4cGVuc2UnLCBidWNrZXQ6ICduZWVkcycsIGNvbG9yOiAnIzA2YjZkNCcgfSxcbiAgICB7IGlkOiAndGFidW5nYW4nLCBuYW1lOiAnVGFidW5nYW4gJiBJbnZlc3Rhc2knLCBpY29uOiAnXHVEODNEXHVEQzhFJywgdHlwZTogJ2V4cGVuc2UnLCBidWNrZXQ6ICdzYXZpbmdzJywgY29sb3I6ICcjMTBiOTgxJyB9LFxuICAgIHsgaWQ6ICdsYWlubnlhJywgbmFtZTogJ0xhaW4tbGFpbicsIGljb246ICdcdUQ4M0RcdURDRTYnLCB0eXBlOiAnZXhwZW5zZScsIGJ1Y2tldDogJ3dhbnRzJywgY29sb3I6ICcjNjQ3NDhiJyB9LFxuICAgIHsgaWQ6ICdnYWppJywgbmFtZTogJ0dhamkgJiBVdGFtYScsIGljb246ICdcdUQ4M0RcdURDQkMnLCB0eXBlOiAnaW5jb21lJywgYnVja2V0OiAnaW5jb21lJywgY29sb3I6ICcjMjJjNTVlJyB9LFxuICAgIHsgaWQ6ICdib251cycsIG5hbWU6ICdCb251cyAmIEZyZWVsYW5jZScsIGljb246ICdcdUQ4M0RcdURFODAnLCB0eXBlOiAnaW5jb21lJywgYnVja2V0OiAnaW5jb21lJywgY29sb3I6ICcjMGVhNWU5JyB9LFxuICAgIHsgaWQ6ICdpbnZlc3RfcmV0dXJuJywgbmFtZTogJ0hhc2lsIEludmVzdGFzaScsIGljb246ICdcdUQ4M0RcdURDQzgnLCB0eXBlOiAnaW5jb21lJywgYnVja2V0OiAnaW5jb21lJywgY29sb3I6ICcjMTBiOTgxJyB9LFxuICAgIHsgaWQ6ICdtYXN1a19sYWluJywgbmFtZTogJ1BlbWFzdWthbiBMYWluJywgaWNvbjogJ1x1RDgzQ1x1REY4MScsIHR5cGU6ICdpbmNvbWUnLCBidWNrZXQ6ICdpbmNvbWUnLCBjb2xvcjogJyM4NGNjMTYnIH1cbiAgXTtcblxuICBjb25zdCBERUZBVUxUX1dBTExFVFMgPSBbXG4gICAgeyBpZDogJ3R1bmFpJywgbmFtZTogJ1R1bmFpIC8gRG9tcGV0JywgaWNvbjogJ1x1RDgzRFx1RENCNScsIGluaXRpYWxCYWxhbmNlOiAwIH0sXG4gICAgeyBpZDogJ2JhbmsnLCBuYW1lOiAnUmVrZW5pbmcgQmFuaycsIGljb246ICdcdUQ4M0NcdURGRTYnLCBpbml0aWFsQmFsYW5jZTogMCB9LFxuICAgIHsgaWQ6ICdld2FsbGV0JywgbmFtZTogJ0UtV2FsbGV0IC8gUVJJUycsIGljb246ICdcdUQ4M0RcdURDRjEnLCBpbml0aWFsQmFsYW5jZTogMCB9XG4gIF07XG5cbiAgZnVuY3Rpb24gZm9ybWF0SURSKGFtb3VudCkge1xuICAgIGNvbnN0IG4gPSBNYXRoLnJvdW5kKE51bWJlcihhbW91bnQpIHx8IDApO1xuICAgIGNvbnN0IHNpZ24gPSBuIDwgMCA/ICctJyA6ICcnO1xuICAgIGNvbnN0IGFicyA9IE1hdGguYWJzKG4pLnRvU3RyaW5nKCkucmVwbGFjZSgvXFxCKD89KFxcZHszfSkrKD8hXFxkKSkvZywgJy4nKTtcbiAgICByZXR1cm4gc2lnbiArICdScCcgKyBhYnM7XG4gIH1cblxuICBmdW5jdGlvbiB0b01vbnRoS2V5KGRhdGVTdHIpIHtcbiAgICBpZiAoIWRhdGVTdHIgfHwgdHlwZW9mIGRhdGVTdHIgIT09ICdzdHJpbmcnKSByZXR1cm4gJyc7XG4gICAgcmV0dXJuIGRhdGVTdHIuc2xpY2UoMCwgNyk7XG4gIH1cblxuICBmdW5jdGlvbiBnZXRQcmV2aW91c01vbnRoS2V5KG1vbnRoS2V5KSB7XG4gICAgY29uc3QgcGFydHMgPSBtb250aEtleS5zcGxpdCgnLScpLm1hcChOdW1iZXIpO1xuICAgIGlmIChwYXJ0cy5sZW5ndGggIT09IDIgfHwgIXBhcnRzWzBdIHx8ICFwYXJ0c1sxXSkgcmV0dXJuICcnO1xuICAgIGxldCB5ID0gcGFydHNbMF07XG4gICAgbGV0IG0gPSBwYXJ0c1sxXSAtIDE7XG4gICAgaWYgKG0gPT09IDApIHtcbiAgICAgIG0gPSAxMjtcbiAgICAgIHkgLT0gMTtcbiAgICB9XG4gICAgcmV0dXJuIFN0cmluZyh5KSArICctJyArIFN0cmluZyhtKS5wYWRTdGFydCgyLCAnMCcpO1xuICB9XG5cbiAgZnVuY3Rpb24gZGF5c0luTW9udGgobW9udGhLZXkpIHtcbiAgICBjb25zdCBwYXJ0cyA9IG1vbnRoS2V5LnNwbGl0KCctJykubWFwKE51bWJlcik7XG4gICAgaWYgKHBhcnRzLmxlbmd0aCAhPT0gMiB8fCAhcGFydHNbMF0gfHwgIXBhcnRzWzFdKSByZXR1cm4gMzA7XG4gICAgcmV0dXJuIG5ldyBEYXRlKHBhcnRzWzBdLCBwYXJ0c1sxXSwgMCkuZ2V0RGF0ZSgpO1xuICB9XG5cbiAgZnVuY3Rpb24gYnVpbGRDYXRlZ29yeU1hcChjYXRlZ29yaWVzKSB7XG4gICAgY29uc3QgbWFwID0ge307XG4gICAgY29uc3QgbGlzdCA9IEFycmF5LmlzQXJyYXkoY2F0ZWdvcmllcykgJiYgY2F0ZWdvcmllcy5sZW5ndGggPyBjYXRlZ29yaWVzIDogREVGQVVMVF9DQVRFR09SSUVTO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbGlzdC5sZW5ndGg7IGkrKykge1xuICAgICAgbWFwW2xpc3RbaV0uaWRdID0gbGlzdFtpXTtcbiAgICB9XG4gICAgcmV0dXJuIG1hcDtcbiAgfVxuXG4gIGZ1bmN0aW9uIGNvbXB1dGVXYWxsZXRCYWxhbmNlcyh0cmFuc2FjdGlvbnMsIHdhbGxldHMpIHtcbiAgICBjb25zdCB3YWxsZXRMaXN0ID0gQXJyYXkuaXNBcnJheSh3YWxsZXRzKSAmJiB3YWxsZXRzLmxlbmd0aCA/IHdhbGxldHMgOiBERUZBVUxUX1dBTExFVFM7XG4gICAgY29uc3QgYmFsYW5jZXMgPSB7fTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHdhbGxldExpc3QubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IHcgPSB3YWxsZXRMaXN0W2ldO1xuICAgICAgYmFsYW5jZXNbdy5pZF0gPSB7XG4gICAgICAgIGlkOiB3LmlkLFxuICAgICAgICBuYW1lOiB3Lm5hbWUsXG4gICAgICAgIGljb246IHcuaWNvbiB8fCAnXHVEODNEXHVEQ0IzJyxcbiAgICAgICAgYmFsYW5jZTogTnVtYmVyKHcuaW5pdGlhbEJhbGFuY2UpIHx8IDAsXG4gICAgICAgIGluY29tZTogMCxcbiAgICAgICAgZXhwZW5zZTogMFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRyYW5zYWN0aW9ucy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgdHggPSB0cmFuc2FjdGlvbnNbaV07XG4gICAgICBpZiAodHguZGVsZXRlZCkgY29udGludWU7XG4gICAgICBjb25zdCBhbXQgPSBOdW1iZXIodHguYW1vdW50KSB8fCAwO1xuICAgICAgY29uc3Qgd0lkID0gdHgud2FsbGV0IHx8ICd0dW5haSc7XG4gICAgICBpZiAoIWJhbGFuY2VzW3dJZF0pIHtcbiAgICAgICAgYmFsYW5jZXNbd0lkXSA9IHsgaWQ6IHdJZCwgbmFtZTogd0lkLCBpY29uOiAnXHVEODNEXHVEQ0IzJywgYmFsYW5jZTogMCwgaW5jb21lOiAwLCBleHBlbnNlOiAwIH07XG4gICAgICB9XG4gICAgICBpZiAodHgudHlwZSA9PT0gJ2luY29tZScpIHtcbiAgICAgICAgYmFsYW5jZXNbd0lkXS5iYWxhbmNlICs9IGFtdDtcbiAgICAgICAgYmFsYW5jZXNbd0lkXS5pbmNvbWUgKz0gYW10O1xuICAgICAgfSBlbHNlIGlmICh0eC50eXBlID09PSAnZXhwZW5zZScpIHtcbiAgICAgICAgYmFsYW5jZXNbd0lkXS5iYWxhbmNlIC09IGFtdDtcbiAgICAgICAgYmFsYW5jZXNbd0lkXS5leHBlbnNlICs9IGFtdDtcbiAgICAgIH0gZWxzZSBpZiAodHgudHlwZSA9PT0gJ3RyYW5zZmVyJykge1xuICAgICAgICBiYWxhbmNlc1t3SWRdLmJhbGFuY2UgLT0gYW10O1xuICAgICAgICBjb25zdCB0b1cgPSB0eC50b1dhbGxldCB8fCAnYmFuayc7XG4gICAgICAgIGlmICghYmFsYW5jZXNbdG9XXSkge1xuICAgICAgICAgIGJhbGFuY2VzW3RvV10gPSB7IGlkOiB0b1csIG5hbWU6IHRvVywgaWNvbjogJ1x1RDgzRFx1RENCMycsIGJhbGFuY2U6IDAsIGluY29tZTogMCwgZXhwZW5zZTogMCB9O1xuICAgICAgICB9XG4gICAgICAgIGJhbGFuY2VzW3RvV10uYmFsYW5jZSArPSBhbXQ7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKGJhbGFuY2VzKS5tYXAoZnVuY3Rpb24gKGspIHsgcmV0dXJuIGJhbGFuY2VzW2tdOyB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZW5lcmF0ZXMgYSBjb21wbGV0ZSBmaW5hbmNpYWwgcmVjYXAgJiBmdXR1cmUgcmVjb21tZW5kYXRpb25zIGZvciBhIHRhcmdldCBtb250aCAoWVlZWS1NTSkuXG4gICAqL1xuICBmdW5jdGlvbiBhbmFseXplTW9udGgoZGF0YSwgdGFyZ2V0TW9udGgsIG5vd0RhdGUpIHtcbiAgICBjb25zdCBub3cgPSBub3dEYXRlIGluc3RhbmNlb2YgRGF0ZSA/IG5vd0RhdGUgOiBuZXcgRGF0ZSgpO1xuICAgIGNvbnN0IG1vbnRoS2V5ID0gdGFyZ2V0TW9udGggfHwgKG5vdy5nZXRGdWxsWWVhcigpICsgJy0nICsgU3RyaW5nKG5vdy5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgJzAnKSk7XG4gICAgY29uc3QgcHJldk1vbnRoS2V5ID0gZ2V0UHJldmlvdXNNb250aEtleShtb250aEtleSk7XG5cbiAgICBjb25zdCBhbGxUeCA9IChkYXRhICYmIEFycmF5LmlzQXJyYXkoZGF0YS50cmFuc2FjdGlvbnMpID8gZGF0YS50cmFuc2FjdGlvbnMgOiBbXSkuZmlsdGVyKGZ1bmN0aW9uICh0KSB7XG4gICAgICByZXR1cm4gdCAmJiAhdC5kZWxldGVkO1xuICAgIH0pO1xuICAgIGNvbnN0IGNhdGVnb3JpZXMgPSAoZGF0YSAmJiBBcnJheS5pc0FycmF5KGRhdGEuY2F0ZWdvcmllcykgJiYgZGF0YS5jYXRlZ29yaWVzLmxlbmd0aClcbiAgICAgID8gZGF0YS5jYXRlZ29yaWVzXG4gICAgICA6IERFRkFVTFRfQ0FURUdPUklFUztcbiAgICBjb25zdCBjYXRNYXAgPSBidWlsZENhdGVnb3J5TWFwKGNhdGVnb3JpZXMpO1xuICAgIGNvbnN0IGJ1ZGdldHMgPSAoZGF0YSAmJiBkYXRhLmJ1ZGdldHMpIHx8IHt9O1xuICAgIGNvbnN0IHdhbGxldHMgPSAoZGF0YSAmJiBkYXRhLndhbGxldHMpIHx8IERFRkFVTFRfV0FMTEVUUztcbiAgICBjb25zdCBtb250aGx5R29hbFNhdmluZ3NSYXRlID0gKGRhdGEgJiYgTnVtYmVyKGRhdGEudGFyZ2V0U2F2aW5nc1JhdGUpKSB8fCAyMDtcblxuICAgIGNvbnN0IGN1cnJlbnRUeCA9IGFsbFR4LmZpbHRlcihmdW5jdGlvbiAodCkgeyByZXR1cm4gdG9Nb250aEtleSh0LmRhdGUpID09PSBtb250aEtleTsgfSk7XG4gICAgY29uc3QgcHJldlR4ID0gYWxsVHguZmlsdGVyKGZ1bmN0aW9uICh0KSB7IHJldHVybiB0b01vbnRoS2V5KHQuZGF0ZSkgPT09IHByZXZNb250aEtleTsgfSk7XG5cbiAgICBsZXQgdG90YWxJbmNvbWUgPSAwO1xuICAgIGxldCB0b3RhbEV4cGVuc2UgPSAwO1xuICAgIGxldCB0b3RhbFNhdmVkQ2F0ZWdvcnkgPSAwO1xuICAgIGNvbnN0IGNhdGVnb3J5VG90YWxzID0ge307XG4gICAgY29uc3Qgd2FsbGV0U3BlbmRpbmcgPSB7fTtcbiAgICBjb25zdCBkYWlseVRvdGFscyA9IHt9O1xuICAgIGNvbnN0IGJ1Y2tldFRvdGFscyA9IHsgbmVlZHM6IDAsIHdhbnRzOiAwLCBzYXZpbmdzOiAwIH07XG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGN1cnJlbnRUeC5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgdHggPSBjdXJyZW50VHhbaV07XG4gICAgICBjb25zdCBhbXQgPSBOdW1iZXIodHguYW1vdW50KSB8fCAwO1xuICAgICAgY29uc3QgZGF5ID0gKHR4LmRhdGUgfHwgJycpLnNsaWNlKDAsIDEwKTtcbiAgICAgIGlmIChkYXkgJiYgIWRhaWx5VG90YWxzW2RheV0pIHtcbiAgICAgICAgZGFpbHlUb3RhbHNbZGF5XSA9IHsgZGF0ZTogZGF5LCBpbmNvbWU6IDAsIGV4cGVuc2U6IDAgfTtcbiAgICAgIH1cblxuICAgICAgaWYgKHR4LnR5cGUgPT09ICdpbmNvbWUnKSB7XG4gICAgICAgIHRvdGFsSW5jb21lICs9IGFtdDtcbiAgICAgICAgaWYgKGRheSkgZGFpbHlUb3RhbHNbZGF5XS5pbmNvbWUgKz0gYW10O1xuICAgICAgfSBlbHNlIGlmICh0eC50eXBlID09PSAnZXhwZW5zZScpIHtcbiAgICAgICAgY29uc3QgY2F0ID0gY2F0TWFwW3R4LmNhdGVnb3J5XSB8fCB7IGlkOiB0eC5jYXRlZ29yeSB8fCAnbGFpbm55YScsIG5hbWU6IHR4LmNhdGVnb3J5IHx8ICdMYWlubnlhJywgaWNvbjogJ1x1RDgzRFx1RENFNicsIGJ1Y2tldDogJ3dhbnRzJywgY29sb3I6ICcjNjQ3NDhiJyB9O1xuICAgICAgICBjb25zdCBidWNrZXQgPSBjYXQuYnVja2V0IHx8ICd3YW50cyc7XG5cbiAgICAgICAgaWYgKGJ1Y2tldCA9PT0gJ3NhdmluZ3MnKSB7XG4gICAgICAgICAgdG90YWxTYXZlZENhdGVnb3J5ICs9IGFtdDtcbiAgICAgICAgICBidWNrZXRUb3RhbHMuc2F2aW5ncyArPSBhbXQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdG90YWxFeHBlbnNlICs9IGFtdDtcbiAgICAgICAgICBpZiAoZGF5KSBkYWlseVRvdGFsc1tkYXldLmV4cGVuc2UgKz0gYW10O1xuICAgICAgICAgIGlmIChidWNrZXQgPT09ICduZWVkcycpIGJ1Y2tldFRvdGFscy5uZWVkcyArPSBhbXQ7XG4gICAgICAgICAgZWxzZSBidWNrZXRUb3RhbHMud2FudHMgKz0gYW10O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKCFjYXRlZ29yeVRvdGFsc1tjYXQuaWRdKSB7XG4gICAgICAgICAgY2F0ZWdvcnlUb3RhbHNbY2F0LmlkXSA9IHtcbiAgICAgICAgICAgIGlkOiBjYXQuaWQsXG4gICAgICAgICAgICBuYW1lOiBjYXQubmFtZSxcbiAgICAgICAgICAgIGljb246IGNhdC5pY29uLFxuICAgICAgICAgICAgY29sb3I6IGNhdC5jb2xvciB8fCAnIzY0NzQ4YicsXG4gICAgICAgICAgICBidWNrZXQ6IGJ1Y2tldCxcbiAgICAgICAgICAgIGFtb3VudDogMCxcbiAgICAgICAgICAgIGNvdW50OiAwLFxuICAgICAgICAgICAgYnVkZ2V0OiBOdW1iZXIoYnVkZ2V0c1tjYXQuaWRdKSB8fCAwXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjYXRlZ29yeVRvdGFsc1tjYXQuaWRdLmFtb3VudCArPSBhbXQ7XG4gICAgICAgIGNhdGVnb3J5VG90YWxzW2NhdC5pZF0uY291bnQgKz0gMTtcblxuICAgICAgICBjb25zdCB3SWQgPSB0eC53YWxsZXQgfHwgJ3R1bmFpJztcbiAgICAgICAgd2FsbGV0U3BlbmRpbmdbd0lkXSA9ICh3YWxsZXRTcGVuZGluZ1t3SWRdIHx8IDApICsgYW10O1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFByZXZpb3VzIG1vbnRoIGNhdGVnb3J5IHRvdGFscyBmb3IgY29tcGFyaXNvblxuICAgIGxldCBwcmV2VG90YWxFeHBlbnNlID0gMDtcbiAgICBsZXQgcHJldlRvdGFsSW5jb21lID0gMDtcbiAgICBjb25zdCBwcmV2Q2F0ZWdvcnlUb3RhbHMgPSB7fTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHByZXZUeC5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgdHggPSBwcmV2VHhbaV07XG4gICAgICBjb25zdCBhbXQgPSBOdW1iZXIodHguYW1vdW50KSB8fCAwO1xuICAgICAgaWYgKHR4LnR5cGUgPT09ICdpbmNvbWUnKSB7XG4gICAgICAgIHByZXZUb3RhbEluY29tZSArPSBhbXQ7XG4gICAgICB9IGVsc2UgaWYgKHR4LnR5cGUgPT09ICdleHBlbnNlJykge1xuICAgICAgICBjb25zdCBjYXQgPSBjYXRNYXBbdHguY2F0ZWdvcnldIHx8IHsgaWQ6IHR4LmNhdGVnb3J5IHx8ICdsYWlubnlhJywgYnVja2V0OiAnd2FudHMnIH07XG4gICAgICAgIGlmIChjYXQuYnVja2V0ICE9PSAnc2F2aW5ncycpIHtcbiAgICAgICAgICBwcmV2VG90YWxFeHBlbnNlICs9IGFtdDtcbiAgICAgICAgfVxuICAgICAgICBwcmV2Q2F0ZWdvcnlUb3RhbHNbY2F0LmlkXSA9IChwcmV2Q2F0ZWdvcnlUb3RhbHNbY2F0LmlkXSB8fCAwKSArIGFtdDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCB0b3RhbE91dGZsb3dXaXRoU2F2aW5ncyA9IHRvdGFsRXhwZW5zZSArIHRvdGFsU2F2ZWRDYXRlZ29yeTtcbiAgICBjb25zdCBuZXRDYXNoZmxvdyA9IHRvdGFsSW5jb21lIC0gdG90YWxFeHBlbnNlO1xuICAgIGNvbnN0IGVmZmVjdGl2ZVNhdmluZ3MgPSBNYXRoLm1heCgwLCBuZXRDYXNoZmxvdyk7IC8vIGluY2x1ZGVzIHVuc3BlbnQgY2FzaGZsb3cgKyBleHBsaWNpdCBzYXZpbmdzIGNhdGVnb3J5XG4gICAgY29uc3Qgc2F2aW5nc1JhdGUgPSB0b3RhbEluY29tZSA+IDAgPyBNYXRoLnJvdW5kKChlZmZlY3RpdmVTYXZpbmdzIC8gdG90YWxJbmNvbWUpICogMTAwMCkgLyAxMCA6IDA7XG5cbiAgICAvLyBCdWlsZCBzb3J0ZWQgY2F0ZWdvcnkgYnJlYWtkb3duIChleGNsdWRpbmcgb3IgdGFnZ2luZyBzYXZpbmdzKVxuICAgIGNvbnN0IGNhdGVnb3J5QnJlYWtkb3duID0gT2JqZWN0LmtleXMoY2F0ZWdvcnlUb3RhbHMpXG4gICAgICAubWFwKGZ1bmN0aW9uIChpZCkge1xuICAgICAgICBjb25zdCBpdGVtID0gY2F0ZWdvcnlUb3RhbHNbaWRdO1xuICAgICAgICBjb25zdCBiYXNlID0gaXRlbS5idWNrZXQgPT09ICdzYXZpbmdzJyA/IE1hdGgubWF4KHRvdGFsT3V0Zmxvd1dpdGhTYXZpbmdzLCAxKSA6IE1hdGgubWF4KHRvdGFsRXhwZW5zZSwgMSk7XG4gICAgICAgIGNvbnN0IHByZXZBbXQgPSBwcmV2Q2F0ZWdvcnlUb3RhbHNbaWRdIHx8IDA7XG4gICAgICAgIGNvbnN0IGRlbHRhUGN0ID0gcHJldkFtdCA+IDAgPyBNYXRoLnJvdW5kKCgoaXRlbS5hbW91bnQgLSBwcmV2QW10KSAvIHByZXZBbXQpICogMTAwKSA6IG51bGw7XG4gICAgICAgIGNvbnN0IGJ1ZGdldFVzZWRQY3QgPSBpdGVtLmJ1ZGdldCA+IDAgPyBNYXRoLnJvdW5kKChpdGVtLmFtb3VudCAvIGl0ZW0uYnVkZ2V0KSAqIDEwMCkgOiBudWxsO1xuICAgICAgICByZXR1cm4gT2JqZWN0LmFzc2lnbih7fSwgaXRlbSwge1xuICAgICAgICAgIHNoYXJlUGN0OiBpdGVtLmJ1Y2tldCA9PT0gJ3NhdmluZ3MnID8gMCA6IE1hdGgucm91bmQoKGl0ZW0uYW1vdW50IC8gYmFzZSkgKiAxMDAwKSAvIDEwLFxuICAgICAgICAgIHByZXZBbW91bnQ6IHByZXZBbXQsXG4gICAgICAgICAgZGVsdGFQY3Q6IGRlbHRhUGN0LFxuICAgICAgICAgIGJ1ZGdldFVzZWRQY3Q6IGJ1ZGdldFVzZWRQY3RcbiAgICAgICAgfSk7XG4gICAgICB9KVxuICAgICAgLnNvcnQoZnVuY3Rpb24gKGEsIGIpIHsgcmV0dXJuIGIuYW1vdW50IC0gYS5hbW91bnQ7IH0pO1xuXG4gICAgY29uc3QgZXhwZW5zZUNhdGVnb3JpZXMgPSBjYXRlZ29yeUJyZWFrZG93bi5maWx0ZXIoZnVuY3Rpb24gKGMpIHsgcmV0dXJuIGMuYnVja2V0ICE9PSAnc2F2aW5ncyc7IH0pO1xuXG4gICAgLy8gVG9wIDUgbGFyZ2VzdCBzaW5nbGUgZXhwZW5zZXNcbiAgICBjb25zdCB0b3BFeHBlbnNlcyA9IGN1cnJlbnRUeFxuICAgICAgLmZpbHRlcihmdW5jdGlvbiAodCkge1xuICAgICAgICBjb25zdCBjID0gY2F0TWFwW3QuY2F0ZWdvcnldO1xuICAgICAgICByZXR1cm4gdC50eXBlID09PSAnZXhwZW5zZScgJiYgKCFjIHx8IGMuYnVja2V0ICE9PSAnc2F2aW5ncycpO1xuICAgICAgfSlcbiAgICAgIC5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7IHJldHVybiAoTnVtYmVyKGIuYW1vdW50KSB8fCAwKSAtIChOdW1iZXIoYS5hbW91bnQpIHx8IDApOyB9KVxuICAgICAgLnNsaWNlKDAsIDUpXG4gICAgICAubWFwKGZ1bmN0aW9uICh0KSB7XG4gICAgICAgIGNvbnN0IGMgPSBjYXRNYXBbdC5jYXRlZ29yeV0gfHwgeyBuYW1lOiB0LmNhdGVnb3J5IHx8ICdMYWlubnlhJywgaWNvbjogJ1x1RDgzRFx1RENFNicgfTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBpZDogdC5pZCxcbiAgICAgICAgICBkYXRlOiB0LmRhdGUsXG4gICAgICAgICAgbm90ZTogdC5ub3RlIHx8IGMubmFtZSxcbiAgICAgICAgICBjYXRlZ29yeU5hbWU6IGMubmFtZSxcbiAgICAgICAgICBpY29uOiBjLmljb24sXG4gICAgICAgICAgYW1vdW50OiBOdW1iZXIodC5hbW91bnQpIHx8IDAsXG4gICAgICAgICAgd2FsbGV0OiB0LndhbGxldFxuICAgICAgICB9O1xuICAgICAgfSk7XG5cbiAgICAvLyBTYWZlLXRvLXNwZW5kIGRhaWx5IGxpbWl0XG4gICAgY29uc3QgdG90YWxEYXlzID0gZGF5c0luTW9udGgobW9udGhLZXkpO1xuICAgIGNvbnN0IGN1cnJlbnRNb250aEtleSA9IG5vdy5nZXRGdWxsWWVhcigpICsgJy0nICsgU3RyaW5nKG5vdy5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgJzAnKTtcbiAgICBsZXQgcmVtYWluaW5nRGF5cyA9IHRvdGFsRGF5cztcbiAgICBsZXQgZWxhcHNlZERheXMgPSB0b3RhbERheXM7XG4gICAgaWYgKG1vbnRoS2V5ID09PSBjdXJyZW50TW9udGhLZXkpIHtcbiAgICAgIGNvbnN0IHRvZGF5ID0gbm93LmdldERhdGUoKTtcbiAgICAgIGVsYXBzZWREYXlzID0gTWF0aC5tYXgoMSwgdG9kYXkpO1xuICAgICAgcmVtYWluaW5nRGF5cyA9IE1hdGgubWF4KDEsIHRvdGFsRGF5cyAtIHRvZGF5ICsgMSk7XG4gICAgfVxuXG4gICAgY29uc3QgdG90YWxCdWRnZXRDYXAgPSBPYmplY3Qua2V5cyhidWRnZXRzKS5yZWR1Y2UoZnVuY3Rpb24gKGFjYywgaykge1xuICAgICAgY29uc3QgYyA9IGNhdE1hcFtrXTtcbiAgICAgIGlmIChjICYmIGMuYnVja2V0ID09PSAnc2F2aW5ncycpIHJldHVybiBhY2M7XG4gICAgICByZXR1cm4gYWNjICsgKE51bWJlcihidWRnZXRzW2tdKSB8fCAwKTtcbiAgICB9LCAwKTtcblxuICAgIGNvbnN0IHRhcmdldE1vbnRobHlTcGVuZCA9IHRvdGFsSW5jb21lID4gMFxuICAgICAgPyBNYXRoLnJvdW5kKHRvdGFsSW5jb21lICogKDEgLSBtb250aGx5R29hbFNhdmluZ3NSYXRlIC8gMTAwKSlcbiAgICAgIDogKHRvdGFsQnVkZ2V0Q2FwID4gMCA/IHRvdGFsQnVkZ2V0Q2FwIDogdG90YWxFeHBlbnNlKTtcblxuICAgIGNvbnN0IHJlbWFpbmluZ1NwZW5kUm9vbSA9IHRhcmdldE1vbnRobHlTcGVuZCAtIHRvdGFsRXhwZW5zZTtcbiAgICBjb25zdCBzYWZlRGFpbHlTcGVuZCA9IChjdXJyZW50VHgubGVuZ3RoID4gMCAmJiByZW1haW5pbmdTcGVuZFJvb20gPiAwKVxuICAgICAgPyBNYXRoLmZsb29yKHJlbWFpbmluZ1NwZW5kUm9vbSAvIHJlbWFpbmluZ0RheXMpXG4gICAgICA6IDA7XG4gICAgY29uc3QgYXZnRGFpbHlTcGVuZCA9IE1hdGgucm91bmQodG90YWxFeHBlbnNlIC8gTWF0aC5tYXgoMSwgZWxhcHNlZERheXMpKTtcblxuICAgIC8vIDUwIC8gMzAgLyAyMCByYXRpb3MgKHJlbGF0aXZlIHRvIGluY29tZSBpZiBhdmFpbGFibGUsIG90aGVyd2lzZSByZWxhdGl2ZSB0byB0b3RhbCBvdXRmbG93KVxuICAgIGNvbnN0IHJhdGlvQmFzZSA9IHRvdGFsSW5jb21lID4gMCA/IHRvdGFsSW5jb21lIDogTWF0aC5tYXgoMSwgdG90YWxPdXRmbG93V2l0aFNhdmluZ3MpO1xuICAgIGNvbnN0IG5lZWRzUGN0ID0gTWF0aC5yb3VuZCgoYnVja2V0VG90YWxzLm5lZWRzIC8gcmF0aW9CYXNlKSAqIDEwMDApIC8gMTA7XG4gICAgY29uc3Qgd2FudHNQY3QgPSBNYXRoLnJvdW5kKChidWNrZXRUb3RhbHMud2FudHMgLyByYXRpb0Jhc2UpICogMTAwMCkgLyAxMDtcbiAgICBjb25zdCBzYXZpbmdzQnVja2V0UGN0ID0gdG90YWxJbmNvbWUgPiAwXG4gICAgICA/IE1hdGgubWF4KDAsIE1hdGgucm91bmQoKGVmZmVjdGl2ZVNhdmluZ3MgLyB0b3RhbEluY29tZSkgKiAxMDAwKSAvIDEwKVxuICAgICAgOiBNYXRoLnJvdW5kKChidWNrZXRUb3RhbHMuc2F2aW5ncyAvIHJhdGlvQmFzZSkgKiAxMDAwKSAvIDEwO1xuXG4gICAgLy8gRmluYW5jaWFsIEhlYWx0aCBTY29yZSAoMCAtIDEwMClcbiAgICBsZXQgaGVhbHRoU2NvcmUgPSA1MDtcbiAgICBpZiAoY3VycmVudFR4Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgaGVhbHRoU2NvcmUgPSAwO1xuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgc2NvcmUgPSA0MDtcbiAgICAgIGlmICh0b3RhbEluY29tZSA+IDApIHtcbiAgICAgICAgaWYgKHNhdmluZ3NSYXRlID49IDIwKSBzY29yZSArPSAzMDtcbiAgICAgICAgZWxzZSBpZiAoc2F2aW5nc1JhdGUgPj0gMTApIHNjb3JlICs9IDIwO1xuICAgICAgICBlbHNlIGlmIChzYXZpbmdzUmF0ZSA+IDApIHNjb3JlICs9IDEwO1xuICAgICAgICBlbHNlIHNjb3JlIC09IDE1O1xuICAgICAgfVxuICAgICAgaWYgKHdhbnRzUGN0IDw9IDMwKSBzY29yZSArPSAxNTtcbiAgICAgIGVsc2UgaWYgKHdhbnRzUGN0IDw9IDQwKSBzY29yZSArPSA1O1xuICAgICAgZWxzZSBzY29yZSAtPSAxMDtcblxuICAgICAgY29uc3Qgb3ZlckJ1ZGdldENvdW50ID0gZXhwZW5zZUNhdGVnb3JpZXMuZmlsdGVyKGZ1bmN0aW9uIChjKSB7IHJldHVybiBjLmJ1ZGdldCA+IDAgJiYgYy5hbW91bnQgPiBjLmJ1ZGdldDsgfSkubGVuZ3RoO1xuICAgICAgaWYgKG92ZXJCdWRnZXRDb3VudCA9PT0gMCkgc2NvcmUgKz0gMTU7XG4gICAgICBlbHNlIHNjb3JlIC09IE1hdGgubWluKDIwLCBvdmVyQnVkZ2V0Q291bnQgKiA3KTtcblxuICAgICAgaGVhbHRoU2NvcmUgPSBNYXRoLm1heCgwLCBNYXRoLm1pbigxMDAsIE1hdGgucm91bmQoc2NvcmUpKSk7XG4gICAgfVxuXG4gICAgLy8gR2VuZXJhdGUgU21hcnQgUmVjb21tZW5kYXRpb25zXG4gICAgY29uc3QgcmVjb21tZW5kYXRpb25zID0gW107XG5cbiAgICBpZiAoY3VycmVudFR4Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmVjb21tZW5kYXRpb25zLnB1c2goe1xuICAgICAgICBwcmlvcml0eTogJ2luZm8nLFxuICAgICAgICB0aXRsZTogJ011bGFpIENhdGF0IFRyYW5zYWtzaSBCdWxhbiBJbmknLFxuICAgICAgICBzdW1tYXJ5OiAnQmVsdW0gYWRhIHRyYW5zYWtzaSB0ZXJjYXRhdCBkaSBwZXJpb2RlICcgKyBtb250aEtleSArICcuIENhdGF0IHBlbWFzdWthbiBkYW4gcGVuZ2VsdWFyYW4gaGFyaWFubXUgYWdhciBhbmFsaXNpcyBkYW4gcmVrb21lbmRhc2kgYmVyamFsYW4gYWt1cmF0LicsXG4gICAgICAgIGFjdGlvbjogJ1RhbWJhaGthbiBwZW1hc3VrYW4gdXRhbWEgZGFuIG1pbmltYWwgMyB0cmFuc2Frc2kgcGVuZ2VsdWFyYW4gaGFyaSBpbmkuJ1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIDEuIENhc2hmbG93IC8gU2F2aW5ncyBSYXRlIGNoZWNrXG4gICAgICBpZiAodG90YWxJbmNvbWUgPiAwICYmIG5ldENhc2hmbG93IDwgMCkge1xuICAgICAgICByZWNvbW1lbmRhdGlvbnMucHVzaCh7XG4gICAgICAgICAgcHJpb3JpdHk6ICdoaWdoJyxcbiAgICAgICAgICB0aXRsZTogJ1BlbmdlbHVhcmFuIE1lbGViaWhpIFBlbWFzdWthbiAoJyArIGZvcm1hdElEUihNYXRoLmFicyhuZXRDYXNoZmxvdykpICsgJyBEZWZpc2l0KScsXG4gICAgICAgICAgc3VtbWFyeTogJ1RvdGFsIHBlbmdlbHVhcmFuIGJ1bGFuIGluaSAoJyArIGZvcm1hdElEUih0b3RhbEV4cGVuc2UpICsgJykgc3VkYWggbWVsYW1wYXVpIHBlbWFzdWthbiAoJyArIGZvcm1hdElEUih0b3RhbEluY29tZSkgKyAnKS4nLFxuICAgICAgICAgIGFjdGlvbjogJ0hlbnRpa2FuIHNlbWVudGFyYSBwZW5nZWx1YXJhbiBrYXRlZ29yaSBLZWluZ2luYW4gKHdhbnRzKSBkYW4gZXZhbHVhc2kga2F0ZWdvcmkgdGVyYmVzYXI6ICcgKyAoZXhwZW5zZUNhdGVnb3JpZXNbMF0gPyBleHBlbnNlQ2F0ZWdvcmllc1swXS5uYW1lIDogJy0nKSArICcuJ1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAodG90YWxJbmNvbWUgPiAwICYmIHNhdmluZ3NSYXRlIDwgbW9udGhseUdvYWxTYXZpbmdzUmF0ZSkge1xuICAgICAgICBjb25zdCBnYXAgPSBNYXRoLnJvdW5kKCh0b3RhbEluY29tZSAqIChtb250aGx5R29hbFNhdmluZ3NSYXRlIC8gMTAwKSkgLSBlZmZlY3RpdmVTYXZpbmdzKTtcbiAgICAgICAgcmVjb21tZW5kYXRpb25zLnB1c2goe1xuICAgICAgICAgIHByaW9yaXR5OiAnbWVkaXVtJyxcbiAgICAgICAgICB0aXRsZTogJ1RpbmdrYXRrYW4gUmFzaW8gVGFidW5nYW4gTWVudWp1ICcgKyBtb250aGx5R29hbFNhdmluZ3NSYXRlICsgJyUnLFxuICAgICAgICAgIHN1bW1hcnk6ICdSYXNpbyB0YWJ1bmdhbiBzYWF0IGluaSAnICsgc2F2aW5nc1JhdGUgKyAnJSAoJyArIGZvcm1hdElEUihlZmZlY3RpdmVTYXZpbmdzKSArICcpLiBLYW11IGJ1dHVoIG1lbmdoZW1hdCBzZWtpdGFyICcgKyBmb3JtYXRJRFIoZ2FwKSArICcgbGFnaSBhZ2FyIG1lbmNhcGFpIHRhcmdldCAnICsgbW9udGhseUdvYWxTYXZpbmdzUmF0ZSArICclLicsXG4gICAgICAgICAgYWN0aW9uOiAnU2lzaWhrYW4gdGFidW5nYW4gZGkgYXdhbCBzYWF0IG1lbmVyaW1hIGdhamkgKG1ldG9kZSBQYXkgWW91cnNlbGYgRmlyc3QpIHNlYmVzYXIgJyArIGZvcm1hdElEUihNYXRoLnJvdW5kKHRvdGFsSW5jb21lICogKG1vbnRobHlHb2FsU2F2aW5nc1JhdGUgLyAxMDApKSkgKyAnLidcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2UgaWYgKHRvdGFsSW5jb21lID4gMCkge1xuICAgICAgICByZWNvbW1lbmRhdGlvbnMucHVzaCh7XG4gICAgICAgICAgcHJpb3JpdHk6ICdnb29kJyxcbiAgICAgICAgICB0aXRsZTogJ0FydXMgS2FzIFNlaGF0IFx1MjAxNCBSYXNpbyBUYWJ1bmdhbiAnICsgc2F2aW5nc1JhdGUgKyAnJScsXG4gICAgICAgICAgc3VtbWFyeTogJ1NlbGFtYXQhIEthbXUgYmVyaGFzaWwgbWVueWlzaWhrYW4gJyArIGZvcm1hdElEUihlZmZlY3RpdmVTYXZpbmdzKSArICcgKCcgKyBzYXZpbmdzUmF0ZSArICclIGRhcmkgcGVtYXN1a2FuKSBidWxhbiBpbmkuJyxcbiAgICAgICAgICBhY3Rpb246ICdQZXJ0YWhhbmthbiBiYXRhcyBiZWxhbmphIGhhcmlhbiBtYWtzaW1hbCAnICsgZm9ybWF0SURSKHNhZmVEYWlseVNwZW5kKSArICcvaGFyaSBoaW5nZ2EgYWtoaXIgYnVsYW4sIGRhbiBhbG9rYXNpa2FuIGtlbGViaWhhbiBrZSBkYW5hIGRhcnVyYXQvaW52ZXN0YXNpLidcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIC8vIDIuIERvbWluYW50IENhdGVnb3J5IC8gUGFyZXRvIFdhcm5pbmdcbiAgICAgIGlmIChleHBlbnNlQ2F0ZWdvcmllcy5sZW5ndGggPiAwICYmIHRvdGFsRXhwZW5zZSA+IDApIHtcbiAgICAgICAgY29uc3QgdG9wQ2F0ID0gZXhwZW5zZUNhdGVnb3JpZXNbMF07XG4gICAgICAgIGlmICh0b3BDYXQuc2hhcmVQY3QgPj0gMzUpIHtcbiAgICAgICAgICBjb25zdCBzdWdnZXN0ZWRDdXQgPSBNYXRoLnJvdW5kKHRvcENhdC5hbW91bnQgKiAwLjE1KTtcbiAgICAgICAgICByZWNvbW1lbmRhdGlvbnMucHVzaCh7XG4gICAgICAgICAgICBwcmlvcml0eTogJ21lZGl1bScsXG4gICAgICAgICAgICB0aXRsZTogdG9wQ2F0Lmljb24gKyAnICcgKyB0b3BDYXQubmFtZSArICcgTWVueWVyYXAgJyArIHRvcENhdC5zaGFyZVBjdCArICclIFBlbmdlbHVhcmFuJyxcbiAgICAgICAgICAgIHN1bW1hcnk6ICdQb3MgcGVuZ2VsdWFyYW4gdGVyYmVzYXIgYWRhbGFoICcgKyB0b3BDYXQubmFtZSArICcgc2ViZXNhciAnICsgZm9ybWF0SURSKHRvcENhdC5hbW91bnQpICsgJyAoJyArIHRvcENhdC5jb3VudCArICcgdHJhbnNha3NpKS4nLFxuICAgICAgICAgICAgYWN0aW9uOiAnSmlrYSBidWxhbiBkZXBhbiBrYW11IG1lbWFuZ2thcyAxNSUgcG9zIGluaSwga2FtdSBiaXNhIGJlcmhlbWF0IGVrc3RyYSAnICsgZm9ybWF0SURSKHN1Z2dlc3RlZEN1dCkgKyAnL2J1bGFuLidcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyAzLiBCdWRnZXQgT3ZlcnJ1biAvIE5lYXItTGltaXQgV2FybmluZ1xuICAgICAgY29uc3Qgb3ZlckNhdHMgPSBleHBlbnNlQ2F0ZWdvcmllcy5maWx0ZXIoZnVuY3Rpb24gKGMpIHsgcmV0dXJuIGMuYnVkZ2V0ID4gMCAmJiBjLmFtb3VudCA+IGMuYnVkZ2V0OyB9KTtcbiAgICAgIGNvbnN0IG5lYXJDYXRzID0gZXhwZW5zZUNhdGVnb3JpZXMuZmlsdGVyKGZ1bmN0aW9uIChjKSB7IHJldHVybiBjLmJ1ZGdldCA+IDAgJiYgYy5hbW91bnQgPD0gYy5idWRnZXQgJiYgYy5idWRnZXRVc2VkUGN0ID49IDgwOyB9KTtcblxuICAgICAgaWYgKG92ZXJDYXRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgY29uc3QgbmFtZXMgPSBvdmVyQ2F0cy5tYXAoZnVuY3Rpb24gKGMpIHsgcmV0dXJuIGMubmFtZSArICcgKCcgKyBjLmJ1ZGdldFVzZWRQY3QgKyAnJSknOyB9KS5qb2luKCcsICcpO1xuICAgICAgICByZWNvbW1lbmRhdGlvbnMucHVzaCh7XG4gICAgICAgICAgcHJpb3JpdHk6ICdoaWdoJyxcbiAgICAgICAgICB0aXRsZTogJ0FuZ2dhcmFuIFRlcmxhbXBhdWkgZGkgJyArIG92ZXJDYXRzLmxlbmd0aCArICcgS2F0ZWdvcmknLFxuICAgICAgICAgIHN1bW1hcnk6ICdLYXRlZ29yaSB5YW5nIHN1ZGFoIG1lbGV3YXRpIGJhdGFzIGJ1ZGdldCBidWxhbiBpbmk6ICcgKyBuYW1lcyArICcuJyxcbiAgICAgICAgICBhY3Rpb246ICdCZWt1a2FuIGJlbGFuamEgbm9uLWVzZW5zaWFsIHBhZGEga2F0ZWdvcmkgdGVyc2VidXQgZGFuIHJldmlzaSBiYXRhcyBidWRnZXQgYnVsYW4gZGVwYW4gYWdhciBsZWJpaCByZWFsaXN0aXMuJ1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAobmVhckNhdHMubGVuZ3RoID4gMCkge1xuICAgICAgICBjb25zdCBuYW1lcyA9IG5lYXJDYXRzLm1hcChmdW5jdGlvbiAoYykgeyByZXR1cm4gYy5uYW1lICsgJyAoJyArIGMuYnVkZ2V0VXNlZFBjdCArICclKSc7IH0pLmpvaW4oJywgJyk7XG4gICAgICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKHtcbiAgICAgICAgICBwcmlvcml0eTogJ21lZGl1bScsXG4gICAgICAgICAgdGl0bGU6ICdNZW5kZWthdGkgQmF0YXMgQW5nZ2FyYW4nLFxuICAgICAgICAgIHN1bW1hcnk6ICdLYXRlZ29yaSAnICsgbmFtZXMgKyAnIHN1ZGFoIG1lbWFrYWkgXHUyMjY1ODAlIGFuZ2dhcmFuIGJ1bGFuYW4uJyxcbiAgICAgICAgICBhY3Rpb246ICdHdW5ha2FuIHNpc2EgYW5nZ2FyYW4gc2VjYXJhIGtldGF0IGRlbmdhbiBiYXRhcyBoYXJpYW4gJyArIGZvcm1hdElEUihzYWZlRGFpbHlTcGVuZCkgKyAnL2hhcmkuJ1xuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gNC4gNTAvMzAvMjAgV2FudHMgQ2hlY2tcbiAgICAgIGlmICh3YW50c1BjdCA+IDMwKSB7XG4gICAgICAgIGNvbnN0IGV4Y2Vzc1dhbnRzID0gTWF0aC5yb3VuZChidWNrZXRUb3RhbHMud2FudHMgLSAocmF0aW9CYXNlICogMC4zMCkpO1xuICAgICAgICByZWNvbW1lbmRhdGlvbnMucHVzaCh7XG4gICAgICAgICAgcHJpb3JpdHk6ICdtZWRpdW0nLFxuICAgICAgICAgIHRpdGxlOiAnUGVuZ2VsdWFyYW4gR2F5YSBIaWR1cCAoV2FudHMpICcgKyB3YW50c1BjdCArICclIChJZGVhbCBcdTIyNjQgMzAlKScsXG4gICAgICAgICAgc3VtbWFyeTogJ1RvdGFsIHBlbmdlbHVhcmFuIGthdGVnb3JpIGtlaW5naW5hbi9nYXlhIGhpZHVwIG1lbmNhcGFpICcgKyBmb3JtYXRJRFIoYnVja2V0VG90YWxzLndhbnRzKSArICcuJyxcbiAgICAgICAgICBhY3Rpb246ICdLdXJhbmdpIHNla2l0YXIgJyArIGZvcm1hdElEUihleGNlc3NXYW50cykgKyAnIHBhZGEgcG9zIGtvcGkvamFqYW4sIGhpYnVyYW4sIGF0YXUgYmVsYW5qYSBpbXB1bHNpZiBidWxhbiBkZXBhbi4nXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICAvLyA1LiBGcmVxdWVudCBTbWFsbCBTcGVuZGluZyAoXCJMYXR0ZSBGYWN0b3JcIilcbiAgICAgIGNvbnN0IHNtYWxsRnJlcXVlbnQgPSBleHBlbnNlQ2F0ZWdvcmllcy5maWx0ZXIoZnVuY3Rpb24gKGMpIHtcbiAgICAgICAgcmV0dXJuIGMuY291bnQgPj0gNSAmJiAoYy5hbW91bnQgLyBjLmNvdW50KSA8PSA3NTAwMCAmJiBjLmJ1Y2tldCA9PT0gJ3dhbnRzJztcbiAgICAgIH0pO1xuICAgICAgaWYgKHNtYWxsRnJlcXVlbnQubGVuZ3RoID4gMCkge1xuICAgICAgICBjb25zdCBmID0gc21hbGxGcmVxdWVudFswXTtcbiAgICAgICAgY29uc3QgYXZnVGlja2V0ID0gTWF0aC5yb3VuZChmLmFtb3VudCAvIGYuY291bnQpO1xuICAgICAgICByZWNvbW1lbmRhdGlvbnMucHVzaCh7XG4gICAgICAgICAgcHJpb3JpdHk6ICdpbmZvJyxcbiAgICAgICAgICB0aXRsZTogJ0RldGVrc2kgS2ViaWFzYWFuIEtlY2lsIEJlcnVsYW5nOiAnICsgZi5uYW1lLFxuICAgICAgICAgIHN1bW1hcnk6ICdUZXJjYXRhdCAnICsgZi5jb3VudCArICcgdHJhbnNha3NpIGtlY2lsIChyYXRhLXJhdGEgJyArIGZvcm1hdElEUihhdmdUaWNrZXQpICsgJykgZGVuZ2FuIHRvdGFsICcgKyBmb3JtYXRJRFIoZi5hbW91bnQpICsgJy4nLFxuICAgICAgICAgIGFjdGlvbjogJ1RlcmFwa2FuIGF0dXJhbiBcIm1pbmdndSB0YW5wYSBqYWphblwiIDIgaGFyaS9taW5nZ3UgdW50dWsgbWVtYW5na2FzIDI1JSBwb3MgaW5pICgnICsgZm9ybWF0SURSKE1hdGgucm91bmQoZi5hbW91bnQgKiAwLjI1KSkgKyAnKS4nXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICAvLyA2LiBNb250aC1vdmVyLW1vbnRoIHNwaWtlXG4gICAgICBjb25zdCBzcGlrZWQgPSBleHBlbnNlQ2F0ZWdvcmllcy5maWx0ZXIoZnVuY3Rpb24gKGMpIHsgcmV0dXJuIGMuZGVsdGFQY3QgIT09IG51bGwgJiYgYy5kZWx0YVBjdCA+PSAyNSAmJiBjLmFtb3VudCA+PSAxMDAwMDA7IH0pO1xuICAgICAgaWYgKHNwaWtlZC5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IHMgPSBzcGlrZWRbMF07XG4gICAgICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKHtcbiAgICAgICAgICBwcmlvcml0eTogJ21lZGl1bScsXG4gICAgICAgICAgdGl0bGU6ICdMb25qYWthbiArJyArIHMuZGVsdGFQY3QgKyAnJSBkaSAnICsgcy5uYW1lICsgJyB2cyBCdWxhbiBMYWx1JyxcbiAgICAgICAgICBzdW1tYXJ5OiAnQnVsYW4gbGFsdSAnICsgZm9ybWF0SURSKHMucHJldkFtb3VudCkgKyAnLCBidWxhbiBpbmkgbmFpayBtZW5qYWRpICcgKyBmb3JtYXRJRFIocy5hbW91bnQpICsgJy4nLFxuICAgICAgICAgIGFjdGlvbjogJ0NlayBrZW1iYWxpIGRhZnRhciB0cmFuc2Frc2kgJyArIHMubmFtZSArICcgdW50dWsgbWVtYXN0aWthbiB0aWRhayBhZGEgYmlheWEgbGFuZ2dhbmFuL2tlYm9jb3JhbiB5YW5nIHRlcmxld2F0LidcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIC8vIDcuIEVtZXJnZW5jeSBGdW5kIFByb2plY3Rpb25cbiAgICAgIGlmICh0b3RhbEV4cGVuc2UgPiAwKSB7XG4gICAgICAgIGNvbnN0IGVtZXJnZW5jeVRhcmdldCA9IHRvdGFsRXhwZW5zZSAqIDM7XG4gICAgICAgIGNvbnN0IG1vbnRobHlTYXZlID0gZWZmZWN0aXZlU2F2aW5ncyA+IDAgPyBlZmZlY3RpdmVTYXZpbmdzIDogTWF0aC5yb3VuZCgodG90YWxJbmNvbWUgfHwgdG90YWxFeHBlbnNlKSAqIDAuMTUpO1xuICAgICAgICBjb25zdCBtb250aHNOZWVkZWQgPSBtb250aGx5U2F2ZSA+IDAgPyBNYXRoLmNlaWwoZW1lcmdlbmN5VGFyZ2V0IC8gbW9udGhseVNhdmUpIDogbnVsbDtcbiAgICAgICAgcmVjb21tZW5kYXRpb25zLnB1c2goe1xuICAgICAgICAgIHByaW9yaXR5OiAnaW5mbycsXG4gICAgICAgICAgdGl0bGU6ICdQcm95ZWtzaSBEYW5hIERhcnVyYXQgTWluaW1hbCAoM3ggUGVuZ2VsdWFyYW4pJyxcbiAgICAgICAgICBzdW1tYXJ5OiAnRGVuZ2FuIHBvbGEgcGVuZ2VsdWFyYW4gJyArIGZvcm1hdElEUih0b3RhbEV4cGVuc2UpICsgJy9idWxhbiwgdGFyZ2V0IGRhbmEgZGFydXJhdCBhd2FsbXUgYWRhbGFoICcgKyBmb3JtYXRJRFIoZW1lcmdlbmN5VGFyZ2V0KSArICcuJyxcbiAgICAgICAgICBhY3Rpb246IG1vbnRoc05lZWRlZFxuICAgICAgICAgICAgPyAnRGVuZ2FuIHRhYnVuZ2FuICcgKyBmb3JtYXRJRFIobW9udGhseVNhdmUpICsgJy9idWxhbiwgdGFyZ2V0IGluaSB0ZXJjYXBhaSBkYWxhbSB+JyArIG1vbnRoc05lZWRlZCArICcgYnVsYW4uJ1xuICAgICAgICAgICAgOiAnVGV0YXBrYW4gdGFyZ2V0IHRhYnVuZ2FuIGJ1bGFuYW4gYWdhciBwcm95ZWtzaSBkYW5hIGRhcnVyYXQgZGFwYXQgZGloaXR1bmcuJ1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBTdWdnZXN0ZWQgTmV4dC1Nb250aCBCdWRnZXQgUGxhblxuICAgIGNvbnN0IG5leHRNb250aFBsYW4gPSBleHBlbnNlQ2F0ZWdvcmllcy5tYXAoZnVuY3Rpb24gKGMpIHtcbiAgICAgIGxldCBzdWdnZXN0ZWQgPSBjLmFtb3VudDtcbiAgICAgIGxldCByYXRpb25hbGUgPSAnUGVydGFoYW5rYW4gc2VzdWFpIHBvbGEgYnVsYW4gaW5pJztcbiAgICAgIGlmIChjLmJ1Y2tldCA9PT0gJ3dhbnRzJyAmJiAod2FudHNQY3QgPiAzMCB8fCAoYy5kZWx0YVBjdCAhPT0gbnVsbCAmJiBjLmRlbHRhUGN0ID4gMTUpKSkge1xuICAgICAgICBzdWdnZXN0ZWQgPSBNYXRoLnJvdW5kKChjLmFtb3VudCAqIDAuODUpIC8gMTAwMDApICogMTAwMDA7XG4gICAgICAgIHJhdGlvbmFsZSA9ICdQYW5na2FzIDE1JSB1bnR1ayBlZmlzaWVuc2kgZ2F5YSBoaWR1cCc7XG4gICAgICB9IGVsc2UgaWYgKGMuYnVkZ2V0ID4gMCAmJiBjLmFtb3VudCA+IGMuYnVkZ2V0KSB7XG4gICAgICAgIHN1Z2dlc3RlZCA9IE1hdGgucm91bmQoKChjLmJ1ZGdldCArIGMuYW1vdW50KSAvIDIpIC8gMTAwMDApICogMTAwMDA7XG4gICAgICAgIHJhdGlvbmFsZSA9ICdQZW55ZXN1YWlhbiBtb2RlcmF0IGFudGFyYSBidWRnZXQgbGFtYSAmIHJlYWxpc2FzaSc7XG4gICAgICB9IGVsc2UgaWYgKGMuYnVkZ2V0ID4gMCkge1xuICAgICAgICBzdWdnZXN0ZWQgPSBjLmJ1ZGdldDtcbiAgICAgICAgcmF0aW9uYWxlID0gJ1Nlc3VhaSBhbmdnYXJhbiB5YW5nIHN1ZGFoIGRpdGV0YXBrYW4nO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY2F0ZWdvcnlJZDogYy5pZCxcbiAgICAgICAgbmFtZTogYy5uYW1lLFxuICAgICAgICBpY29uOiBjLmljb24sXG4gICAgICAgIGN1cnJlbnRBbW91bnQ6IGMuYW1vdW50LFxuICAgICAgICBzdWdnZXN0ZWRCdWRnZXQ6IE1hdGgubWF4KDAsIHN1Z2dlc3RlZCksXG4gICAgICAgIHJhdGlvbmFsZTogcmF0aW9uYWxlXG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgY29uc3QgZGFpbHlTZXJpZXMgPSBPYmplY3Qua2V5cyhkYWlseVRvdGFscykuc29ydCgpLm1hcChmdW5jdGlvbiAoZCkgeyByZXR1cm4gZGFpbHlUb3RhbHNbZF07IH0pO1xuICAgIGNvbnN0IHdhbGxldEJhbGFuY2VzID0gY29tcHV0ZVdhbGxldEJhbGFuY2VzKGFsbFR4LCB3YWxsZXRzKTtcblxuICAgIHJldHVybiB7XG4gICAgICBtb250aDogbW9udGhLZXksXG4gICAgICBwcmV2aW91c01vbnRoOiBwcmV2TW9udGhLZXksXG4gICAgICBzdW1tYXJ5OiB7XG4gICAgICAgIHRvdGFsSW5jb21lOiB0b3RhbEluY29tZSxcbiAgICAgICAgdG90YWxFeHBlbnNlOiB0b3RhbEV4cGVuc2UsXG4gICAgICAgIHRvdGFsU2F2ZWRDYXRlZ29yeTogdG90YWxTYXZlZENhdGVnb3J5LFxuICAgICAgICBuZXRDYXNoZmxvdzogbmV0Q2FzaGZsb3csXG4gICAgICAgIGVmZmVjdGl2ZVNhdmluZ3M6IGVmZmVjdGl2ZVNhdmluZ3MsXG4gICAgICAgIHNhdmluZ3NSYXRlOiBzYXZpbmdzUmF0ZSxcbiAgICAgICAgcHJldlRvdGFsSW5jb21lOiBwcmV2VG90YWxJbmNvbWUsXG4gICAgICAgIHByZXZUb3RhbEV4cGVuc2U6IHByZXZUb3RhbEV4cGVuc2UsXG4gICAgICAgIGV4cGVuc2VEZWx0YVBjdDogcHJldlRvdGFsRXhwZW5zZSA+IDAgPyBNYXRoLnJvdW5kKCgodG90YWxFeHBlbnNlIC0gcHJldlRvdGFsRXhwZW5zZSkgLyBwcmV2VG90YWxFeHBlbnNlKSAqIDEwMCkgOiBudWxsLFxuICAgICAgICBhdmdEYWlseVNwZW5kOiBhdmdEYWlseVNwZW5kLFxuICAgICAgICBzYWZlRGFpbHlTcGVuZDogc2FmZURhaWx5U3BlbmQsXG4gICAgICAgIHJlbWFpbmluZ0RheXM6IHJlbWFpbmluZ0RheXMsXG4gICAgICAgIHRyYW5zYWN0aW9uQ291bnQ6IGN1cnJlbnRUeC5sZW5ndGgsXG4gICAgICAgIGhlYWx0aFNjb3JlOiBoZWFsdGhTY29yZVxuICAgICAgfSxcbiAgICAgIHJ1bGU1MDMwMjA6IHtcbiAgICAgICAgbmVlZHNBbW91bnQ6IGJ1Y2tldFRvdGFscy5uZWVkcyxcbiAgICAgICAgd2FudHNBbW91bnQ6IGJ1Y2tldFRvdGFscy53YW50cyxcbiAgICAgICAgc2F2aW5nc0Ftb3VudDogZWZmZWN0aXZlU2F2aW5ncyxcbiAgICAgICAgbmVlZHNQY3Q6IG5lZWRzUGN0LFxuICAgICAgICB3YW50c1BjdDogd2FudHNQY3QsXG4gICAgICAgIHNhdmluZ3NQY3Q6IHNhdmluZ3NCdWNrZXRQY3RcbiAgICAgIH0sXG4gICAgICBjYXRlZ29yeUJyZWFrZG93bjogY2F0ZWdvcnlCcmVha2Rvd24sXG4gICAgICB0b3BFeHBlbnNlczogdG9wRXhwZW5zZXMsXG4gICAgICB3YWxsZXRTcGVuZGluZzogd2FsbGV0U3BlbmRpbmcsXG4gICAgICB3YWxsZXRCYWxhbmNlczogd2FsbGV0QmFsYW5jZXMsXG4gICAgICBkYWlseVNlcmllczogZGFpbHlTZXJpZXMsXG4gICAgICByZWNvbW1lbmRhdGlvbnM6IHJlY29tbWVuZGF0aW9ucyxcbiAgICAgIG5leHRNb250aFBsYW46IG5leHRNb250aFBsYW5cbiAgICB9O1xuICB9XG5cbiAgZnVuY3Rpb24gcmVuZGVyTWFya2Rvd25SZWNhcChyZXBvcnQpIHtcbiAgICBjb25zdCBzID0gcmVwb3J0LnN1bW1hcnk7XG4gICAgY29uc3QgciA9IHJlcG9ydC5ydWxlNTAzMDIwO1xuICAgIGNvbnN0IGxpbmVzID0gW107XG4gICAgbGluZXMucHVzaCgnIyBSZWthcCAmIFJla29tZW5kYXNpIEtldWFuZ2FuIFx1MjAxNCAnICsgcmVwb3J0Lm1vbnRoKTtcbiAgICBsaW5lcy5wdXNoKCcnKTtcbiAgICBsaW5lcy5wdXNoKCcjIyBSaW5na2FzYW4gQnVsYW4gJyArIHJlcG9ydC5tb250aCk7XG4gICAgbGluZXMucHVzaCgnLSAqKlRvdGFsIFBlbWFzdWthbioqOiAnICsgZm9ybWF0SURSKHMudG90YWxJbmNvbWUpKTtcbiAgICBsaW5lcy5wdXNoKCctICoqVG90YWwgUGVuZ2VsdWFyYW4qKjogJyArIGZvcm1hdElEUihzLnRvdGFsRXhwZW5zZSkgKyAocy5leHBlbnNlRGVsdGFQY3QgIT09IG51bGwgPyAnICgnICsgKHMuZXhwZW5zZURlbHRhUGN0ID49IDAgPyAnKycgOiAnJykgKyBzLmV4cGVuc2VEZWx0YVBjdCArICclIHZzIGJ1bGFuIGxhbHUpJyA6ICcnKSk7XG4gICAgbGluZXMucHVzaCgnLSAqKlNpc2EgQXJ1cyBLYXMgLyBUYWJ1bmdhbiBFZmVrdGlmKio6ICcgKyBmb3JtYXRJRFIocy5lZmZlY3RpdmVTYXZpbmdzKSArICcgKCcgKyBzLnNhdmluZ3NSYXRlICsgJyUpJyk7XG4gICAgbGluZXMucHVzaCgnLSAqKlJhdGEtcmF0YSBCZWxhbmphIEhhcmlhbioqOiAnICsgZm9ybWF0SURSKHMuYXZnRGFpbHlTcGVuZCkgKyAnL2hhcmknKTtcbiAgICBsaW5lcy5wdXNoKCctICoqQmF0YXMgQW1hbiBCZWxhbmphIEhhcmlhbiAoU2FmZS10by1TcGVuZCkqKjogJyArIGZvcm1hdElEUihzLnNhZmVEYWlseVNwZW5kKSArICcvaGFyaSAoc2lzYSAnICsgcy5yZW1haW5pbmdEYXlzICsgJyBoYXJpKScpO1xuICAgIGxpbmVzLnB1c2goJy0gKipTa29yIEtlc2VoYXRhbiBLZXVhbmdhbioqOiAnICsgcy5oZWFsdGhTY29yZSArICcvMTAwJyk7XG4gICAgbGluZXMucHVzaCgnJyk7XG4gICAgbGluZXMucHVzaCgnIyMgUHJvcG9yc2kgNTAgLyAzMCAvIDIwJyk7XG4gICAgbGluZXMucHVzaCgnLSAqKktlYnV0dWhhbiAoTmVlZHMsIGlkZWFsIFx1MjI2NDUwJSkqKjogJyArIHIubmVlZHNQY3QgKyAnJSAoJyArIGZvcm1hdElEUihyLm5lZWRzQW1vdW50KSArICcpJyk7XG4gICAgbGluZXMucHVzaCgnLSAqKktlaW5naW5hbiAoV2FudHMsIGlkZWFsIFx1MjI2NDMwJSkqKjogJyArIHIud2FudHNQY3QgKyAnJSAoJyArIGZvcm1hdElEUihyLndhbnRzQW1vdW50KSArICcpJyk7XG4gICAgbGluZXMucHVzaCgnLSAqKlRhYnVuZ2FuIChTYXZpbmdzLCBpZGVhbCBcdTIyNjUyMCUpKio6ICcgKyByLnNhdmluZ3NQY3QgKyAnJSAoJyArIGZvcm1hdElEUihyLnNhdmluZ3NBbW91bnQpICsgJyknKTtcbiAgICBsaW5lcy5wdXNoKCcnKTtcbiAgICBsaW5lcy5wdXNoKCcjIyBQZW5nZWx1YXJhbiBUZXJiZXNhciBwZXIgS2F0ZWdvcmknKTtcbiAgICBpZiAocmVwb3J0LmNhdGVnb3J5QnJlYWtkb3duLmxlbmd0aCA9PT0gMCkge1xuICAgICAgbGluZXMucHVzaCgnLSBCZWx1bSBhZGEgcGVuZ2VsdWFyYW4gdGVyY2F0YXQuJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlcG9ydC5jYXRlZ29yeUJyZWFrZG93bi5mb3JFYWNoKGZ1bmN0aW9uIChjLCBpZHgpIHtcbiAgICAgICAgY29uc3QgYnVkZ2V0SW5mbyA9IGMuYnVkZ2V0ID4gMCA/ICcgfCBCdWRnZXQ6ICcgKyBmb3JtYXRJRFIoYy5idWRnZXQpICsgJyAoJyArIGMuYnVkZ2V0VXNlZFBjdCArICclKScgOiAnJztcbiAgICAgICAgbGluZXMucHVzaCgoaWR4ICsgMSkgKyAnLiAnICsgYy5pY29uICsgJyAqKicgKyBjLm5hbWUgKyAnKio6ICcgKyBmb3JtYXRJRFIoYy5hbW91bnQpICsgJyAoJyArIGMuc2hhcmVQY3QgKyAnJSwgJyArIGMuY291bnQgKyAneCknICsgYnVkZ2V0SW5mbyk7XG4gICAgICB9KTtcbiAgICB9XG4gICAgbGluZXMucHVzaCgnJyk7XG4gICAgbGluZXMucHVzaCgnIyMgUmVrb21lbmRhc2kgS2VkZXBhbm55YScpO1xuICAgIHJlcG9ydC5yZWNvbW1lbmRhdGlvbnMuZm9yRWFjaChmdW5jdGlvbiAocmVjLCBpZHgpIHtcbiAgICAgIGxpbmVzLnB1c2goKGlkeCArIDEpICsgJy4gKipbJyArIHJlYy5wcmlvcml0eS50b1VwcGVyQ2FzZSgpICsgJ10gJyArIHJlYy50aXRsZSArICcqKicpO1xuICAgICAgbGluZXMucHVzaCgnICAgLSBTaXR1YXNpOiAnICsgcmVjLnN1bW1hcnkpO1xuICAgICAgbGluZXMucHVzaCgnICAgLSBMYW5na2FoOiAnICsgcmVjLmFjdGlvbik7XG4gICAgfSk7XG4gICAgaWYgKHJlcG9ydC5uZXh0TW9udGhQbGFuLmxlbmd0aCA+IDApIHtcbiAgICAgIGxpbmVzLnB1c2goJycpO1xuICAgICAgbGluZXMucHVzaCgnIyMgU2FyYW4gVGFyZ2V0IEJ1ZGdldCBCdWxhbiBEZXBhbicpO1xuICAgICAgcmVwb3J0Lm5leHRNb250aFBsYW4uZm9yRWFjaChmdW5jdGlvbiAocCkge1xuICAgICAgICBsaW5lcy5wdXNoKCctICcgKyBwLmljb24gKyAnICoqJyArIHAubmFtZSArICcqKjogJyArIGZvcm1hdElEUihwLnN1Z2dlc3RlZEJ1ZGdldCkgKyAnICgnICsgcC5yYXRpb25hbGUgKyAnKScpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBsaW5lcy5qb2luKCdcXG4nKTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAgREVGQVVMVF9DQVRFR09SSUVTOiBERUZBVUxUX0NBVEVHT1JJRVMsXG4gICAgREVGQVVMVF9XQUxMRVRTOiBERUZBVUxUX1dBTExFVFMsXG4gICAgZm9ybWF0SURSOiBmb3JtYXRJRFIsXG4gICAgYW5hbHl6ZU1vbnRoOiBhbmFseXplTW9udGgsXG4gICAgcmVuZGVyTWFya2Rvd25SZWNhcDogcmVuZGVyTWFya2Rvd25SZWNhcCxcbiAgICBjb21wdXRlV2FsbGV0QmFsYW5jZXM6IGNvbXB1dGVXYWxsZXRCYWxhbmNlc1xuICB9O1xufSk7XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG5jb25zdCBmcyA9IHJlcXVpcmUoJ2ZzJyk7XG5jb25zdCBwYXRoID0gcmVxdWlyZSgncGF0aCcpO1xuY29uc3QgY3J5cHRvID0gcmVxdWlyZSgnY3J5cHRvJyk7XG5jb25zdCBhbmFseXRpY3MgPSByZXF1aXJlKCcuL2FuYWx5dGljcycpO1xuXG5jb25zdCBEQVRBX0RJUiA9IHByb2Nlc3MuZW52LkRBVEFfRElSIHx8IHBhdGguam9pbihfX2Rpcm5hbWUsICcuLicsICdkYXRhJyk7XG5cbmZ1bmN0aW9uIGVuc3VyZURhdGFEaXIoKSB7XG4gIGlmICghZnMuZXhpc3RzU3luYyhEQVRBX0RJUikpIHtcbiAgICBmcy5ta2RpclN5bmMoREFUQV9ESVIsIHsgcmVjdXJzaXZlOiB0cnVlIH0pO1xuICB9XG59XG5cbmZ1bmN0aW9uIHNhbml0aXplV29ya3NwYWNlSWQod3NJZCkge1xuICBjb25zdCBjbGVhbiA9IFN0cmluZyh3c0lkIHx8ICdwcmliYWRpJylcbiAgICAudG9Mb3dlckNhc2UoKVxuICAgIC5yZXBsYWNlKC9bXmEtejAtOV8tXS9nLCAnJylcbiAgICAuc2xpY2UoMCwgNDgpO1xuICByZXR1cm4gY2xlYW4gfHwgJ3ByaWJhZGknO1xufVxuXG5mdW5jdGlvbiBoYXNoUGluKHBpbikge1xuICBpZiAoIXBpbikgcmV0dXJuIG51bGw7XG4gIHJldHVybiBjcnlwdG8uY3JlYXRlSGFzaCgnc2hhMjU2JykudXBkYXRlKCd1YW5na3U6JyArIFN0cmluZyhwaW4pKS5kaWdlc3QoJ2hleCcpO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVEZWZhdWx0V29ya3NwYWNlKHdzSWQpIHtcbiAgcmV0dXJuIHtcbiAgICB3b3Jrc3BhY2VJZDogc2FuaXRpemVXb3Jrc3BhY2VJZCh3c0lkKSxcbiAgICByZXZpc2lvbjogMSxcbiAgICB1cGRhdGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB0YXJnZXRTYXZpbmdzUmF0ZTogMjAsXG4gICAgcGluSGFzaDogbnVsbCxcbiAgICBjYXRlZ29yaWVzOiBhbmFseXRpY3MuREVGQVVMVF9DQVRFR09SSUVTLFxuICAgIHdhbGxldHM6IGFuYWx5dGljcy5ERUZBVUxUX1dBTExFVFMsXG4gICAgYnVkZ2V0czoge1xuICAgICAgbWFrYW46IDE1MDAwMDAsXG4gICAgICBrb3BpOiA0MDAwMDAsXG4gICAgICB0cmFuc3BvcnQ6IDYwMDAwMCxcbiAgICAgIHRhZ2loYW46IDE1MDAwMDAsXG4gICAgICBiZWxhbmphOiA3NTAwMDAsXG4gICAgICBoaWJ1cmFuOiA0MDAwMDBcbiAgICB9LFxuICAgIHRyYW5zYWN0aW9uczogW11cbiAgfTtcbn1cblxuZnVuY3Rpb24gZ2V0V29ya3NwYWNlUGF0aCh3c0lkKSB7XG4gIGVuc3VyZURhdGFEaXIoKTtcbiAgcmV0dXJuIHBhdGguam9pbihEQVRBX0RJUiwgc2FuaXRpemVXb3Jrc3BhY2VJZCh3c0lkKSArICcuanNvbicpO1xufVxuXG5mdW5jdGlvbiByZWFkV29ya3NwYWNlKHdzSWQpIHtcbiAgY29uc3QgY2xlYW5JZCA9IHNhbml0aXplV29ya3NwYWNlSWQod3NJZCk7XG4gIGNvbnN0IGZpbGVQYXRoID0gZ2V0V29ya3NwYWNlUGF0aChjbGVhbklkKTtcbiAgaWYgKCFmcy5leGlzdHNTeW5jKGZpbGVQYXRoKSkge1xuICAgIGNvbnN0IGZyZXNoID0gY3JlYXRlRGVmYXVsdFdvcmtzcGFjZShjbGVhbklkKTtcbiAgICB3cml0ZVdvcmtzcGFjZUF0b21pYyhjbGVhbklkLCBmcmVzaCk7XG4gICAgcmV0dXJuIGZyZXNoO1xuICB9XG4gIHRyeSB7XG4gICAgY29uc3QgcmF3ID0gZnMucmVhZEZpbGVTeW5jKGZpbGVQYXRoLCAndXRmOCcpO1xuICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2UocmF3KTtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkocGFyc2VkLnRyYW5zYWN0aW9ucykpIHBhcnNlZC50cmFuc2FjdGlvbnMgPSBbXTtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkocGFyc2VkLmNhdGVnb3JpZXMpIHx8ICFwYXJzZWQuY2F0ZWdvcmllcy5sZW5ndGgpIHBhcnNlZC5jYXRlZ29yaWVzID0gYW5hbHl0aWNzLkRFRkFVTFRfQ0FURUdPUklFUztcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkocGFyc2VkLndhbGxldHMpIHx8ICFwYXJzZWQud2FsbGV0cy5sZW5ndGgpIHBhcnNlZC53YWxsZXRzID0gYW5hbHl0aWNzLkRFRkFVTFRfV0FMTEVUUztcbiAgICBpZiAoIXBhcnNlZC5idWRnZXRzIHx8IHR5cGVvZiBwYXJzZWQuYnVkZ2V0cyAhPT0gJ29iamVjdCcpIHBhcnNlZC5idWRnZXRzID0ge307XG4gICAgaWYgKCFwYXJzZWQucmV2aXNpb24pIHBhcnNlZC5yZXZpc2lvbiA9IDE7XG4gICAgcGFyc2VkLndvcmtzcGFjZUlkID0gY2xlYW5JZDtcbiAgICByZXR1cm4gcGFyc2VkO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBjb25zdCBmYWxsYmFjayA9IGNyZWF0ZURlZmF1bHRXb3Jrc3BhY2UoY2xlYW5JZCk7XG4gICAgcmV0dXJuIGZhbGxiYWNrO1xuICB9XG59XG5cbmZ1bmN0aW9uIHdyaXRlV29ya3NwYWNlQXRvbWljKHdzSWQsIGRhdGEpIHtcbiAgY29uc3QgY2xlYW5JZCA9IHNhbml0aXplV29ya3NwYWNlSWQod3NJZCk7XG4gIGNvbnN0IGZpbGVQYXRoID0gZ2V0V29ya3NwYWNlUGF0aChjbGVhbklkKTtcbiAgY29uc3QgdG1wUGF0aCA9IGZpbGVQYXRoICsgJy4nICsgcHJvY2Vzcy5waWQgKyAnLicgKyBEYXRlLm5vdygpICsgJy50bXAnO1xuICBmcy53cml0ZUZpbGVTeW5jKHRtcFBhdGgsIEpTT04uc3RyaW5naWZ5KGRhdGEsIG51bGwsIDIpLCAndXRmOCcpO1xuICBmcy5yZW5hbWVTeW5jKHRtcFBhdGgsIGZpbGVQYXRoKTtcbn1cblxuZnVuY3Rpb24gc2FuaXRpemVDbGllbnRWaWV3KHdzKSB7XG4gIHJldHVybiB7XG4gICAgd29ya3NwYWNlSWQ6IHdzLndvcmtzcGFjZUlkLFxuICAgIHJldmlzaW9uOiB3cy5yZXZpc2lvbixcbiAgICB1cGRhdGVkQXQ6IHdzLnVwZGF0ZWRBdCxcbiAgICBoYXNQaW46IEJvb2xlYW4od3MucGluSGFzaCksXG4gICAgdGFyZ2V0U2F2aW5nc1JhdGU6IHdzLnRhcmdldFNhdmluZ3NSYXRlIHx8IDIwLFxuICAgIGNhdGVnb3JpZXM6IHdzLmNhdGVnb3JpZXMsXG4gICAgd2FsbGV0czogd3Mud2FsbGV0cyxcbiAgICBidWRnZXRzOiB3cy5idWRnZXRzLFxuICAgIHRyYW5zYWN0aW9uczogd3MudHJhbnNhY3Rpb25zLmZpbHRlcihmdW5jdGlvbiAodCkgeyByZXR1cm4gIXQuZGVsZXRlZDsgfSksXG4gICAgdG9tYnN0b25lczogd3MudHJhbnNhY3Rpb25zLmZpbHRlcihmdW5jdGlvbiAodCkgeyByZXR1cm4gdC5kZWxldGVkOyB9KS5tYXAoZnVuY3Rpb24gKHQpIHtcbiAgICAgIHJldHVybiB7IGlkOiB0LmlkLCB1cGRhdGVkQXQ6IHQudXBkYXRlZEF0LCBkZWxldGVkOiB0cnVlIH07XG4gICAgfSlcbiAgfTtcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplVHJhbnNhY3Rpb24odHgpIHtcbiAgY29uc3Qgbm93SXNvID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICBjb25zdCBpZCA9IFN0cmluZyh0eC5pZCB8fCAoJ3R4XycgKyBjcnlwdG8ucmFuZG9tVVVJRCgpKSkuc2xpY2UoMCwgNjQpO1xuICBjb25zdCB0eXBlID0gWydleHBlbnNlJywgJ2luY29tZScsICd0cmFuc2ZlciddLmluY2x1ZGVzKHR4LnR5cGUpID8gdHgudHlwZSA6ICdleHBlbnNlJztcbiAgY29uc3QgYW1vdW50ID0gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZChOdW1iZXIodHguYW1vdW50KSB8fCAwKSk7XG4gIGNvbnN0IGRhdGUgPSB0eXBlb2YgdHguZGF0ZSA9PT0gJ3N0cmluZycgJiYgL15cXGR7NH0tXFxkezJ9LVxcZHsyfS8udGVzdCh0eC5kYXRlKVxuICAgID8gdHguZGF0ZS5zbGljZSgwLCAxOSlcbiAgICA6IG5vd0lzby5zbGljZSgwLCAxMCk7XG5cbiAgcmV0dXJuIHtcbiAgICBpZDogaWQsXG4gICAgdHlwZTogdHlwZSxcbiAgICBhbW91bnQ6IGFtb3VudCxcbiAgICBjYXRlZ29yeTogU3RyaW5nKHR4LmNhdGVnb3J5IHx8ICh0eXBlID09PSAnaW5jb21lJyA/ICdnYWppJyA6ICdsYWlubnlhJykpLnNsaWNlKDAsIDQ4KSxcbiAgICB3YWxsZXQ6IFN0cmluZyh0eC53YWxsZXQgfHwgJ3R1bmFpJykuc2xpY2UoMCwgNDgpLFxuICAgIHRvV2FsbGV0OiB0eXBlID09PSAndHJhbnNmZXInID8gU3RyaW5nKHR4LnRvV2FsbGV0IHx8ICdiYW5rJykuc2xpY2UoMCwgNDgpIDogdW5kZWZpbmVkLFxuICAgIGRhdGU6IGRhdGUsXG4gICAgbm90ZTogU3RyaW5nKHR4Lm5vdGUgfHwgJycpLnNsaWNlKDAsIDIwMCksXG4gICAgZGV2aWNlOiBTdHJpbmcodHguZGV2aWNlIHx8ICd3ZWInKS5zbGljZSgwLCAzMiksXG4gICAgZGVsZXRlZDogQm9vbGVhbih0eC5kZWxldGVkKSxcbiAgICBjcmVhdGVkQXQ6IHR4LmNyZWF0ZWRBdCB8fCBub3dJc28sXG4gICAgdXBkYXRlZEF0OiB0eC51cGRhdGVkQXQgfHwgbm93SXNvXG4gIH07XG59XG5cbmZ1bmN0aW9uIG1lcmdlVHJhbnNhY3Rpb25zKGV4aXN0aW5nLCBpbmNvbWluZykge1xuICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZXhpc3RpbmcubGVuZ3RoOyBpKyspIHtcbiAgICBtYXAuc2V0KGV4aXN0aW5nW2ldLmlkLCBleGlzdGluZ1tpXSk7XG4gIH1cbiAgbGV0IGNoYW5nZWQgPSBmYWxzZTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbmNvbWluZy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IG5vcm0gPSBub3JtYWxpemVUcmFuc2FjdGlvbihpbmNvbWluZ1tpXSk7XG4gICAgY29uc3QgcHJldiA9IG1hcC5nZXQobm9ybS5pZCk7XG4gICAgaWYgKCFwcmV2IHx8IFN0cmluZyhub3JtLnVwZGF0ZWRBdCkgPiBTdHJpbmcocHJldi51cGRhdGVkQXQpKSB7XG4gICAgICBtYXAuc2V0KG5vcm0uaWQsIG5vcm0pO1xuICAgICAgY2hhbmdlZCA9IHRydWU7XG4gICAgfVxuICB9XG4gIGNvbnN0IG1lcmdlZCA9IEFycmF5LmZyb20obWFwLnZhbHVlcygpKS5zb3J0KGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgaWYgKGEuZGF0ZSAhPT0gYi5kYXRlKSByZXR1cm4gYS5kYXRlIDwgYi5kYXRlID8gMSA6IC0xO1xuICAgIHJldHVybiBTdHJpbmcoYS5jcmVhdGVkQXQpIDwgU3RyaW5nKGIuY3JlYXRlZEF0KSA/IDEgOiAtMTtcbiAgfSk7XG4gIHJldHVybiB7IG1lcmdlZDogbWVyZ2VkLCBjaGFuZ2VkOiBjaGFuZ2VkIH07XG59XG5cbmZ1bmN0aW9uIHVwc2VydFRyYW5zYWN0aW9uKHdzSWQsIHR4SW5wdXQpIHtcbiAgY29uc3Qgd3MgPSByZWFkV29ya3NwYWNlKHdzSWQpO1xuICBjb25zdCBub3dJc28gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gIGNvbnN0IHR4ID0gbm9ybWFsaXplVHJhbnNhY3Rpb24oT2JqZWN0LmFzc2lnbih7fSwgdHhJbnB1dCwgeyB1cGRhdGVkQXQ6IG5vd0lzbyB9KSk7XG4gIGNvbnN0IHJlcyA9IG1lcmdlVHJhbnNhY3Rpb25zKHdzLnRyYW5zYWN0aW9ucywgW3R4XSk7XG4gIHdzLnRyYW5zYWN0aW9ucyA9IHJlcy5tZXJnZWQ7XG4gIHdzLnJldmlzaW9uICs9IDE7XG4gIHdzLnVwZGF0ZWRBdCA9IG5vd0lzbztcbiAgd3JpdGVXb3Jrc3BhY2VBdG9taWMod3NJZCwgd3MpO1xuICByZXR1cm4geyB3b3Jrc3BhY2U6IHdzLCB0cmFuc2FjdGlvbjogdHggfTtcbn1cblxuZnVuY3Rpb24gZGVsZXRlVHJhbnNhY3Rpb24od3NJZCwgdHhJZCkge1xuICBjb25zdCB3cyA9IHJlYWRXb3Jrc3BhY2Uod3NJZCk7XG4gIGNvbnN0IG5vd0lzbyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgY29uc3QgZXhpc3RpbmcgPSB3cy50cmFuc2FjdGlvbnMuZmluZChmdW5jdGlvbiAodCkgeyByZXR1cm4gdC5pZCA9PT0gdHhJZDsgfSk7XG4gIGlmICghZXhpc3RpbmcpIHJldHVybiB7IHdvcmtzcGFjZTogd3MsIGRlbGV0ZWQ6IGZhbHNlIH07XG4gIGV4aXN0aW5nLmRlbGV0ZWQgPSB0cnVlO1xuICBleGlzdGluZy51cGRhdGVkQXQgPSBub3dJc287XG4gIHdzLnJldmlzaW9uICs9IDE7XG4gIHdzLnVwZGF0ZWRBdCA9IG5vd0lzbztcbiAgd3JpdGVXb3Jrc3BhY2VBdG9taWMod3NJZCwgd3MpO1xuICByZXR1cm4geyB3b3Jrc3BhY2U6IHdzLCBkZWxldGVkOiB0cnVlIH07XG59XG5cbmZ1bmN0aW9uIHN5bmNCYXRjaCh3c0lkLCBwYXlsb2FkKSB7XG4gIGNvbnN0IHdzID0gcmVhZFdvcmtzcGFjZSh3c0lkKTtcbiAgY29uc3Qgbm93SXNvID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICBjb25zdCBpbmNvbWluZ1R4ID0gQXJyYXkuaXNBcnJheShwYXlsb2FkLnRyYW5zYWN0aW9ucykgPyBwYXlsb2FkLnRyYW5zYWN0aW9ucyA6IFtdO1xuICBjb25zdCByZXMgPSBtZXJnZVRyYW5zYWN0aW9ucyh3cy50cmFuc2FjdGlvbnMsIGluY29taW5nVHgpO1xuICBsZXQgbWV0YUNoYW5nZWQgPSBmYWxzZTtcblxuICBpZiAocGF5bG9hZC5idWRnZXRzICYmIHR5cGVvZiBwYXlsb2FkLmJ1ZGdldHMgPT09ICdvYmplY3QnKSB7XG4gICAgd3MuYnVkZ2V0cyA9IE9iamVjdC5hc3NpZ24oe30sIHdzLmJ1ZGdldHMsIHBheWxvYWQuYnVkZ2V0cyk7XG4gICAgbWV0YUNoYW5nZWQgPSB0cnVlO1xuICB9XG4gIGlmIChwYXlsb2FkLnRhcmdldFNhdmluZ3NSYXRlICE9PSB1bmRlZmluZWQpIHtcbiAgICBjb25zdCByYXRlID0gTWF0aC5tYXgoMSwgTWF0aC5taW4oODAsIE51bWJlcihwYXlsb2FkLnRhcmdldFNhdmluZ3NSYXRlKSB8fCAyMCkpO1xuICAgIHdzLnRhcmdldFNhdmluZ3NSYXRlID0gcmF0ZTtcbiAgICBtZXRhQ2hhbmdlZCA9IHRydWU7XG4gIH1cbiAgaWYgKEFycmF5LmlzQXJyYXkocGF5bG9hZC53YWxsZXRzKSAmJiBwYXlsb2FkLndhbGxldHMubGVuZ3RoID4gMCkge1xuICAgIHdzLndhbGxldHMgPSBwYXlsb2FkLndhbGxldHM7XG4gICAgbWV0YUNoYW5nZWQgPSB0cnVlO1xuICB9XG5cbiAgaWYgKHJlcy5jaGFuZ2VkIHx8IG1ldGFDaGFuZ2VkKSB7XG4gICAgd3MudHJhbnNhY3Rpb25zID0gcmVzLm1lcmdlZDtcbiAgICB3cy5yZXZpc2lvbiArPSAxO1xuICAgIHdzLnVwZGF0ZWRBdCA9IG5vd0lzbztcbiAgICB3cml0ZVdvcmtzcGFjZUF0b21pYyh3c0lkLCB3cyk7XG4gIH1cbiAgcmV0dXJuIHdzO1xufVxuXG5mdW5jdGlvbiB1cGRhdGVTZXR0aW5ncyh3c0lkLCBwYXlsb2FkKSB7XG4gIGNvbnN0IHdzID0gcmVhZFdvcmtzcGFjZSh3c0lkKTtcbiAgY29uc3Qgbm93SXNvID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICBpZiAocGF5bG9hZC5idWRnZXRzICYmIHR5cGVvZiBwYXlsb2FkLmJ1ZGdldHMgPT09ICdvYmplY3QnKSB7XG4gICAgY29uc3QgY2xlYW5CdWRnZXRzID0ge307XG4gICAgT2JqZWN0LmtleXMocGF5bG9hZC5idWRnZXRzKS5mb3JFYWNoKGZ1bmN0aW9uIChrKSB7XG4gICAgICBjb25zdCB2ID0gTWF0aC5tYXgoMCwgTWF0aC5yb3VuZChOdW1iZXIocGF5bG9hZC5idWRnZXRzW2tdKSB8fCAwKSk7XG4gICAgICBpZiAodiA+IDApIGNsZWFuQnVkZ2V0c1trXSA9IHY7XG4gICAgfSk7XG4gICAgd3MuYnVkZ2V0cyA9IGNsZWFuQnVkZ2V0cztcbiAgfVxuICBpZiAocGF5bG9hZC50YXJnZXRTYXZpbmdzUmF0ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgd3MudGFyZ2V0U2F2aW5nc1JhdGUgPSBNYXRoLm1heCgxLCBNYXRoLm1pbig4MCwgTnVtYmVyKHBheWxvYWQudGFyZ2V0U2F2aW5nc1JhdGUpIHx8IDIwKSk7XG4gIH1cbiAgaWYgKEFycmF5LmlzQXJyYXkocGF5bG9hZC53YWxsZXRzKSAmJiBwYXlsb2FkLndhbGxldHMubGVuZ3RoID4gMCkge1xuICAgIHdzLndhbGxldHMgPSBwYXlsb2FkLndhbGxldHMubWFwKGZ1bmN0aW9uICh3KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBpZDogU3RyaW5nKHcuaWQgfHwgJ3dhbGxldCcpLnNsaWNlKDAsIDMyKSxcbiAgICAgICAgbmFtZTogU3RyaW5nKHcubmFtZSB8fCAnRG9tcGV0Jykuc2xpY2UoMCwgNDApLFxuICAgICAgICBpY29uOiBTdHJpbmcody5pY29uIHx8ICdcdUQ4M0RcdURDQjMnKS5zbGljZSgwLCA4KSxcbiAgICAgICAgaW5pdGlhbEJhbGFuY2U6IE51bWJlcih3LmluaXRpYWxCYWxhbmNlKSB8fCAwXG4gICAgICB9O1xuICAgIH0pO1xuICB9XG4gIGlmIChwYXlsb2FkLm5ld1BpbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgd3MucGluSGFzaCA9IHBheWxvYWQubmV3UGluID8gaGFzaFBpbihwYXlsb2FkLm5ld1BpbikgOiBudWxsO1xuICB9XG4gIHdzLnJldmlzaW9uICs9IDE7XG4gIHdzLnVwZGF0ZWRBdCA9IG5vd0lzbztcbiAgd3JpdGVXb3Jrc3BhY2VBdG9taWMod3NJZCwgd3MpO1xuICByZXR1cm4gd3M7XG59XG5cbmZ1bmN0aW9uIGJ1aWxkRGVtb1NhbXBsZXMocmVmRGF0ZSkge1xuICBjb25zdCBub3cgPSByZWZEYXRlIGluc3RhbmNlb2YgRGF0ZSA/IHJlZkRhdGUgOiBuZXcgRGF0ZSgpO1xuICBjb25zdCB5bSA9IG5vdy5nZXRGdWxsWWVhcigpICsgJy0nICsgU3RyaW5nKG5vdy5nZXRNb250aCgpICsgMSkucGFkU3RhcnQoMiwgJzAnKTtcbiAgY29uc3QgcHJldkRhdGUgPSBuZXcgRGF0ZShub3cuZ2V0RnVsbFllYXIoKSwgbm93LmdldE1vbnRoKCkgLSAxLCAxNSk7XG4gIGNvbnN0IHByZXZZbSA9IHByZXZEYXRlLmdldEZ1bGxZZWFyKCkgKyAnLScgKyBTdHJpbmcocHJldkRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJyk7XG4gIGNvbnN0IGRheSA9IGZ1bmN0aW9uIChtLCBkKSB7XG4gICAgY29uc3QgbWF4RCA9IG5ldyBEYXRlKE51bWJlcihtLnNsaWNlKDAsIDQpKSwgTnVtYmVyKG0uc2xpY2UoNSwgNykpLCAwKS5nZXREYXRlKCk7XG4gICAgY29uc3Qgc2FmZUQgPSBNYXRoLm1pbihkLCBtYXhEKTtcbiAgICByZXR1cm4gbSArICctJyArIFN0cmluZyhzYWZlRCkucGFkU3RhcnQoMiwgJzAnKTtcbiAgfTtcblxuICByZXR1cm4gW1xuICAgIC8vIFByZXZpb3VzIG1vbnRoIGJhc2VsaW5lIGZvciBNb00gY29tcGFyaXNvblxuICAgIHsgaWQ6ICdkZW1vX3AxJywgdHlwZTogJ2luY29tZScsIGFtb3VudDogNzUwMDAwMCwgY2F0ZWdvcnk6ICdnYWppJywgd2FsbGV0OiAnYmFuaycsIGRhdGU6IGRheShwcmV2WW0sIDEpLCBub3RlOiAnR2FqaSBCdWxhbmFuJywgZGV2aWNlOiAnZGVza3RvcCcgfSxcbiAgICB7IGlkOiAnZGVtb19wMicsIHR5cGU6ICdleHBlbnNlJywgYW1vdW50OiAxNDAwMDAwLCBjYXRlZ29yeTogJ3RhZ2loYW4nLCB3YWxsZXQ6ICdiYW5rJywgZGF0ZTogZGF5KHByZXZZbSwgMyksIG5vdGU6ICdLb3MgJiBMaXN0cmlrJywgZGV2aWNlOiAnZGVza3RvcCcgfSxcbiAgICB7IGlkOiAnZGVtb19wMycsIHR5cGU6ICdleHBlbnNlJywgYW1vdW50OiAxMjAwMDAwLCBjYXRlZ29yeTogJ21ha2FuJywgd2FsbGV0OiAnZXdhbGxldCcsIGRhdGU6IGRheShwcmV2WW0sIDEwKSwgbm90ZTogJ01ha2FuIGhhcmlhbiAmIHdhcnRlZycsIGRldmljZTogJ2FuZHJvaWQnIH0sXG4gICAgeyBpZDogJ2RlbW9fcDQnLCB0eXBlOiAnZXhwZW5zZScsIGFtb3VudDogMzIwMDAwLCBjYXRlZ29yeTogJ2tvcGknLCB3YWxsZXQ6ICdld2FsbGV0JywgZGF0ZTogZGF5KHByZXZZbSwgMTQpLCBub3RlOiAnS29waSBzdXN1ICYgc25hY2snLCBkZXZpY2U6ICdhbmRyb2lkJyB9LFxuICAgIHsgaWQ6ICdkZW1vX3A1JywgdHlwZTogJ2V4cGVuc2UnLCBhbW91bnQ6IDQ4MDAwMCwgY2F0ZWdvcnk6ICd0cmFuc3BvcnQnLCB3YWxsZXQ6ICdld2FsbGV0JywgZGF0ZTogZGF5KHByZXZZbSwgMTgpLCBub3RlOiAnQmVuc2luICYgb2pvbCcsIGRldmljZTogJ2FuZHJvaWQnIH0sXG4gICAgeyBpZDogJ2RlbW9fcDYnLCB0eXBlOiAnZXhwZW5zZScsIGFtb3VudDogMTAwMDAwMCwgY2F0ZWdvcnk6ICd0YWJ1bmdhbicsIHdhbGxldDogJ2JhbmsnLCBkYXRlOiBkYXkocHJldlltLCAyNSksIG5vdGU6ICdUYWJ1bmdhbiByZWtzYWRhbmEnLCBkZXZpY2U6ICdkZXNrdG9wJyB9LFxuXG4gICAgLy8gQ3VycmVudCBtb250aCByaWNoIGRhdGFcbiAgICB7IGlkOiAnZGVtb19jMScsIHR5cGU6ICdpbmNvbWUnLCBhbW91bnQ6IDc1MDAwMDAsIGNhdGVnb3J5OiAnZ2FqaScsIHdhbGxldDogJ2JhbmsnLCBkYXRlOiBkYXkoeW0sIDEpLCBub3RlOiAnR2FqaSBCdWxhbmFuJywgZGV2aWNlOiAnZGVza3RvcCcgfSxcbiAgICB7IGlkOiAnZGVtb19jMicsIHR5cGU6ICdpbmNvbWUnLCBhbW91bnQ6IDk1MDAwMCwgY2F0ZWdvcnk6ICdib251cycsIHdhbGxldDogJ2JhbmsnLCBkYXRlOiBkYXkoeW0sIDgpLCBub3RlOiAnUHJvamVjdCBGcmVlbGFuY2UgVUknLCBkZXZpY2U6ICdkZXNrdG9wJyB9LFxuICAgIHsgaWQ6ICdkZW1vX2MzJywgdHlwZTogJ3RyYW5zZmVyJywgYW1vdW50OiAxNTAwMDAwLCBjYXRlZ29yeTogJ2xhaW5ueWEnLCB3YWxsZXQ6ICdiYW5rJywgdG9XYWxsZXQ6ICdld2FsbGV0JywgZGF0ZTogZGF5KHltLCAyKSwgbm90ZTogJ1RvcCB1cCBFLVdhbGxldCBidWxhbmFuJywgZGV2aWNlOiAnYW5kcm9pZCcgfSxcbiAgICB7IGlkOiAnZGVtb19jNCcsIHR5cGU6ICd0cmFuc2ZlcicsIGFtb3VudDogNTAwMDAwLCBjYXRlZ29yeTogJ2xhaW5ueWEnLCB3YWxsZXQ6ICdiYW5rJywgdG9XYWxsZXQ6ICd0dW5haScsIGRhdGU6IGRheSh5bSwgMiksIG5vdGU6ICdUYXJpayB0dW5haSBBVE0nLCBkZXZpY2U6ICdhbmRyb2lkJyB9LFxuICAgIHsgaWQ6ICdkZW1vX2M1JywgdHlwZTogJ2V4cGVuc2UnLCBhbW91bnQ6IDE0NTAwMDAsIGNhdGVnb3J5OiAndGFnaWhhbicsIHdhbGxldDogJ2JhbmsnLCBkYXRlOiBkYXkoeW0sIDMpLCBub3RlOiAnU2V3YSBrb3MgKyBpbnRlcm5ldCcsIGRldmljZTogJ2Rlc2t0b3AnIH0sXG4gICAgeyBpZDogJ2RlbW9fYzYnLCB0eXBlOiAnZXhwZW5zZScsIGFtb3VudDogNjUwMDAwLCBjYXRlZ29yeTogJ2JlbGFuamEnLCB3YWxsZXQ6ICdld2FsbGV0JywgZGF0ZTogZGF5KHltLCA0KSwgbm90ZTogJ0dyb2NlcmllcyAmIHBlcmxlbmdrYXBhbiBtYW5kaScsIGRldmljZTogJ2FuZHJvaWQnIH0sXG4gICAgeyBpZDogJ2RlbW9fYzcnLCB0eXBlOiAnZXhwZW5zZScsIGFtb3VudDogNDIwMDAwLCBjYXRlZ29yeTogJ21ha2FuJywgd2FsbGV0OiAnZXdhbGxldCcsIGRhdGU6IGRheSh5bSwgNSksIG5vdGU6ICdNYWthbiBzaWFuZyBrYW50b3IgbWluZ2d1IDEnLCBkZXZpY2U6ICdhbmRyb2lkJyB9LFxuICAgIHsgaWQ6ICdkZW1vX2M4JywgdHlwZTogJ2V4cGVuc2UnLCBhbW91bnQ6IDU1MDAwLCBjYXRlZ29yeTogJ2tvcGknLCB3YWxsZXQ6ICdld2FsbGV0JywgZGF0ZTogZGF5KHltLCA2KSwgbm90ZTogJ0tvcGkgc3VzdSArIHJvdGknLCBkZXZpY2U6ICdhbmRyb2lkJyB9LFxuICAgIHsgaWQ6ICdkZW1vX2M5JywgdHlwZTogJ2V4cGVuc2UnLCBhbW91bnQ6IDQ4MDAwLCBjYXRlZ29yeTogJ2tvcGknLCB3YWxsZXQ6ICdld2FsbGV0JywgZGF0ZTogZGF5KHltLCA4KSwgbm90ZTogJ0VzIGtvcGkgc29yZScsIGRldmljZTogJ2FuZHJvaWQnIH0sXG4gICAgeyBpZDogJ2RlbW9fYzEwJywgdHlwZTogJ2V4cGVuc2UnLCBhbW91bnQ6IDMxMDAwMCwgY2F0ZWdvcnk6ICd0cmFuc3BvcnQnLCB3YWxsZXQ6ICdld2FsbGV0JywgZGF0ZTogZGF5KHltLCA5KSwgbm90ZTogJ09qb2wgJiB0b2wgbWluZ2d1IDEtMicsIGRldmljZTogJ2FuZHJvaWQnIH0sXG4gICAgeyBpZDogJ2RlbW9fYzExJywgdHlwZTogJ2V4cGVuc2UnLCBhbW91bnQ6IDE4NTAwMCwgY2F0ZWdvcnk6ICdoaWJ1cmFuJywgd2FsbGV0OiAnYmFuaycsIGRhdGU6IGRheSh5bSwgMTApLCBub3RlOiAnU3RyZWFtaW5nICYgbXVzaWsnLCBkZXZpY2U6ICdkZXNrdG9wJyB9LFxuICAgIHsgaWQ6ICdkZW1vX2MxMicsIHR5cGU6ICdleHBlbnNlJywgYW1vdW50OiA0OTAwMDAsIGNhdGVnb3J5OiAnbWFrYW4nLCB3YWxsZXQ6ICd0dW5haScsIGRhdGU6IGRheSh5bSwgMTIpLCBub3RlOiAnTWFrYW4gbWFsYW0gJiB0cmFrdGlyJywgZGV2aWNlOiAnYW5kcm9pZCcgfSxcbiAgICB7IGlkOiAnZGVtb19jMTMnLCB0eXBlOiAnZXhwZW5zZScsIGFtb3VudDogNjUwMDAsIGNhdGVnb3J5OiAna29waScsIHdhbGxldDogJ2V3YWxsZXQnLCBkYXRlOiBkYXkoeW0sIDE0KSwgbm90ZTogJ0JvYmEgJiBjZW1pbGFuJywgZGV2aWNlOiAnYW5kcm9pZCcgfSxcbiAgICB7IGlkOiAnZGVtb19jMTQnLCB0eXBlOiAnZXhwZW5zZScsIGFtb3VudDogNDUwMDAsIGNhdGVnb3J5OiAna29waScsIHdhbGxldDogJ2V3YWxsZXQnLCBkYXRlOiBkYXkoeW0sIDE2KSwgbm90ZTogJ0tvcGkga2VuYW5nYW4nLCBkZXZpY2U6ICdhbmRyb2lkJyB9LFxuICAgIHsgaWQ6ICdkZW1vX2MxNScsIHR5cGU6ICdleHBlbnNlJywgYW1vdW50OiAyNzAwMDAsIGNhdGVnb3J5OiAndHJhbnNwb3J0Jywgd2FsbGV0OiAndHVuYWknLCBkYXRlOiBkYXkoeW0sIDE4KSwgbm90ZTogJ0lzaSBiZW5zaW4gJiBwYXJraXInLCBkZXZpY2U6ICdhbmRyb2lkJyB9LFxuICAgIHsgaWQ6ICdkZW1vX2MxNicsIHR5cGU6ICdleHBlbnNlJywgYW1vdW50OiAzODAwMDAsIGNhdGVnb3J5OiAnbWFrYW4nLCB3YWxsZXQ6ICdld2FsbGV0JywgZGF0ZTogZGF5KHltLCAyMCksIG5vdGU6ICdNYWthbiBzaWFuZyAmIHBlc2FuIGFudGFyJywgZGV2aWNlOiAnYW5kcm9pZCcgfSxcbiAgICB7IGlkOiAnZGVtb19jMTcnLCB0eXBlOiAnZXhwZW5zZScsIGFtb3VudDogMjk1MDAwLCBjYXRlZ29yeTogJ2hpYnVyYW4nLCB3YWxsZXQ6ICdld2FsbGV0JywgZGF0ZTogZGF5KHltLCAyMSksIG5vdGU6ICdOb250b24gYmlvc2tvcCB3ZWVrZW5kJywgZGV2aWNlOiAnYW5kcm9pZCcgfSxcbiAgICB7IGlkOiAnZGVtb19jMTgnLCB0eXBlOiAnZXhwZW5zZScsIGFtb3VudDogNzIwMDAsIGNhdGVnb3J5OiAna29waScsIHdhbGxldDogJ2V3YWxsZXQnLCBkYXRlOiBkYXkoeW0sIDIzKSwgbm90ZTogJ01hdGNoYSBsYXR0ZSAmIHBhc3RyeScsIGRldmljZTogJ2FuZHJvaWQnIH0sXG4gICAgeyBpZDogJ2RlbW9fYzE5JywgdHlwZTogJ2V4cGVuc2UnLCBhbW91bnQ6IDE1MDAwMDAsIGNhdGVnb3J5OiAndGFidW5nYW4nLCB3YWxsZXQ6ICdiYW5rJywgZGF0ZTogZGF5KHltLCAyNCksIG5vdGU6ICdBdXRvZGViaXQgdGFidW5nYW4gJiBSRFBVJywgZGV2aWNlOiAnZGVza3RvcCcgfVxuICBdO1xufVxuXG5mdW5jdGlvbiBzZWVkRGVtb0RhdGEod3NJZCwgcmVmRGF0ZSkge1xuICBjb25zdCB3cyA9IHN5bmNCYXRjaCh3c0lkLCB7IHRyYW5zYWN0aW9uczogYnVpbGREZW1vU2FtcGxlcyhyZWZEYXRlKSB9KTtcbiAgcmV0dXJuIHdzO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgREFUQV9ESVI6IERBVEFfRElSLFxuICBzYW5pdGl6ZVdvcmtzcGFjZUlkOiBzYW5pdGl6ZVdvcmtzcGFjZUlkLFxuICBoYXNoUGluOiBoYXNoUGluLFxuICBjcmVhdGVEZWZhdWx0V29ya3NwYWNlOiBjcmVhdGVEZWZhdWx0V29ya3NwYWNlLFxuICBub3JtYWxpemVUcmFuc2FjdGlvbjogbm9ybWFsaXplVHJhbnNhY3Rpb24sXG4gIGJ1aWxkRGVtb1NhbXBsZXM6IGJ1aWxkRGVtb1NhbXBsZXMsXG4gIHJlYWRXb3Jrc3BhY2U6IHJlYWRXb3Jrc3BhY2UsXG4gIHNhbml0aXplQ2xpZW50Vmlldzogc2FuaXRpemVDbGllbnRWaWV3LFxuICB1cHNlcnRUcmFuc2FjdGlvbjogdXBzZXJ0VHJhbnNhY3Rpb24sXG4gIGRlbGV0ZVRyYW5zYWN0aW9uOiBkZWxldGVUcmFuc2FjdGlvbixcbiAgc3luY0JhdGNoOiBzeW5jQmF0Y2gsXG4gIHVwZGF0ZVNldHRpbmdzOiB1cGRhdGVTZXR0aW5ncyxcbiAgc2VlZERlbW9EYXRhOiBzZWVkRGVtb0RhdGFcbn07XG4iLCAiJ3VzZSBzdHJpY3QnO1xuXG5jb25zdCB7IGdldERhdGFiYXNlIH0gPSByZXF1aXJlKCdAbmV0bGlmeS9kYXRhYmFzZScpO1xuY29uc3Qgc3RvcmFnZSA9IHJlcXVpcmUoJy4vc3RvcmFnZScpO1xuXG5sZXQgZGJJbnN0YW5jZSA9IG51bGw7XG5cbmZ1bmN0aW9uIGdldERiKCkge1xuICBpZiAoIWRiSW5zdGFuY2UpIHtcbiAgICBkYkluc3RhbmNlID0gZ2V0RGF0YWJhc2UoKTtcbiAgfVxuICByZXR1cm4gZGJJbnN0YW5jZTtcbn1cblxuZnVuY3Rpb24gbWFwVHhSb3cocm93KSB7XG4gIHJldHVybiB7XG4gICAgaWQ6IHJvdy5pZCxcbiAgICB0eXBlOiByb3cudHlwZSxcbiAgICBhbW91bnQ6IE51bWJlcihyb3cuYW1vdW50KSB8fCAwLFxuICAgIGNhdGVnb3J5OiByb3cuY2F0ZWdvcnksXG4gICAgd2FsbGV0OiByb3cud2FsbGV0LFxuICAgIHRvV2FsbGV0OiByb3cudG9fd2FsbGV0IHx8IHVuZGVmaW5lZCxcbiAgICBkYXRlOiByb3cudHhfZGF0ZSxcbiAgICBub3RlOiByb3cubm90ZSB8fCAnJyxcbiAgICBkZXZpY2U6IHJvdy5kZXZpY2UgfHwgJ3dlYicsXG4gICAgZGVsZXRlZDogQm9vbGVhbihyb3cuZGVsZXRlZCksXG4gICAgY3JlYXRlZEF0OiByb3cuY3JlYXRlZF9hdCxcbiAgICB1cGRhdGVkQXQ6IHJvdy51cGRhdGVkX2F0XG4gIH07XG59XG5cbmZ1bmN0aW9uIG1hcFdvcmtzcGFjZVJvdyhyb3csIHRyYW5zYWN0aW9ucykge1xuICBjb25zdCBkZWYgPSBzdG9yYWdlLmNyZWF0ZURlZmF1bHRXb3Jrc3BhY2Uocm93LndvcmtzcGFjZV9pZCk7XG4gIHJldHVybiB7XG4gICAgd29ya3NwYWNlSWQ6IHJvdy53b3Jrc3BhY2VfaWQsXG4gICAgcmV2aXNpb246IE51bWJlcihyb3cucmV2aXNpb24pIHx8IDEsXG4gICAgdXBkYXRlZEF0OiBuZXcgRGF0ZShyb3cudXBkYXRlZF9hdCkudG9JU09TdHJpbmcoKSxcbiAgICB0YXJnZXRTYXZpbmdzUmF0ZTogTnVtYmVyKHJvdy50YXJnZXRfc2F2aW5nc19yYXRlKSB8fCAyMCxcbiAgICBwaW5IYXNoOiByb3cucGluX2hhc2ggfHwgbnVsbCxcbiAgICBjYXRlZ29yaWVzOiBBcnJheS5pc0FycmF5KHJvdy5jYXRlZ29yaWVzKSAmJiByb3cuY2F0ZWdvcmllcy5sZW5ndGggPyByb3cuY2F0ZWdvcmllcyA6IGRlZi5jYXRlZ29yaWVzLFxuICAgIHdhbGxldHM6IEFycmF5LmlzQXJyYXkocm93LndhbGxldHMpICYmIHJvdy53YWxsZXRzLmxlbmd0aCA/IHJvdy53YWxsZXRzIDogZGVmLndhbGxldHMsXG4gICAgYnVkZ2V0czogcm93LmJ1ZGdldHMgJiYgdHlwZW9mIHJvdy5idWRnZXRzID09PSAnb2JqZWN0JyA/IHJvdy5idWRnZXRzIDoge30sXG4gICAgdHJhbnNhY3Rpb25zOiB0cmFuc2FjdGlvbnMgfHwgW11cbiAgfTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZW5zdXJlV29ya3NwYWNlUm93KGNsaWVudCwgd3NJZCwgbG9ja0ZvclVwZGF0ZSkge1xuICBjb25zdCBjbGVhbklkID0gc3RvcmFnZS5zYW5pdGl6ZVdvcmtzcGFjZUlkKHdzSWQpO1xuICBjb25zdCBkZWYgPSBzdG9yYWdlLmNyZWF0ZURlZmF1bHRXb3Jrc3BhY2UoY2xlYW5JZCk7XG5cbiAgYXdhaXQgY2xpZW50LnF1ZXJ5KFxuICAgIGBJTlNFUlQgSU5UTyB3b3Jrc3BhY2VzIChcbiAgICAgIHdvcmtzcGFjZV9pZCwgcmV2aXNpb24sIHVwZGF0ZWRfYXQsIHRhcmdldF9zYXZpbmdzX3JhdGUsIHBpbl9oYXNoLCBjYXRlZ29yaWVzLCB3YWxsZXRzLCBidWRnZXRzXG4gICAgKSBWQUxVRVMgKCQxLCAkMiwgJDMsICQ0LCAkNSwgJDY6Ompzb25iLCAkNzo6anNvbmIsICQ4Ojpqc29uYilcbiAgICBPTiBDT05GTElDVCAod29ya3NwYWNlX2lkKSBETyBOT1RISU5HYCxcbiAgICBbXG4gICAgICBjbGVhbklkLFxuICAgICAgZGVmLnJldmlzaW9uLFxuICAgICAgZGVmLnVwZGF0ZWRBdCxcbiAgICAgIGRlZi50YXJnZXRTYXZpbmdzUmF0ZSxcbiAgICAgIGRlZi5waW5IYXNoLFxuICAgICAgSlNPTi5zdHJpbmdpZnkoZGVmLmNhdGVnb3JpZXMpLFxuICAgICAgSlNPTi5zdHJpbmdpZnkoZGVmLndhbGxldHMpLFxuICAgICAgSlNPTi5zdHJpbmdpZnkoZGVmLmJ1ZGdldHMpXG4gICAgXVxuICApO1xuXG4gIGNvbnN0IHN1ZmZpeCA9IGxvY2tGb3JVcGRhdGUgPyAnIEZPUiBVUERBVEUnIDogJyc7XG4gIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5xdWVyeShcbiAgICBgU0VMRUNUIHdvcmtzcGFjZV9pZCwgcmV2aXNpb24sIHVwZGF0ZWRfYXQsIHRhcmdldF9zYXZpbmdzX3JhdGUsIHBpbl9oYXNoLCBjYXRlZ29yaWVzLCB3YWxsZXRzLCBidWRnZXRzXG4gICAgIEZST00gd29ya3NwYWNlcyBXSEVSRSB3b3Jrc3BhY2VfaWQgPSAkMSR7c3VmZml4fWAsXG4gICAgW2NsZWFuSWRdXG4gICk7XG4gIHJldHVybiByZXMucm93c1swXTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gbG9hZFdvcmtzcGFjZVdpdGhDbGllbnQoY2xpZW50LCB3c0lkKSB7XG4gIGNvbnN0IHdzUm93ID0gYXdhaXQgZW5zdXJlV29ya3NwYWNlUm93KGNsaWVudCwgd3NJZCwgZmFsc2UpO1xuICBjb25zdCB0eFJlcyA9IGF3YWl0IGNsaWVudC5xdWVyeShcbiAgICBgU0VMRUNUIGlkLCB0eXBlLCBhbW91bnQsIGNhdGVnb3J5LCB3YWxsZXQsIHRvX3dhbGxldCwgdHhfZGF0ZSwgbm90ZSwgZGV2aWNlLCBkZWxldGVkLCBjcmVhdGVkX2F0LCB1cGRhdGVkX2F0XG4gICAgIEZST00gdHJhbnNhY3Rpb25zXG4gICAgIFdIRVJFIHdvcmtzcGFjZV9pZCA9ICQxXG4gICAgIE9SREVSIEJZIHR4X2RhdGUgREVTQywgY3JlYXRlZF9hdCBERVNDYCxcbiAgICBbd3NSb3cud29ya3NwYWNlX2lkXVxuICApO1xuICByZXR1cm4gbWFwV29ya3NwYWNlUm93KHdzUm93LCB0eFJlcy5yb3dzLm1hcChtYXBUeFJvdykpO1xufVxuXG5hc3luYyBmdW5jdGlvbiB3aXRoVHJhbnNhY3Rpb24oZm4pIHtcbiAgY29uc3QgZGIgPSBnZXREYigpO1xuICBjb25zdCBjbGllbnQgPSBhd2FpdCBkYi5wb29sLmNvbm5lY3QoKTtcbiAgdHJ5IHtcbiAgICBhd2FpdCBjbGllbnQucXVlcnkoJ0JFR0lOJyk7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZm4oY2xpZW50KTtcbiAgICBhd2FpdCBjbGllbnQucXVlcnkoJ0NPTU1JVCcpO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGF3YWl0IGNsaWVudC5xdWVyeSgnUk9MTEJBQ0snKTtcbiAgICB0aHJvdyBlcnI7XG4gIH0gZmluYWxseSB7XG4gICAgY2xpZW50LnJlbGVhc2UoKTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiB1cHNlcnRUeFJvdyhjbGllbnQsIHdzSWQsIHR4KSB7XG4gIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5xdWVyeShcbiAgICBgSU5TRVJUIElOVE8gdHJhbnNhY3Rpb25zIChcbiAgICAgIHdvcmtzcGFjZV9pZCwgaWQsIHR5cGUsIGFtb3VudCwgY2F0ZWdvcnksIHdhbGxldCwgdG9fd2FsbGV0LFxuICAgICAgdHhfZGF0ZSwgbm90ZSwgZGV2aWNlLCBkZWxldGVkLCBjcmVhdGVkX2F0LCB1cGRhdGVkX2F0XG4gICAgKSBWQUxVRVMgKCQxLCAkMiwgJDMsICQ0LCAkNSwgJDYsICQ3LCAkOCwgJDksICQxMCwgJDExLCAkMTIsICQxMylcbiAgICBPTiBDT05GTElDVCAod29ya3NwYWNlX2lkLCBpZCkgRE8gVVBEQVRFIFNFVFxuICAgICAgdHlwZSA9IEVYQ0xVREVELnR5cGUsXG4gICAgICBhbW91bnQgPSBFWENMVURFRC5hbW91bnQsXG4gICAgICBjYXRlZ29yeSA9IEVYQ0xVREVELmNhdGVnb3J5LFxuICAgICAgd2FsbGV0ID0gRVhDTFVERUQud2FsbGV0LFxuICAgICAgdG9fd2FsbGV0ID0gRVhDTFVERUQudG9fd2FsbGV0LFxuICAgICAgdHhfZGF0ZSA9IEVYQ0xVREVELnR4X2RhdGUsXG4gICAgICBub3RlID0gRVhDTFVERUQubm90ZSxcbiAgICAgIGRldmljZSA9IEVYQ0xVREVELmRldmljZSxcbiAgICAgIGRlbGV0ZWQgPSBFWENMVURFRC5kZWxldGVkLFxuICAgICAgdXBkYXRlZF9hdCA9IEVYQ0xVREVELnVwZGF0ZWRfYXRcbiAgICBXSEVSRSB0cmFuc2FjdGlvbnMudXBkYXRlZF9hdCA8IEVYQ0xVREVELnVwZGF0ZWRfYXRgLFxuICAgIFtcbiAgICAgIHdzSWQsXG4gICAgICB0eC5pZCxcbiAgICAgIHR4LnR5cGUsXG4gICAgICB0eC5hbW91bnQsXG4gICAgICB0eC5jYXRlZ29yeSxcbiAgICAgIHR4LndhbGxldCxcbiAgICAgIHR4LnRvV2FsbGV0IHx8IG51bGwsXG4gICAgICB0eC5kYXRlLFxuICAgICAgdHgubm90ZSxcbiAgICAgIHR4LmRldmljZSxcbiAgICAgIHR4LmRlbGV0ZWQsXG4gICAgICB0eC5jcmVhdGVkQXQsXG4gICAgICB0eC51cGRhdGVkQXRcbiAgICBdXG4gICk7XG4gIHJldHVybiByZXMucm93Q291bnQgPiAwO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWFkV29ya3NwYWNlTWV0YSh3c0lkKSB7XG4gIGNvbnN0IGRiID0gZ2V0RGIoKTtcbiAgY29uc3QgY2xpZW50ID0gYXdhaXQgZGIucG9vbC5jb25uZWN0KCk7XG4gIHRyeSB7XG4gICAgY29uc3Qgcm93ID0gYXdhaXQgZW5zdXJlV29ya3NwYWNlUm93KGNsaWVudCwgd3NJZCwgZmFsc2UpO1xuICAgIHJldHVybiBtYXBXb3Jrc3BhY2VSb3cocm93LCBbXSk7XG4gIH0gZmluYWxseSB7XG4gICAgY2xpZW50LnJlbGVhc2UoKTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiByZWFkV29ya3NwYWNlKHdzSWQpIHtcbiAgY29uc3QgZGIgPSBnZXREYigpO1xuICBjb25zdCBjbGllbnQgPSBhd2FpdCBkYi5wb29sLmNvbm5lY3QoKTtcbiAgdHJ5IHtcbiAgICByZXR1cm4gYXdhaXQgbG9hZFdvcmtzcGFjZVdpdGhDbGllbnQoY2xpZW50LCB3c0lkKTtcbiAgfSBmaW5hbGx5IHtcbiAgICBjbGllbnQucmVsZWFzZSgpO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHVwc2VydFRyYW5zYWN0aW9uKHdzSWQsIHR4SW5wdXQpIHtcbiAgY29uc3QgY2xlYW5JZCA9IHN0b3JhZ2Uuc2FuaXRpemVXb3Jrc3BhY2VJZCh3c0lkKTtcbiAgY29uc3Qgbm93SXNvID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICBjb25zdCB0eCA9IHN0b3JhZ2Uubm9ybWFsaXplVHJhbnNhY3Rpb24oT2JqZWN0LmFzc2lnbih7fSwgdHhJbnB1dCwgeyB1cGRhdGVkQXQ6IG5vd0lzbyB9KSk7XG5cbiAgcmV0dXJuIHdpdGhUcmFuc2FjdGlvbihhc3luYyBmdW5jdGlvbiAoY2xpZW50KSB7XG4gICAgY29uc3Qgd3NSb3cgPSBhd2FpdCBlbnN1cmVXb3Jrc3BhY2VSb3coY2xpZW50LCBjbGVhbklkLCB0cnVlKTtcbiAgICBhd2FpdCB1cHNlcnRUeFJvdyhjbGllbnQsIGNsZWFuSWQsIHR4KTtcbiAgICBjb25zdCBuZXh0UmV2ID0gTnVtYmVyKHdzUm93LnJldmlzaW9uKSArIDE7XG4gICAgYXdhaXQgY2xpZW50LnF1ZXJ5KFxuICAgICAgYFVQREFURSB3b3Jrc3BhY2VzIFNFVCByZXZpc2lvbiA9ICQyLCB1cGRhdGVkX2F0ID0gJDMgV0hFUkUgd29ya3NwYWNlX2lkID0gJDFgLFxuICAgICAgW2NsZWFuSWQsIG5leHRSZXYsIG5vd0lzb11cbiAgICApO1xuICAgIHdzUm93LnJldmlzaW9uID0gbmV4dFJldjtcbiAgICB3c1Jvdy51cGRhdGVkX2F0ID0gbm93SXNvO1xuICAgIHJldHVybiB7IHdvcmtzcGFjZTogbWFwV29ya3NwYWNlUm93KHdzUm93LCBbXSksIHRyYW5zYWN0aW9uOiB0eCB9O1xuICB9KTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZGVsZXRlVHJhbnNhY3Rpb24od3NJZCwgdHhJZCkge1xuICBjb25zdCBjbGVhbklkID0gc3RvcmFnZS5zYW5pdGl6ZVdvcmtzcGFjZUlkKHdzSWQpO1xuICBjb25zdCBub3dJc28gPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG5cbiAgcmV0dXJuIHdpdGhUcmFuc2FjdGlvbihhc3luYyBmdW5jdGlvbiAoY2xpZW50KSB7XG4gICAgY29uc3Qgd3NSb3cgPSBhd2FpdCBlbnN1cmVXb3Jrc3BhY2VSb3coY2xpZW50LCBjbGVhbklkLCB0cnVlKTtcbiAgICBjb25zdCBkZWxSZXMgPSBhd2FpdCBjbGllbnQucXVlcnkoXG4gICAgICBgVVBEQVRFIHRyYW5zYWN0aW9uc1xuICAgICAgIFNFVCBkZWxldGVkID0gVFJVRSwgdXBkYXRlZF9hdCA9ICQzXG4gICAgICAgV0hFUkUgd29ya3NwYWNlX2lkID0gJDEgQU5EIGlkID0gJDIgQU5EIGRlbGV0ZWQgPSBGQUxTRWAsXG4gICAgICBbY2xlYW5JZCwgdHhJZCwgbm93SXNvXVxuICAgICk7XG4gICAgY29uc3QgZGVsZXRlZCA9IGRlbFJlcy5yb3dDb3VudCA+IDA7XG4gICAgaWYgKGRlbGV0ZWQpIHtcbiAgICAgIGNvbnN0IG5leHRSZXYgPSBOdW1iZXIod3NSb3cucmV2aXNpb24pICsgMTtcbiAgICAgIGF3YWl0IGNsaWVudC5xdWVyeShcbiAgICAgICAgYFVQREFURSB3b3Jrc3BhY2VzIFNFVCByZXZpc2lvbiA9ICQyLCB1cGRhdGVkX2F0ID0gJDMgV0hFUkUgd29ya3NwYWNlX2lkID0gJDFgLFxuICAgICAgICBbY2xlYW5JZCwgbmV4dFJldiwgbm93SXNvXVxuICAgICAgKTtcbiAgICAgIHdzUm93LnJldmlzaW9uID0gbmV4dFJldjtcbiAgICAgIHdzUm93LnVwZGF0ZWRfYXQgPSBub3dJc287XG4gICAgfVxuICAgIHJldHVybiB7IHdvcmtzcGFjZTogbWFwV29ya3NwYWNlUm93KHdzUm93LCBbXSksIGRlbGV0ZWQ6IGRlbGV0ZWQgfTtcbiAgfSk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHN5bmNCYXRjaCh3c0lkLCBwYXlsb2FkKSB7XG4gIGNvbnN0IGNsZWFuSWQgPSBzdG9yYWdlLnNhbml0aXplV29ya3NwYWNlSWQod3NJZCk7XG4gIGNvbnN0IG5vd0lzbyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgY29uc3QgaW5jb21pbmdUeCA9IEFycmF5LmlzQXJyYXkocGF5bG9hZC50cmFuc2FjdGlvbnMpID8gcGF5bG9hZC50cmFuc2FjdGlvbnMgOiBbXTtcblxuICByZXR1cm4gd2l0aFRyYW5zYWN0aW9uKGFzeW5jIGZ1bmN0aW9uIChjbGllbnQpIHtcbiAgICBjb25zdCB3c1JvdyA9IGF3YWl0IGVuc3VyZVdvcmtzcGFjZVJvdyhjbGllbnQsIGNsZWFuSWQsIHRydWUpO1xuICAgIGNvbnN0IGN1cnJlbnQgPSBtYXBXb3Jrc3BhY2VSb3cod3NSb3csIFtdKTtcbiAgICBsZXQgY2hhbmdlZCA9IGZhbHNlO1xuXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbmNvbWluZ1R4Lmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBub3JtID0gc3RvcmFnZS5ub3JtYWxpemVUcmFuc2FjdGlvbihpbmNvbWluZ1R4W2ldKTtcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCB1cHNlcnRUeFJvdyhjbGllbnQsIGNsZWFuSWQsIG5vcm0pO1xuICAgICAgaWYgKHVwZGF0ZWQpIGNoYW5nZWQgPSB0cnVlO1xuICAgIH1cblxuICAgIGxldCBtZXRhQ2hhbmdlZCA9IGZhbHNlO1xuICAgIGlmIChwYXlsb2FkLmJ1ZGdldHMgJiYgdHlwZW9mIHBheWxvYWQuYnVkZ2V0cyA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGN1cnJlbnQuYnVkZ2V0cyA9IE9iamVjdC5hc3NpZ24oe30sIGN1cnJlbnQuYnVkZ2V0cywgcGF5bG9hZC5idWRnZXRzKTtcbiAgICAgIG1ldGFDaGFuZ2VkID0gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQudGFyZ2V0U2F2aW5nc1JhdGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgY3VycmVudC50YXJnZXRTYXZpbmdzUmF0ZSA9IE1hdGgubWF4KDEsIE1hdGgubWluKDgwLCBOdW1iZXIocGF5bG9hZC50YXJnZXRTYXZpbmdzUmF0ZSkgfHwgMjApKTtcbiAgICAgIG1ldGFDaGFuZ2VkID0gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKEFycmF5LmlzQXJyYXkocGF5bG9hZC53YWxsZXRzKSAmJiBwYXlsb2FkLndhbGxldHMubGVuZ3RoID4gMCkge1xuICAgICAgY3VycmVudC53YWxsZXRzID0gcGF5bG9hZC53YWxsZXRzO1xuICAgICAgbWV0YUNoYW5nZWQgPSB0cnVlO1xuICAgIH1cblxuICAgIGlmIChjaGFuZ2VkIHx8IG1ldGFDaGFuZ2VkKSB7XG4gICAgICBjb25zdCBuZXh0UmV2ID0gY3VycmVudC5yZXZpc2lvbiArIDE7XG4gICAgICBhd2FpdCBjbGllbnQucXVlcnkoXG4gICAgICAgIGBVUERBVEUgd29ya3NwYWNlc1xuICAgICAgICAgU0VUIHJldmlzaW9uID0gJDIsIHVwZGF0ZWRfYXQgPSAkMywgdGFyZ2V0X3NhdmluZ3NfcmF0ZSA9ICQ0LCB3YWxsZXRzID0gJDU6Ompzb25iLCBidWRnZXRzID0gJDY6Ompzb25iXG4gICAgICAgICBXSEVSRSB3b3Jrc3BhY2VfaWQgPSAkMWAsXG4gICAgICAgIFtcbiAgICAgICAgICBjbGVhbklkLFxuICAgICAgICAgIG5leHRSZXYsXG4gICAgICAgICAgbm93SXNvLFxuICAgICAgICAgIGN1cnJlbnQudGFyZ2V0U2F2aW5nc1JhdGUsXG4gICAgICAgICAgSlNPTi5zdHJpbmdpZnkoY3VycmVudC53YWxsZXRzKSxcbiAgICAgICAgICBKU09OLnN0cmluZ2lmeShjdXJyZW50LmJ1ZGdldHMpXG4gICAgICAgIF1cbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGxvYWRXb3Jrc3BhY2VXaXRoQ2xpZW50KGNsaWVudCwgY2xlYW5JZCk7XG4gIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiB1cGRhdGVTZXR0aW5ncyh3c0lkLCBwYXlsb2FkKSB7XG4gIGNvbnN0IGNsZWFuSWQgPSBzdG9yYWdlLnNhbml0aXplV29ya3NwYWNlSWQod3NJZCk7XG4gIGNvbnN0IG5vd0lzbyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICByZXR1cm4gd2l0aFRyYW5zYWN0aW9uKGFzeW5jIGZ1bmN0aW9uIChjbGllbnQpIHtcbiAgICBjb25zdCB3c1JvdyA9IGF3YWl0IGVuc3VyZVdvcmtzcGFjZVJvdyhjbGllbnQsIGNsZWFuSWQsIHRydWUpO1xuICAgIGNvbnN0IGN1cnJlbnQgPSBtYXBXb3Jrc3BhY2VSb3cod3NSb3csIFtdKTtcblxuICAgIGlmIChwYXlsb2FkLmJ1ZGdldHMgJiYgdHlwZW9mIHBheWxvYWQuYnVkZ2V0cyA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGNvbnN0IGNsZWFuQnVkZ2V0cyA9IHt9O1xuICAgICAgT2JqZWN0LmtleXMocGF5bG9hZC5idWRnZXRzKS5mb3JFYWNoKGZ1bmN0aW9uIChrKSB7XG4gICAgICAgIGNvbnN0IHYgPSBNYXRoLm1heCgwLCBNYXRoLnJvdW5kKE51bWJlcihwYXlsb2FkLmJ1ZGdldHNba10pIHx8IDApKTtcbiAgICAgICAgaWYgKHYgPiAwKSBjbGVhbkJ1ZGdldHNba10gPSB2O1xuICAgICAgfSk7XG4gICAgICBjdXJyZW50LmJ1ZGdldHMgPSBjbGVhbkJ1ZGdldHM7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnRhcmdldFNhdmluZ3NSYXRlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGN1cnJlbnQudGFyZ2V0U2F2aW5nc1JhdGUgPSBNYXRoLm1heCgxLCBNYXRoLm1pbig4MCwgTnVtYmVyKHBheWxvYWQudGFyZ2V0U2F2aW5nc1JhdGUpIHx8IDIwKSk7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KHBheWxvYWQud2FsbGV0cykgJiYgcGF5bG9hZC53YWxsZXRzLmxlbmd0aCA+IDApIHtcbiAgICAgIGN1cnJlbnQud2FsbGV0cyA9IHBheWxvYWQud2FsbGV0cy5tYXAoZnVuY3Rpb24gKHcpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBpZDogU3RyaW5nKHcuaWQgfHwgJ3dhbGxldCcpLnNsaWNlKDAsIDMyKSxcbiAgICAgICAgICBuYW1lOiBTdHJpbmcody5uYW1lIHx8ICdEb21wZXQnKS5zbGljZSgwLCA0MCksXG4gICAgICAgICAgaWNvbjogU3RyaW5nKHcuaWNvbiB8fCAnXHVEODNEXHVEQ0IzJykuc2xpY2UoMCwgOCksXG4gICAgICAgICAgaW5pdGlhbEJhbGFuY2U6IE51bWJlcih3LmluaXRpYWxCYWxhbmNlKSB8fCAwXG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQubmV3UGluICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGN1cnJlbnQucGluSGFzaCA9IHBheWxvYWQubmV3UGluID8gc3RvcmFnZS5oYXNoUGluKHBheWxvYWQubmV3UGluKSA6IG51bGw7XG4gICAgfVxuXG4gICAgY29uc3QgbmV4dFJldiA9IGN1cnJlbnQucmV2aXNpb24gKyAxO1xuICAgIGF3YWl0IGNsaWVudC5xdWVyeShcbiAgICAgIGBVUERBVEUgd29ya3NwYWNlc1xuICAgICAgIFNFVCByZXZpc2lvbiA9ICQyLCB1cGRhdGVkX2F0ID0gJDMsIHRhcmdldF9zYXZpbmdzX3JhdGUgPSAkNCwgcGluX2hhc2ggPSAkNSwgd2FsbGV0cyA9ICQ2Ojpqc29uYiwgYnVkZ2V0cyA9ICQ3Ojpqc29uYlxuICAgICAgIFdIRVJFIHdvcmtzcGFjZV9pZCA9ICQxYCxcbiAgICAgIFtcbiAgICAgICAgY2xlYW5JZCxcbiAgICAgICAgbmV4dFJldixcbiAgICAgICAgbm93SXNvLFxuICAgICAgICBjdXJyZW50LnRhcmdldFNhdmluZ3NSYXRlLFxuICAgICAgICBjdXJyZW50LnBpbkhhc2gsXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KGN1cnJlbnQud2FsbGV0cyksXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KGN1cnJlbnQuYnVkZ2V0cylcbiAgICAgIF1cbiAgICApO1xuXG4gICAgcmV0dXJuIGxvYWRXb3Jrc3BhY2VXaXRoQ2xpZW50KGNsaWVudCwgY2xlYW5JZCk7XG4gIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZWVkRGVtb0RhdGEod3NJZCwgcmVmRGF0ZSkge1xuICByZXR1cm4gc3luY0JhdGNoKHdzSWQsIHsgdHJhbnNhY3Rpb25zOiBzdG9yYWdlLmJ1aWxkRGVtb1NhbXBsZXMocmVmRGF0ZSkgfSk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICByZWFkV29ya3NwYWNlTWV0YTogcmVhZFdvcmtzcGFjZU1ldGEsXG4gIHJlYWRXb3Jrc3BhY2U6IHJlYWRXb3Jrc3BhY2UsXG4gIHVwc2VydFRyYW5zYWN0aW9uOiB1cHNlcnRUcmFuc2FjdGlvbixcbiAgZGVsZXRlVHJhbnNhY3Rpb246IGRlbGV0ZVRyYW5zYWN0aW9uLFxuICBzeW5jQmF0Y2g6IHN5bmNCYXRjaCxcbiAgdXBkYXRlU2V0dGluZ3M6IHVwZGF0ZVNldHRpbmdzLFxuICBzZWVkRGVtb0RhdGE6IHNlZWREZW1vRGF0YVxufTtcbiIsICJpbXBvcnQgdHlwZSB7IENvbmZpZyB9IGZyb20gXCJAbmV0bGlmeS9mdW5jdGlvbnNcIjtcbmltcG9ydCBzdG9yYWdlIGZyb20gXCIuLi8uLi9zcmMvc3RvcmFnZS5qc1wiO1xuaW1wb3J0IHBnU3RvcmFnZSBmcm9tIFwiLi4vLi4vc3JjL3BnLXN0b3JhZ2UuanNcIjtcbmltcG9ydCBhbmFseXRpY3MgZnJvbSBcIi4uLy4uL3NyYy9hbmFseXRpY3MuanNcIjtcblxuZnVuY3Rpb24ganNvblJlc3BvbnNlKHN0YXR1czogbnVtYmVyLCBib2R5OiB1bmtub3duKTogUmVzcG9uc2Uge1xuICByZXR1cm4gbmV3IFJlc3BvbnNlKEpTT04uc3RyaW5naWZ5KGJvZHkpLCB7XG4gICAgc3RhdHVzLFxuICAgIGhlYWRlcnM6IHtcbiAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOFwiLFxuICAgICAgXCJDYWNoZS1Db250cm9sXCI6IFwibm8tc3RvcmVcIixcbiAgICB9LFxuICB9KTtcbn1cblxuZnVuY3Rpb24gY2hlY2tQaW4od3M6IHsgcGluSGFzaDogc3RyaW5nIHwgbnVsbCB9LCByZXE6IFJlcXVlc3QsIHVybDogVVJMKTogYm9vbGVhbiB7XG4gIGlmICghd3MucGluSGFzaCkgcmV0dXJuIHRydWU7XG4gIGNvbnN0IHBpbiA9IHJlcS5oZWFkZXJzLmdldChcIngtd29ya3NwYWNlLXBpblwiKSB8fCB1cmwuc2VhcmNoUGFyYW1zLmdldChcInBpblwiKSB8fCBcIlwiO1xuICByZXR1cm4gc3RvcmFnZS5oYXNoUGluKHBpbikgPT09IHdzLnBpbkhhc2g7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHBhcnNlSnNvbkJvZHkocmVxOiBSZXF1ZXN0KTogUHJvbWlzZTxSZWNvcmQ8c3RyaW5nLCB1bmtub3duPj4ge1xuICBjb25zdCByYXcgPSBhd2FpdCByZXEudGV4dCgpO1xuICBpZiAoIXJhdykgcmV0dXJuIHt9O1xuICBpZiAocmF3Lmxlbmd0aCA+IDIgKiAxMDI0ICogMTAyNCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIlBheWxvYWQgdG9vIGxhcmdlXCIpO1xuICB9XG4gIHRyeSB7XG4gICAgcmV0dXJuIEpTT04ucGFyc2UocmF3KTtcbiAgfSBjYXRjaCB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBKU09OIGJvZHlcIik7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgKHJlcTogUmVxdWVzdCk6IFByb21pc2U8UmVzcG9uc2U+ID0+IHtcbiAgY29uc3QgdXJsID0gbmV3IFVSTChyZXEudXJsKTtcbiAgY29uc3QgcGF0aG5hbWUgPSB1cmwucGF0aG5hbWU7XG4gIGNvbnN0IHdzSWQgPSBzdG9yYWdlLnNhbml0aXplV29ya3NwYWNlSWQodXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJ3c1wiKSB8fCBcInByaWJhZGlcIik7XG5cbiAgdHJ5IHtcbiAgICBpZiAocGF0aG5hbWUgPT09IFwiL2FwaS9oZWFsdGhcIiAmJiByZXEubWV0aG9kID09PSBcIkdFVFwiKSB7XG4gICAgICByZXR1cm4ganNvblJlc3BvbnNlKDIwMCwge1xuICAgICAgICBvazogdHJ1ZSxcbiAgICAgICAgc2VydmljZTogXCJ1YW5na3UtdHJhY2tlclwiLFxuICAgICAgICBydW50aW1lOiBcIm5ldGxpZnktZnVuY3Rpb25zXCIsXG4gICAgICAgIHRpbWU6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgbGFuVXJsczogW10sXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAocGF0aG5hbWUgPT09IFwiL2FwaS9ldmVudHNcIiAmJiByZXEubWV0aG9kID09PSBcIkdFVFwiKSB7XG4gICAgICBjb25zdCB3cyA9IGF3YWl0IHBnU3RvcmFnZS5yZWFkV29ya3NwYWNlTWV0YSh3c0lkKTtcbiAgICAgIGlmICghY2hlY2tQaW4od3MsIHJlcSwgdXJsKSkge1xuICAgICAgICByZXR1cm4ganNvblJlc3BvbnNlKDQwMSwgeyBlcnJvcjogXCJQSU4gd29ya3NwYWNlIHNhbGFoIGF0YXUgZGlwZXJsdWthblwiLCByZXF1aXJlc1BpbjogdHJ1ZSB9KTtcbiAgICAgIH1cbiAgICAgIC8vIFNlcnZlcmxlc3MgZnVuY3Rpb25zIGRvIG5vdCBob2xkIHBlcnNpc3RlbnQgU1NFIHN0cmVhbXM7IDIwNCB0ZWxscyBFdmVudFNvdXJjZSB0byBzdG9wIHJldHJ5aW5nXG4gICAgICAvLyBzbyB0aGUgY2xpZW50IHNlYW1sZXNzbHkgdXNlcyAyMHMgQ2xvdWQgU3luYyBwb2xsaW5nLlxuICAgICAgcmV0dXJuIG5ldyBSZXNwb25zZShudWxsLCB7XG4gICAgICAgIHN0YXR1czogMjA0LFxuICAgICAgICBoZWFkZXJzOiB7IFwiQ2FjaGUtQ29udHJvbFwiOiBcIm5vLXN0b3JlXCIgfSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlmIChwYXRobmFtZSA9PT0gXCIvYXBpL3dvcmtzcGFjZVwiICYmIHJlcS5tZXRob2QgPT09IFwiR0VUXCIpIHtcbiAgICAgIGNvbnN0IHdzID0gYXdhaXQgcGdTdG9yYWdlLnJlYWRXb3Jrc3BhY2Uod3NJZCk7XG4gICAgICBpZiAoIWNoZWNrUGluKHdzLCByZXEsIHVybCkpIHtcbiAgICAgICAgcmV0dXJuIGpzb25SZXNwb25zZSg0MDEsIHsgZXJyb3I6IFwiUElOIHdvcmtzcGFjZSBzYWxhaCBhdGF1IGRpcGVybHVrYW5cIiwgcmVxdWlyZXNQaW46IHRydWUgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBtb250aCA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwibW9udGhcIikgfHwgXCJcIjtcbiAgICAgIGNvbnN0IHZpZXcgPSBzdG9yYWdlLnNhbml0aXplQ2xpZW50Vmlldyh3cykgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgICB2aWV3LnJlcG9ydCA9IGFuYWx5dGljcy5hbmFseXplTW9udGgod3MsIG1vbnRoKTtcbiAgICAgIHJldHVybiBqc29uUmVzcG9uc2UoMjAwLCB2aWV3KTtcbiAgICB9XG5cbiAgICBpZiAocGF0aG5hbWUgPT09IFwiL2FwaS9yZWNhcFwiICYmIHJlcS5tZXRob2QgPT09IFwiR0VUXCIpIHtcbiAgICAgIGNvbnN0IHdzID0gYXdhaXQgcGdTdG9yYWdlLnJlYWRXb3Jrc3BhY2Uod3NJZCk7XG4gICAgICBpZiAoIWNoZWNrUGluKHdzLCByZXEsIHVybCkpIHtcbiAgICAgICAgcmV0dXJuIGpzb25SZXNwb25zZSg0MDEsIHsgZXJyb3I6IFwiUElOIHdvcmtzcGFjZSBzYWxhaCBhdGF1IGRpcGVybHVrYW5cIiwgcmVxdWlyZXNQaW46IHRydWUgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBtb250aCA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwibW9udGhcIikgfHwgXCJcIjtcbiAgICAgIGNvbnN0IGZvcm1hdCA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KFwiZm9ybWF0XCIpIHx8IFwianNvblwiO1xuICAgICAgY29uc3QgcmVwb3J0ID0gYW5hbHl0aWNzLmFuYWx5emVNb250aCh3cywgbW9udGgpO1xuICAgICAgaWYgKGZvcm1hdCA9PT0gXCJtZFwiIHx8IGZvcm1hdCA9PT0gXCJtYXJrZG93blwiKSB7XG4gICAgICAgIHJldHVybiBuZXcgUmVzcG9uc2UoYW5hbHl0aWNzLnJlbmRlck1hcmtkb3duUmVjYXAocmVwb3J0KSwge1xuICAgICAgICAgIHN0YXR1czogMjAwLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwidGV4dC9tYXJrZG93bjsgY2hhcnNldD11dGYtOFwiLFxuICAgICAgICAgICAgXCJDYWNoZS1Db250cm9sXCI6IFwibm8tc3RvcmVcIixcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBqc29uUmVzcG9uc2UoMjAwLCByZXBvcnQpO1xuICAgIH1cblxuICAgIGlmIChwYXRobmFtZSA9PT0gXCIvYXBpL3RyYW5zYWN0aW9uc1wiICYmIHJlcS5tZXRob2QgPT09IFwiUE9TVFwiKSB7XG4gICAgICBjb25zdCB3c0NoZWNrID0gYXdhaXQgcGdTdG9yYWdlLnJlYWRXb3Jrc3BhY2VNZXRhKHdzSWQpO1xuICAgICAgaWYgKCFjaGVja1Bpbih3c0NoZWNrLCByZXEsIHVybCkpIHtcbiAgICAgICAgcmV0dXJuIGpzb25SZXNwb25zZSg0MDEsIHsgZXJyb3I6IFwiUElOIHdvcmtzcGFjZSBzYWxhaCBhdGF1IGRpcGVybHVrYW5cIiwgcmVxdWlyZXNQaW46IHRydWUgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBib2R5ID0gYXdhaXQgcGFyc2VKc29uQm9keShyZXEpO1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcGdTdG9yYWdlLnVwc2VydFRyYW5zYWN0aW9uKHdzSWQsIGJvZHkpO1xuICAgICAgcmV0dXJuIGpzb25SZXNwb25zZSgyMDAsIHtcbiAgICAgICAgb2s6IHRydWUsXG4gICAgICAgIHRyYW5zYWN0aW9uOiByZXN1bHQudHJhbnNhY3Rpb24sXG4gICAgICAgIHJldmlzaW9uOiByZXN1bHQud29ya3NwYWNlLnJldmlzaW9uLFxuICAgICAgICB1cGRhdGVkQXQ6IHJlc3VsdC53b3Jrc3BhY2UudXBkYXRlZEF0LFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgaWYgKHBhdGhuYW1lLnN0YXJ0c1dpdGgoXCIvYXBpL3RyYW5zYWN0aW9ucy9cIikgJiYgcmVxLm1ldGhvZCA9PT0gXCJERUxFVEVcIikge1xuICAgICAgY29uc3Qgd3NDaGVjayA9IGF3YWl0IHBnU3RvcmFnZS5yZWFkV29ya3NwYWNlTWV0YSh3c0lkKTtcbiAgICAgIGlmICghY2hlY2tQaW4od3NDaGVjaywgcmVxLCB1cmwpKSB7XG4gICAgICAgIHJldHVybiBqc29uUmVzcG9uc2UoNDAxLCB7IGVycm9yOiBcIlBJTiB3b3Jrc3BhY2Ugc2FsYWggYXRhdSBkaXBlcmx1a2FuXCIsIHJlcXVpcmVzUGluOiB0cnVlIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgdHhJZCA9IGRlY29kZVVSSUNvbXBvbmVudChwYXRobmFtZS5zbGljZShcIi9hcGkvdHJhbnNhY3Rpb25zL1wiLmxlbmd0aCkpO1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcGdTdG9yYWdlLmRlbGV0ZVRyYW5zYWN0aW9uKHdzSWQsIHR4SWQpO1xuICAgICAgcmV0dXJuIGpzb25SZXNwb25zZSgyMDAsIHtcbiAgICAgICAgb2s6IHRydWUsXG4gICAgICAgIGRlbGV0ZWQ6IHJlc3VsdC5kZWxldGVkLFxuICAgICAgICByZXZpc2lvbjogcmVzdWx0LndvcmtzcGFjZS5yZXZpc2lvbixcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGlmIChwYXRobmFtZSA9PT0gXCIvYXBpL3N5bmNcIiAmJiByZXEubWV0aG9kID09PSBcIlBPU1RcIikge1xuICAgICAgY29uc3Qgd3NDaGVjayA9IGF3YWl0IHBnU3RvcmFnZS5yZWFkV29ya3NwYWNlTWV0YSh3c0lkKTtcbiAgICAgIGlmICghY2hlY2tQaW4od3NDaGVjaywgcmVxLCB1cmwpKSB7XG4gICAgICAgIHJldHVybiBqc29uUmVzcG9uc2UoNDAxLCB7IGVycm9yOiBcIlBJTiB3b3Jrc3BhY2Ugc2FsYWggYXRhdSBkaXBlcmx1a2FuXCIsIHJlcXVpcmVzUGluOiB0cnVlIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgYm9keSA9IGF3YWl0IHBhcnNlSnNvbkJvZHkocmVxKTtcbiAgICAgIGNvbnN0IHdzID0gYXdhaXQgcGdTdG9yYWdlLnN5bmNCYXRjaCh3c0lkLCBib2R5KTtcbiAgICAgIGNvbnN0IG1vbnRoID0gdXJsLnNlYXJjaFBhcmFtcy5nZXQoXCJtb250aFwiKSB8fCBcIlwiO1xuICAgICAgY29uc3QgdmlldyA9IHN0b3JhZ2Uuc2FuaXRpemVDbGllbnRWaWV3KHdzKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIHZpZXcucmVwb3J0ID0gYW5hbHl0aWNzLmFuYWx5emVNb250aCh3cywgbW9udGgpO1xuICAgICAgcmV0dXJuIGpzb25SZXNwb25zZSgyMDAsIHZpZXcpO1xuICAgIH1cblxuICAgIGlmIChwYXRobmFtZSA9PT0gXCIvYXBpL3NldHRpbmdzXCIgJiYgcmVxLm1ldGhvZCA9PT0gXCJQT1NUXCIpIHtcbiAgICAgIGNvbnN0IHdzQ2hlY2sgPSBhd2FpdCBwZ1N0b3JhZ2UucmVhZFdvcmtzcGFjZU1ldGEod3NJZCk7XG4gICAgICBpZiAoIWNoZWNrUGluKHdzQ2hlY2ssIHJlcSwgdXJsKSkge1xuICAgICAgICByZXR1cm4ganNvblJlc3BvbnNlKDQwMSwgeyBlcnJvcjogXCJQSU4gd29ya3NwYWNlIHNhbGFoIGF0YXUgZGlwZXJsdWthblwiLCByZXF1aXJlc1BpbjogdHJ1ZSB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGJvZHkgPSBhd2FpdCBwYXJzZUpzb25Cb2R5KHJlcSk7XG4gICAgICBjb25zdCB3cyA9IGF3YWl0IHBnU3RvcmFnZS51cGRhdGVTZXR0aW5ncyh3c0lkLCBib2R5KTtcbiAgICAgIHJldHVybiBqc29uUmVzcG9uc2UoMjAwLCBzdG9yYWdlLnNhbml0aXplQ2xpZW50Vmlldyh3cykpO1xuICAgIH1cblxuICAgIGlmIChwYXRobmFtZSA9PT0gXCIvYXBpL2RlbW9cIiAmJiByZXEubWV0aG9kID09PSBcIlBPU1RcIikge1xuICAgICAgY29uc3Qgd3NDaGVjayA9IGF3YWl0IHBnU3RvcmFnZS5yZWFkV29ya3NwYWNlTWV0YSh3c0lkKTtcbiAgICAgIGlmICghY2hlY2tQaW4od3NDaGVjaywgcmVxLCB1cmwpKSB7XG4gICAgICAgIHJldHVybiBqc29uUmVzcG9uc2UoNDAxLCB7IGVycm9yOiBcIlBJTiB3b3Jrc3BhY2Ugc2FsYWggYXRhdSBkaXBlcmx1a2FuXCIsIHJlcXVpcmVzUGluOiB0cnVlIH0pO1xuICAgICAgfVxuICAgICAgY29uc3Qgd3MgPSBhd2FpdCBwZ1N0b3JhZ2Uuc2VlZERlbW9EYXRhKHdzSWQpO1xuICAgICAgY29uc3QgdmlldyA9IHN0b3JhZ2Uuc2FuaXRpemVDbGllbnRWaWV3KHdzKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICAgIHZpZXcucmVwb3J0ID0gYW5hbHl0aWNzLmFuYWx5emVNb250aCh3cywgXCJcIik7XG4gICAgICByZXR1cm4ganNvblJlc3BvbnNlKDIwMCwgdmlldyk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGpzb25SZXNwb25zZSg0MDQsIHsgZXJyb3I6IFwiRW5kcG9pbnQgdGlkYWsgZGl0ZW11a2FuXCIgfSk7XG4gIH0gY2F0Y2ggKGVycjogdW5rbm93bikge1xuICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJCYWQgcmVxdWVzdFwiO1xuICAgIHJldHVybiBqc29uUmVzcG9uc2UoNDAwLCB7IGVycm9yOiBtZXNzYWdlIH0pO1xuICB9XG59O1xuXG5leHBvcnQgY29uc3QgY29uZmlnOiBDb25maWcgPSB7XG4gIHBhdGg6IFwiL2FwaS8qXCIsXG59O1xuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQUEsS0FBQyxTQUFVLE1BQU0sU0FBUztBQUN4QixVQUFJLE9BQU8sV0FBVyxZQUFZLE9BQU8sU0FBUztBQUNoRCxlQUFPLFVBQVUsUUFBUTtBQUFBLE1BQzNCLE9BQU87QUFDTCxhQUFLLGtCQUFrQixRQUFRO0FBQUEsTUFDakM7QUFBQSxJQUNGLEdBQUcsT0FBTyxlQUFlLGNBQWMsYUFBYSxTQUFNLFdBQVk7QUFDcEU7QUFFQSxZQUFNLHFCQUFxQjtBQUFBLFFBQ3pCLEVBQUUsSUFBSSxTQUFTLE1BQU0saUJBQWlCLE1BQU0sYUFBTSxNQUFNLFdBQVcsUUFBUSxTQUFTLE9BQU8sVUFBVTtBQUFBLFFBQ3JHLEVBQUUsSUFBSSxRQUFRLE1BQU0sZ0JBQWdCLE1BQU0sVUFBSyxNQUFNLFdBQVcsUUFBUSxTQUFTLE9BQU8sVUFBVTtBQUFBLFFBQ2xHLEVBQUUsSUFBSSxhQUFhLE1BQU0sZ0JBQWdCLE1BQU0sYUFBTSxNQUFNLFdBQVcsUUFBUSxTQUFTLE9BQU8sVUFBVTtBQUFBLFFBQ3hHLEVBQUUsSUFBSSxXQUFXLE1BQU0saUJBQWlCLE1BQU0sYUFBTSxNQUFNLFdBQVcsUUFBUSxTQUFTLE9BQU8sVUFBVTtBQUFBLFFBQ3ZHLEVBQUUsSUFBSSxXQUFXLE1BQU0sdUJBQXVCLE1BQU0sYUFBTSxNQUFNLFdBQVcsUUFBUSxTQUFTLE9BQU8sVUFBVTtBQUFBLFFBQzdHLEVBQUUsSUFBSSxXQUFXLE1BQU0sdUJBQXVCLE1BQU0sYUFBTSxNQUFNLFdBQVcsUUFBUSxTQUFTLE9BQU8sVUFBVTtBQUFBLFFBQzdHLEVBQUUsSUFBSSxhQUFhLE1BQU0sYUFBYSxNQUFNLGFBQU0sTUFBTSxXQUFXLFFBQVEsU0FBUyxPQUFPLFVBQVU7QUFBQSxRQUNyRyxFQUFFLElBQUksY0FBYyxNQUFNLHFCQUFxQixNQUFNLGFBQU0sTUFBTSxXQUFXLFFBQVEsU0FBUyxPQUFPLFVBQVU7QUFBQSxRQUM5RyxFQUFFLElBQUksWUFBWSxNQUFNLHdCQUF3QixNQUFNLGFBQU0sTUFBTSxXQUFXLFFBQVEsV0FBVyxPQUFPLFVBQVU7QUFBQSxRQUNqSCxFQUFFLElBQUksV0FBVyxNQUFNLGFBQWEsTUFBTSxhQUFNLE1BQU0sV0FBVyxRQUFRLFNBQVMsT0FBTyxVQUFVO0FBQUEsUUFDbkcsRUFBRSxJQUFJLFFBQVEsTUFBTSxnQkFBZ0IsTUFBTSxhQUFNLE1BQU0sVUFBVSxRQUFRLFVBQVUsT0FBTyxVQUFVO0FBQUEsUUFDbkcsRUFBRSxJQUFJLFNBQVMsTUFBTSxxQkFBcUIsTUFBTSxhQUFNLE1BQU0sVUFBVSxRQUFRLFVBQVUsT0FBTyxVQUFVO0FBQUEsUUFDekcsRUFBRSxJQUFJLGlCQUFpQixNQUFNLG1CQUFtQixNQUFNLGFBQU0sTUFBTSxVQUFVLFFBQVEsVUFBVSxPQUFPLFVBQVU7QUFBQSxRQUMvRyxFQUFFLElBQUksY0FBYyxNQUFNLGtCQUFrQixNQUFNLGFBQU0sTUFBTSxVQUFVLFFBQVEsVUFBVSxPQUFPLFVBQVU7QUFBQSxNQUM3RztBQUVBLFlBQU0sa0JBQWtCO0FBQUEsUUFDdEIsRUFBRSxJQUFJLFNBQVMsTUFBTSxrQkFBa0IsTUFBTSxhQUFNLGdCQUFnQixFQUFFO0FBQUEsUUFDckUsRUFBRSxJQUFJLFFBQVEsTUFBTSxpQkFBaUIsTUFBTSxhQUFNLGdCQUFnQixFQUFFO0FBQUEsUUFDbkUsRUFBRSxJQUFJLFdBQVcsTUFBTSxtQkFBbUIsTUFBTSxhQUFNLGdCQUFnQixFQUFFO0FBQUEsTUFDMUU7QUFFQSxlQUFTLFVBQVUsUUFBUTtBQUN6QixjQUFNLElBQUksS0FBSyxNQUFNLE9BQU8sTUFBTSxLQUFLLENBQUM7QUFDeEMsY0FBTSxPQUFPLElBQUksSUFBSSxNQUFNO0FBQzNCLGNBQU0sTUFBTSxLQUFLLElBQUksQ0FBQyxFQUFFLFNBQVMsRUFBRSxRQUFRLHlCQUF5QixHQUFHO0FBQ3ZFLGVBQU8sT0FBTyxPQUFPO0FBQUEsTUFDdkI7QUFFQSxlQUFTLFdBQVcsU0FBUztBQUMzQixZQUFJLENBQUMsV0FBVyxPQUFPLFlBQVksU0FBVSxRQUFPO0FBQ3BELGVBQU8sUUFBUSxNQUFNLEdBQUcsQ0FBQztBQUFBLE1BQzNCO0FBRUEsZUFBUyxvQkFBb0IsVUFBVTtBQUNyQyxjQUFNLFFBQVEsU0FBUyxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU07QUFDNUMsWUFBSSxNQUFNLFdBQVcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUcsUUFBTztBQUN6RCxZQUFJLElBQUksTUFBTSxDQUFDO0FBQ2YsWUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJO0FBQ25CLFlBQUksTUFBTSxHQUFHO0FBQ1gsY0FBSTtBQUNKLGVBQUs7QUFBQSxRQUNQO0FBQ0EsZUFBTyxPQUFPLENBQUMsSUFBSSxNQUFNLE9BQU8sQ0FBQyxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQUEsTUFDcEQ7QUFFQSxlQUFTLFlBQVksVUFBVTtBQUM3QixjQUFNLFFBQVEsU0FBUyxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU07QUFDNUMsWUFBSSxNQUFNLFdBQVcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUcsUUFBTztBQUN6RCxlQUFPLElBQUksS0FBSyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLEVBQUUsUUFBUTtBQUFBLE1BQ2pEO0FBRUEsZUFBUyxpQkFBaUIsWUFBWTtBQUNwQyxjQUFNLE1BQU0sQ0FBQztBQUNiLGNBQU0sT0FBTyxNQUFNLFFBQVEsVUFBVSxLQUFLLFdBQVcsU0FBUyxhQUFhO0FBQzNFLGlCQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0FBQ3BDLGNBQUksS0FBSyxDQUFDLEVBQUUsRUFBRSxJQUFJLEtBQUssQ0FBQztBQUFBLFFBQzFCO0FBQ0EsZUFBTztBQUFBLE1BQ1Q7QUFFQSxlQUFTLHNCQUFzQixjQUFjLFNBQVM7QUFDcEQsY0FBTSxhQUFhLE1BQU0sUUFBUSxPQUFPLEtBQUssUUFBUSxTQUFTLFVBQVU7QUFDeEUsY0FBTSxXQUFXLENBQUM7QUFDbEIsaUJBQVMsSUFBSSxHQUFHLElBQUksV0FBVyxRQUFRLEtBQUs7QUFDMUMsZ0JBQU0sSUFBSSxXQUFXLENBQUM7QUFDdEIsbUJBQVMsRUFBRSxFQUFFLElBQUk7QUFBQSxZQUNmLElBQUksRUFBRTtBQUFBLFlBQ04sTUFBTSxFQUFFO0FBQUEsWUFDUixNQUFNLEVBQUUsUUFBUTtBQUFBLFlBQ2hCLFNBQVMsT0FBTyxFQUFFLGNBQWMsS0FBSztBQUFBLFlBQ3JDLFFBQVE7QUFBQSxZQUNSLFNBQVM7QUFBQSxVQUNYO0FBQUEsUUFDRjtBQUVBLGlCQUFTLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLO0FBQzVDLGdCQUFNLEtBQUssYUFBYSxDQUFDO0FBQ3pCLGNBQUksR0FBRyxRQUFTO0FBQ2hCLGdCQUFNLE1BQU0sT0FBTyxHQUFHLE1BQU0sS0FBSztBQUNqQyxnQkFBTSxNQUFNLEdBQUcsVUFBVTtBQUN6QixjQUFJLENBQUMsU0FBUyxHQUFHLEdBQUc7QUFDbEIscUJBQVMsR0FBRyxJQUFJLEVBQUUsSUFBSSxLQUFLLE1BQU0sS0FBSyxNQUFNLGFBQU0sU0FBUyxHQUFHLFFBQVEsR0FBRyxTQUFTLEVBQUU7QUFBQSxVQUN0RjtBQUNBLGNBQUksR0FBRyxTQUFTLFVBQVU7QUFDeEIscUJBQVMsR0FBRyxFQUFFLFdBQVc7QUFDekIscUJBQVMsR0FBRyxFQUFFLFVBQVU7QUFBQSxVQUMxQixXQUFXLEdBQUcsU0FBUyxXQUFXO0FBQ2hDLHFCQUFTLEdBQUcsRUFBRSxXQUFXO0FBQ3pCLHFCQUFTLEdBQUcsRUFBRSxXQUFXO0FBQUEsVUFDM0IsV0FBVyxHQUFHLFNBQVMsWUFBWTtBQUNqQyxxQkFBUyxHQUFHLEVBQUUsV0FBVztBQUN6QixrQkFBTSxNQUFNLEdBQUcsWUFBWTtBQUMzQixnQkFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHO0FBQ2xCLHVCQUFTLEdBQUcsSUFBSSxFQUFFLElBQUksS0FBSyxNQUFNLEtBQUssTUFBTSxhQUFNLFNBQVMsR0FBRyxRQUFRLEdBQUcsU0FBUyxFQUFFO0FBQUEsWUFDdEY7QUFDQSxxQkFBUyxHQUFHLEVBQUUsV0FBVztBQUFBLFVBQzNCO0FBQUEsUUFDRjtBQUVBLGVBQU8sT0FBTyxLQUFLLFFBQVEsRUFBRSxJQUFJLFNBQVUsR0FBRztBQUFFLGlCQUFPLFNBQVMsQ0FBQztBQUFBLFFBQUcsQ0FBQztBQUFBLE1BQ3ZFO0FBS0EsZUFBUyxhQUFhLE1BQU0sYUFBYSxTQUFTO0FBQ2hELGNBQU0sTUFBTSxtQkFBbUIsT0FBTyxVQUFVLG9CQUFJLEtBQUs7QUFDekQsY0FBTSxXQUFXLGVBQWdCLElBQUksWUFBWSxJQUFJLE1BQU0sT0FBTyxJQUFJLFNBQVMsSUFBSSxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUc7QUFDckcsY0FBTSxlQUFlLG9CQUFvQixRQUFRO0FBRWpELGNBQU0sU0FBUyxRQUFRLE1BQU0sUUFBUSxLQUFLLFlBQVksSUFBSSxLQUFLLGVBQWUsQ0FBQyxHQUFHLE9BQU8sU0FBVSxHQUFHO0FBQ3BHLGlCQUFPLEtBQUssQ0FBQyxFQUFFO0FBQUEsUUFDakIsQ0FBQztBQUNELGNBQU0sYUFBYyxRQUFRLE1BQU0sUUFBUSxLQUFLLFVBQVUsS0FBSyxLQUFLLFdBQVcsU0FDMUUsS0FBSyxhQUNMO0FBQ0osY0FBTSxTQUFTLGlCQUFpQixVQUFVO0FBQzFDLGNBQU0sVUFBVyxRQUFRLEtBQUssV0FBWSxDQUFDO0FBQzNDLGNBQU0sVUFBVyxRQUFRLEtBQUssV0FBWTtBQUMxQyxjQUFNLHlCQUEwQixRQUFRLE9BQU8sS0FBSyxpQkFBaUIsS0FBTTtBQUUzRSxjQUFNLFlBQVksTUFBTSxPQUFPLFNBQVUsR0FBRztBQUFFLGlCQUFPLFdBQVcsRUFBRSxJQUFJLE1BQU07QUFBQSxRQUFVLENBQUM7QUFDdkYsY0FBTSxTQUFTLE1BQU0sT0FBTyxTQUFVLEdBQUc7QUFBRSxpQkFBTyxXQUFXLEVBQUUsSUFBSSxNQUFNO0FBQUEsUUFBYyxDQUFDO0FBRXhGLFlBQUksY0FBYztBQUNsQixZQUFJLGVBQWU7QUFDbkIsWUFBSSxxQkFBcUI7QUFDekIsY0FBTSxpQkFBaUIsQ0FBQztBQUN4QixjQUFNLGlCQUFpQixDQUFDO0FBQ3hCLGNBQU0sY0FBYyxDQUFDO0FBQ3JCLGNBQU0sZUFBZSxFQUFFLE9BQU8sR0FBRyxPQUFPLEdBQUcsU0FBUyxFQUFFO0FBRXRELGlCQUFTLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0FBQ3pDLGdCQUFNLEtBQUssVUFBVSxDQUFDO0FBQ3RCLGdCQUFNLE1BQU0sT0FBTyxHQUFHLE1BQU0sS0FBSztBQUNqQyxnQkFBTSxPQUFPLEdBQUcsUUFBUSxJQUFJLE1BQU0sR0FBRyxFQUFFO0FBQ3ZDLGNBQUksT0FBTyxDQUFDLFlBQVksR0FBRyxHQUFHO0FBQzVCLHdCQUFZLEdBQUcsSUFBSSxFQUFFLE1BQU0sS0FBSyxRQUFRLEdBQUcsU0FBUyxFQUFFO0FBQUEsVUFDeEQ7QUFFQSxjQUFJLEdBQUcsU0FBUyxVQUFVO0FBQ3hCLDJCQUFlO0FBQ2YsZ0JBQUksSUFBSyxhQUFZLEdBQUcsRUFBRSxVQUFVO0FBQUEsVUFDdEMsV0FBVyxHQUFHLFNBQVMsV0FBVztBQUNoQyxrQkFBTSxNQUFNLE9BQU8sR0FBRyxRQUFRLEtBQUssRUFBRSxJQUFJLEdBQUcsWUFBWSxXQUFXLE1BQU0sR0FBRyxZQUFZLFdBQVcsTUFBTSxhQUFNLFFBQVEsU0FBUyxPQUFPLFVBQVU7QUFDakosa0JBQU0sU0FBUyxJQUFJLFVBQVU7QUFFN0IsZ0JBQUksV0FBVyxXQUFXO0FBQ3hCLG9DQUFzQjtBQUN0QiwyQkFBYSxXQUFXO0FBQUEsWUFDMUIsT0FBTztBQUNMLDhCQUFnQjtBQUNoQixrQkFBSSxJQUFLLGFBQVksR0FBRyxFQUFFLFdBQVc7QUFDckMsa0JBQUksV0FBVyxRQUFTLGNBQWEsU0FBUztBQUFBLGtCQUN6QyxjQUFhLFNBQVM7QUFBQSxZQUM3QjtBQUVBLGdCQUFJLENBQUMsZUFBZSxJQUFJLEVBQUUsR0FBRztBQUMzQiw2QkFBZSxJQUFJLEVBQUUsSUFBSTtBQUFBLGdCQUN2QixJQUFJLElBQUk7QUFBQSxnQkFDUixNQUFNLElBQUk7QUFBQSxnQkFDVixNQUFNLElBQUk7QUFBQSxnQkFDVixPQUFPLElBQUksU0FBUztBQUFBLGdCQUNwQjtBQUFBLGdCQUNBLFFBQVE7QUFBQSxnQkFDUixPQUFPO0FBQUEsZ0JBQ1AsUUFBUSxPQUFPLFFBQVEsSUFBSSxFQUFFLENBQUMsS0FBSztBQUFBLGNBQ3JDO0FBQUEsWUFDRjtBQUNBLDJCQUFlLElBQUksRUFBRSxFQUFFLFVBQVU7QUFDakMsMkJBQWUsSUFBSSxFQUFFLEVBQUUsU0FBUztBQUVoQyxrQkFBTSxNQUFNLEdBQUcsVUFBVTtBQUN6QiwyQkFBZSxHQUFHLEtBQUssZUFBZSxHQUFHLEtBQUssS0FBSztBQUFBLFVBQ3JEO0FBQUEsUUFDRjtBQUdBLFlBQUksbUJBQW1CO0FBQ3ZCLFlBQUksa0JBQWtCO0FBQ3RCLGNBQU0scUJBQXFCLENBQUM7QUFDNUIsaUJBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQUs7QUFDdEMsZ0JBQU0sS0FBSyxPQUFPLENBQUM7QUFDbkIsZ0JBQU0sTUFBTSxPQUFPLEdBQUcsTUFBTSxLQUFLO0FBQ2pDLGNBQUksR0FBRyxTQUFTLFVBQVU7QUFDeEIsK0JBQW1CO0FBQUEsVUFDckIsV0FBVyxHQUFHLFNBQVMsV0FBVztBQUNoQyxrQkFBTSxNQUFNLE9BQU8sR0FBRyxRQUFRLEtBQUssRUFBRSxJQUFJLEdBQUcsWUFBWSxXQUFXLFFBQVEsUUFBUTtBQUNuRixnQkFBSSxJQUFJLFdBQVcsV0FBVztBQUM1QixrQ0FBb0I7QUFBQSxZQUN0QjtBQUNBLCtCQUFtQixJQUFJLEVBQUUsS0FBSyxtQkFBbUIsSUFBSSxFQUFFLEtBQUssS0FBSztBQUFBLFVBQ25FO0FBQUEsUUFDRjtBQUVBLGNBQU0sMEJBQTBCLGVBQWU7QUFDL0MsY0FBTSxjQUFjLGNBQWM7QUFDbEMsY0FBTSxtQkFBbUIsS0FBSyxJQUFJLEdBQUcsV0FBVztBQUNoRCxjQUFNLGNBQWMsY0FBYyxJQUFJLEtBQUssTUFBTyxtQkFBbUIsY0FBZSxHQUFJLElBQUksS0FBSztBQUdqRyxjQUFNLG9CQUFvQixPQUFPLEtBQUssY0FBYyxFQUNqRCxJQUFJLFNBQVUsSUFBSTtBQUNqQixnQkFBTSxPQUFPLGVBQWUsRUFBRTtBQUM5QixnQkFBTSxPQUFPLEtBQUssV0FBVyxZQUFZLEtBQUssSUFBSSx5QkFBeUIsQ0FBQyxJQUFJLEtBQUssSUFBSSxjQUFjLENBQUM7QUFDeEcsZ0JBQU0sVUFBVSxtQkFBbUIsRUFBRSxLQUFLO0FBQzFDLGdCQUFNLFdBQVcsVUFBVSxJQUFJLEtBQUssT0FBUSxLQUFLLFNBQVMsV0FBVyxVQUFXLEdBQUcsSUFBSTtBQUN2RixnQkFBTSxnQkFBZ0IsS0FBSyxTQUFTLElBQUksS0FBSyxNQUFPLEtBQUssU0FBUyxLQUFLLFNBQVUsR0FBRyxJQUFJO0FBQ3hGLGlCQUFPLE9BQU8sT0FBTyxDQUFDLEdBQUcsTUFBTTtBQUFBLFlBQzdCLFVBQVUsS0FBSyxXQUFXLFlBQVksSUFBSSxLQUFLLE1BQU8sS0FBSyxTQUFTLE9BQVEsR0FBSSxJQUFJO0FBQUEsWUFDcEYsWUFBWTtBQUFBLFlBQ1o7QUFBQSxZQUNBO0FBQUEsVUFDRixDQUFDO0FBQUEsUUFDSCxDQUFDLEVBQ0EsS0FBSyxTQUFVLEdBQUcsR0FBRztBQUFFLGlCQUFPLEVBQUUsU0FBUyxFQUFFO0FBQUEsUUFBUSxDQUFDO0FBRXZELGNBQU0sb0JBQW9CLGtCQUFrQixPQUFPLFNBQVUsR0FBRztBQUFFLGlCQUFPLEVBQUUsV0FBVztBQUFBLFFBQVcsQ0FBQztBQUdsRyxjQUFNLGNBQWMsVUFDakIsT0FBTyxTQUFVLEdBQUc7QUFDbkIsZ0JBQU0sSUFBSSxPQUFPLEVBQUUsUUFBUTtBQUMzQixpQkFBTyxFQUFFLFNBQVMsY0FBYyxDQUFDLEtBQUssRUFBRSxXQUFXO0FBQUEsUUFDckQsQ0FBQyxFQUNBLEtBQUssU0FBVSxHQUFHLEdBQUc7QUFBRSxrQkFBUSxPQUFPLEVBQUUsTUFBTSxLQUFLLE1BQU0sT0FBTyxFQUFFLE1BQU0sS0FBSztBQUFBLFFBQUksQ0FBQyxFQUNsRixNQUFNLEdBQUcsQ0FBQyxFQUNWLElBQUksU0FBVSxHQUFHO0FBQ2hCLGdCQUFNLElBQUksT0FBTyxFQUFFLFFBQVEsS0FBSyxFQUFFLE1BQU0sRUFBRSxZQUFZLFdBQVcsTUFBTSxZQUFLO0FBQzVFLGlCQUFPO0FBQUEsWUFDTCxJQUFJLEVBQUU7QUFBQSxZQUNOLE1BQU0sRUFBRTtBQUFBLFlBQ1IsTUFBTSxFQUFFLFFBQVEsRUFBRTtBQUFBLFlBQ2xCLGNBQWMsRUFBRTtBQUFBLFlBQ2hCLE1BQU0sRUFBRTtBQUFBLFlBQ1IsUUFBUSxPQUFPLEVBQUUsTUFBTSxLQUFLO0FBQUEsWUFDNUIsUUFBUSxFQUFFO0FBQUEsVUFDWjtBQUFBLFFBQ0YsQ0FBQztBQUdILGNBQU0sWUFBWSxZQUFZLFFBQVE7QUFDdEMsY0FBTSxrQkFBa0IsSUFBSSxZQUFZLElBQUksTUFBTSxPQUFPLElBQUksU0FBUyxJQUFJLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUM1RixZQUFJLGdCQUFnQjtBQUNwQixZQUFJLGNBQWM7QUFDbEIsWUFBSSxhQUFhLGlCQUFpQjtBQUNoQyxnQkFBTSxRQUFRLElBQUksUUFBUTtBQUMxQix3QkFBYyxLQUFLLElBQUksR0FBRyxLQUFLO0FBQy9CLDBCQUFnQixLQUFLLElBQUksR0FBRyxZQUFZLFFBQVEsQ0FBQztBQUFBLFFBQ25EO0FBRUEsY0FBTSxpQkFBaUIsT0FBTyxLQUFLLE9BQU8sRUFBRSxPQUFPLFNBQVUsS0FBSyxHQUFHO0FBQ25FLGdCQUFNLElBQUksT0FBTyxDQUFDO0FBQ2xCLGNBQUksS0FBSyxFQUFFLFdBQVcsVUFBVyxRQUFPO0FBQ3hDLGlCQUFPLE9BQU8sT0FBTyxRQUFRLENBQUMsQ0FBQyxLQUFLO0FBQUEsUUFDdEMsR0FBRyxDQUFDO0FBRUosY0FBTSxxQkFBcUIsY0FBYyxJQUNyQyxLQUFLLE1BQU0sZUFBZSxJQUFJLHlCQUF5QixJQUFJLElBQzFELGlCQUFpQixJQUFJLGlCQUFpQjtBQUUzQyxjQUFNLHFCQUFxQixxQkFBcUI7QUFDaEQsY0FBTSxpQkFBa0IsVUFBVSxTQUFTLEtBQUsscUJBQXFCLElBQ2pFLEtBQUssTUFBTSxxQkFBcUIsYUFBYSxJQUM3QztBQUNKLGNBQU0sZ0JBQWdCLEtBQUssTUFBTSxlQUFlLEtBQUssSUFBSSxHQUFHLFdBQVcsQ0FBQztBQUd4RSxjQUFNLFlBQVksY0FBYyxJQUFJLGNBQWMsS0FBSyxJQUFJLEdBQUcsdUJBQXVCO0FBQ3JGLGNBQU0sV0FBVyxLQUFLLE1BQU8sYUFBYSxRQUFRLFlBQWEsR0FBSSxJQUFJO0FBQ3ZFLGNBQU0sV0FBVyxLQUFLLE1BQU8sYUFBYSxRQUFRLFlBQWEsR0FBSSxJQUFJO0FBQ3ZFLGNBQU0sbUJBQW1CLGNBQWMsSUFDbkMsS0FBSyxJQUFJLEdBQUcsS0FBSyxNQUFPLG1CQUFtQixjQUFlLEdBQUksSUFBSSxFQUFFLElBQ3BFLEtBQUssTUFBTyxhQUFhLFVBQVUsWUFBYSxHQUFJLElBQUk7QUFHNUQsWUFBSSxjQUFjO0FBQ2xCLFlBQUksVUFBVSxXQUFXLEdBQUc7QUFDMUIsd0JBQWM7QUFBQSxRQUNoQixPQUFPO0FBQ0wsY0FBSSxRQUFRO0FBQ1osY0FBSSxjQUFjLEdBQUc7QUFDbkIsZ0JBQUksZUFBZSxHQUFJLFVBQVM7QUFBQSxxQkFDdkIsZUFBZSxHQUFJLFVBQVM7QUFBQSxxQkFDNUIsY0FBYyxFQUFHLFVBQVM7QUFBQSxnQkFDOUIsVUFBUztBQUFBLFVBQ2hCO0FBQ0EsY0FBSSxZQUFZLEdBQUksVUFBUztBQUFBLG1CQUNwQixZQUFZLEdBQUksVUFBUztBQUFBLGNBQzdCLFVBQVM7QUFFZCxnQkFBTSxrQkFBa0Isa0JBQWtCLE9BQU8sU0FBVSxHQUFHO0FBQUUsbUJBQU8sRUFBRSxTQUFTLEtBQUssRUFBRSxTQUFTLEVBQUU7QUFBQSxVQUFRLENBQUMsRUFBRTtBQUMvRyxjQUFJLG9CQUFvQixFQUFHLFVBQVM7QUFBQSxjQUMvQixVQUFTLEtBQUssSUFBSSxJQUFJLGtCQUFrQixDQUFDO0FBRTlDLHdCQUFjLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxLQUFLLEtBQUssTUFBTSxLQUFLLENBQUMsQ0FBQztBQUFBLFFBQzVEO0FBR0EsY0FBTSxrQkFBa0IsQ0FBQztBQUV6QixZQUFJLFVBQVUsV0FBVyxHQUFHO0FBQzFCLDBCQUFnQixLQUFLO0FBQUEsWUFDbkIsVUFBVTtBQUFBLFlBQ1YsT0FBTztBQUFBLFlBQ1AsU0FBUyw2Q0FBNkMsV0FBVztBQUFBLFlBQ2pFLFFBQVE7QUFBQSxVQUNWLENBQUM7QUFBQSxRQUNILE9BQU87QUFFTCxjQUFJLGNBQWMsS0FBSyxjQUFjLEdBQUc7QUFDdEMsNEJBQWdCLEtBQUs7QUFBQSxjQUNuQixVQUFVO0FBQUEsY0FDVixPQUFPLHFDQUFxQyxVQUFVLEtBQUssSUFBSSxXQUFXLENBQUMsSUFBSTtBQUFBLGNBQy9FLFNBQVMsa0NBQWtDLFVBQVUsWUFBWSxJQUFJLGtDQUFrQyxVQUFVLFdBQVcsSUFBSTtBQUFBLGNBQ2hJLFFBQVEsZ0dBQWdHLGtCQUFrQixDQUFDLElBQUksa0JBQWtCLENBQUMsRUFBRSxPQUFPLE9BQU87QUFBQSxZQUNwSyxDQUFDO0FBQUEsVUFDSCxXQUFXLGNBQWMsS0FBSyxjQUFjLHdCQUF3QjtBQUNsRSxrQkFBTSxNQUFNLEtBQUssTUFBTyxlQUFlLHlCQUF5QixPQUFRLGdCQUFnQjtBQUN4Riw0QkFBZ0IsS0FBSztBQUFBLGNBQ25CLFVBQVU7QUFBQSxjQUNWLE9BQU8sc0NBQXNDLHlCQUF5QjtBQUFBLGNBQ3RFLFNBQVMsNkJBQTZCLGNBQWMsUUFBUSxVQUFVLGdCQUFnQixJQUFJLHFDQUFxQyxVQUFVLEdBQUcsSUFBSSxnQ0FBZ0MseUJBQXlCO0FBQUEsY0FDek0sUUFBUSxzRkFBc0YsVUFBVSxLQUFLLE1BQU0sZUFBZSx5QkFBeUIsSUFBSSxDQUFDLElBQUk7QUFBQSxZQUN0SyxDQUFDO0FBQUEsVUFDSCxXQUFXLGNBQWMsR0FBRztBQUMxQiw0QkFBZ0IsS0FBSztBQUFBLGNBQ25CLFVBQVU7QUFBQSxjQUNWLE9BQU8sMENBQXFDLGNBQWM7QUFBQSxjQUMxRCxTQUFTLHdDQUF3QyxVQUFVLGdCQUFnQixJQUFJLE9BQU8sY0FBYztBQUFBLGNBQ3BHLFFBQVEsK0NBQStDLFVBQVUsY0FBYyxJQUFJO0FBQUEsWUFDckYsQ0FBQztBQUFBLFVBQ0g7QUFHQSxjQUFJLGtCQUFrQixTQUFTLEtBQUssZUFBZSxHQUFHO0FBQ3BELGtCQUFNLFNBQVMsa0JBQWtCLENBQUM7QUFDbEMsZ0JBQUksT0FBTyxZQUFZLElBQUk7QUFDekIsb0JBQU0sZUFBZSxLQUFLLE1BQU0sT0FBTyxTQUFTLElBQUk7QUFDcEQsOEJBQWdCLEtBQUs7QUFBQSxnQkFDbkIsVUFBVTtBQUFBLGdCQUNWLE9BQU8sT0FBTyxPQUFPLE1BQU0sT0FBTyxPQUFPLGVBQWUsT0FBTyxXQUFXO0FBQUEsZ0JBQzFFLFNBQVMscUNBQXFDLE9BQU8sT0FBTyxjQUFjLFVBQVUsT0FBTyxNQUFNLElBQUksT0FBTyxPQUFPLFFBQVE7QUFBQSxnQkFDM0gsUUFBUSw0RUFBNEUsVUFBVSxZQUFZLElBQUk7QUFBQSxjQUNoSCxDQUFDO0FBQUEsWUFDSDtBQUFBLFVBQ0Y7QUFHQSxnQkFBTSxXQUFXLGtCQUFrQixPQUFPLFNBQVUsR0FBRztBQUFFLG1CQUFPLEVBQUUsU0FBUyxLQUFLLEVBQUUsU0FBUyxFQUFFO0FBQUEsVUFBUSxDQUFDO0FBQ3RHLGdCQUFNLFdBQVcsa0JBQWtCLE9BQU8sU0FBVSxHQUFHO0FBQUUsbUJBQU8sRUFBRSxTQUFTLEtBQUssRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLGlCQUFpQjtBQUFBLFVBQUksQ0FBQztBQUVoSSxjQUFJLFNBQVMsU0FBUyxHQUFHO0FBQ3ZCLGtCQUFNLFFBQVEsU0FBUyxJQUFJLFNBQVUsR0FBRztBQUFFLHFCQUFPLEVBQUUsT0FBTyxPQUFPLEVBQUUsZ0JBQWdCO0FBQUEsWUFBTSxDQUFDLEVBQUUsS0FBSyxJQUFJO0FBQ3JHLDRCQUFnQixLQUFLO0FBQUEsY0FDbkIsVUFBVTtBQUFBLGNBQ1YsT0FBTyw0QkFBNEIsU0FBUyxTQUFTO0FBQUEsY0FDckQsU0FBUywwREFBMEQsUUFBUTtBQUFBLGNBQzNFLFFBQVE7QUFBQSxZQUNWLENBQUM7QUFBQSxVQUNILFdBQVcsU0FBUyxTQUFTLEdBQUc7QUFDOUIsa0JBQU0sUUFBUSxTQUFTLElBQUksU0FBVSxHQUFHO0FBQUUscUJBQU8sRUFBRSxPQUFPLE9BQU8sRUFBRSxnQkFBZ0I7QUFBQSxZQUFNLENBQUMsRUFBRSxLQUFLLElBQUk7QUFDckcsNEJBQWdCLEtBQUs7QUFBQSxjQUNuQixVQUFVO0FBQUEsY0FDVixPQUFPO0FBQUEsY0FDUCxTQUFTLGNBQWMsUUFBUTtBQUFBLGNBQy9CLFFBQVEsNERBQTRELFVBQVUsY0FBYyxJQUFJO0FBQUEsWUFDbEcsQ0FBQztBQUFBLFVBQ0g7QUFHQSxjQUFJLFdBQVcsSUFBSTtBQUNqQixrQkFBTSxjQUFjLEtBQUssTUFBTSxhQUFhLFFBQVMsWUFBWSxHQUFLO0FBQ3RFLDRCQUFnQixLQUFLO0FBQUEsY0FDbkIsVUFBVTtBQUFBLGNBQ1YsT0FBTyxvQ0FBb0MsV0FBVztBQUFBLGNBQ3RELFNBQVMsOERBQThELFVBQVUsYUFBYSxLQUFLLElBQUk7QUFBQSxjQUN2RyxRQUFRLHFCQUFxQixVQUFVLFdBQVcsSUFBSTtBQUFBLFlBQ3hELENBQUM7QUFBQSxVQUNIO0FBR0EsZ0JBQU0sZ0JBQWdCLGtCQUFrQixPQUFPLFNBQVUsR0FBRztBQUMxRCxtQkFBTyxFQUFFLFNBQVMsS0FBTSxFQUFFLFNBQVMsRUFBRSxTQUFVLFFBQVMsRUFBRSxXQUFXO0FBQUEsVUFDdkUsQ0FBQztBQUNELGNBQUksY0FBYyxTQUFTLEdBQUc7QUFDNUIsa0JBQU0sSUFBSSxjQUFjLENBQUM7QUFDekIsa0JBQU0sWUFBWSxLQUFLLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSztBQUMvQyw0QkFBZ0IsS0FBSztBQUFBLGNBQ25CLFVBQVU7QUFBQSxjQUNWLE9BQU8sdUNBQXVDLEVBQUU7QUFBQSxjQUNoRCxTQUFTLGNBQWMsRUFBRSxRQUFRLGlDQUFpQyxVQUFVLFNBQVMsSUFBSSxvQkFBb0IsVUFBVSxFQUFFLE1BQU0sSUFBSTtBQUFBLGNBQ25JLFFBQVEscUZBQXFGLFVBQVUsS0FBSyxNQUFNLEVBQUUsU0FBUyxJQUFJLENBQUMsSUFBSTtBQUFBLFlBQ3hJLENBQUM7QUFBQSxVQUNIO0FBR0EsZ0JBQU0sU0FBUyxrQkFBa0IsT0FBTyxTQUFVLEdBQUc7QUFBRSxtQkFBTyxFQUFFLGFBQWEsUUFBUSxFQUFFLFlBQVksTUFBTSxFQUFFLFVBQVU7QUFBQSxVQUFRLENBQUM7QUFDOUgsY0FBSSxPQUFPLFNBQVMsR0FBRztBQUNyQixrQkFBTSxJQUFJLE9BQU8sQ0FBQztBQUNsQiw0QkFBZ0IsS0FBSztBQUFBLGNBQ25CLFVBQVU7QUFBQSxjQUNWLE9BQU8sZUFBZSxFQUFFLFdBQVcsVUFBVSxFQUFFLE9BQU87QUFBQSxjQUN0RCxTQUFTLGdCQUFnQixVQUFVLEVBQUUsVUFBVSxJQUFJLDhCQUE4QixVQUFVLEVBQUUsTUFBTSxJQUFJO0FBQUEsY0FDdkcsUUFBUSxrQ0FBa0MsRUFBRSxPQUFPO0FBQUEsWUFDckQsQ0FBQztBQUFBLFVBQ0g7QUFHQSxjQUFJLGVBQWUsR0FBRztBQUNwQixrQkFBTSxrQkFBa0IsZUFBZTtBQUN2QyxrQkFBTSxjQUFjLG1CQUFtQixJQUFJLG1CQUFtQixLQUFLLE9BQU8sZUFBZSxnQkFBZ0IsSUFBSTtBQUM3RyxrQkFBTSxlQUFlLGNBQWMsSUFBSSxLQUFLLEtBQUssa0JBQWtCLFdBQVcsSUFBSTtBQUNsRiw0QkFBZ0IsS0FBSztBQUFBLGNBQ25CLFVBQVU7QUFBQSxjQUNWLE9BQU87QUFBQSxjQUNQLFNBQVMsNkJBQTZCLFVBQVUsWUFBWSxJQUFJLCtDQUErQyxVQUFVLGVBQWUsSUFBSTtBQUFBLGNBQzVJLFFBQVEsZUFDSixxQkFBcUIsVUFBVSxXQUFXLElBQUksd0NBQXdDLGVBQWUsWUFDckc7QUFBQSxZQUNOLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRjtBQUdBLGNBQU0sZ0JBQWdCLGtCQUFrQixJQUFJLFNBQVUsR0FBRztBQUN2RCxjQUFJLFlBQVksRUFBRTtBQUNsQixjQUFJLFlBQVk7QUFDaEIsY0FBSSxFQUFFLFdBQVcsWUFBWSxXQUFXLE1BQU8sRUFBRSxhQUFhLFFBQVEsRUFBRSxXQUFXLEtBQU07QUFDdkYsd0JBQVksS0FBSyxNQUFPLEVBQUUsU0FBUyxPQUFRLEdBQUssSUFBSTtBQUNwRCx3QkFBWTtBQUFBLFVBQ2QsV0FBVyxFQUFFLFNBQVMsS0FBSyxFQUFFLFNBQVMsRUFBRSxRQUFRO0FBQzlDLHdCQUFZLEtBQUssT0FBUSxFQUFFLFNBQVMsRUFBRSxVQUFVLElBQUssR0FBSyxJQUFJO0FBQzlELHdCQUFZO0FBQUEsVUFDZCxXQUFXLEVBQUUsU0FBUyxHQUFHO0FBQ3ZCLHdCQUFZLEVBQUU7QUFDZCx3QkFBWTtBQUFBLFVBQ2Q7QUFDQSxpQkFBTztBQUFBLFlBQ0wsWUFBWSxFQUFFO0FBQUEsWUFDZCxNQUFNLEVBQUU7QUFBQSxZQUNSLE1BQU0sRUFBRTtBQUFBLFlBQ1IsZUFBZSxFQUFFO0FBQUEsWUFDakIsaUJBQWlCLEtBQUssSUFBSSxHQUFHLFNBQVM7QUFBQSxZQUN0QztBQUFBLFVBQ0Y7QUFBQSxRQUNGLENBQUM7QUFFRCxjQUFNLGNBQWMsT0FBTyxLQUFLLFdBQVcsRUFBRSxLQUFLLEVBQUUsSUFBSSxTQUFVLEdBQUc7QUFBRSxpQkFBTyxZQUFZLENBQUM7QUFBQSxRQUFHLENBQUM7QUFDL0YsY0FBTSxpQkFBaUIsc0JBQXNCLE9BQU8sT0FBTztBQUUzRCxlQUFPO0FBQUEsVUFDTCxPQUFPO0FBQUEsVUFDUCxlQUFlO0FBQUEsVUFDZixTQUFTO0FBQUEsWUFDUDtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBLGlCQUFpQixtQkFBbUIsSUFBSSxLQUFLLE9BQVEsZUFBZSxvQkFBb0IsbUJBQW9CLEdBQUcsSUFBSTtBQUFBLFlBQ25IO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBLGtCQUFrQixVQUFVO0FBQUEsWUFDNUI7QUFBQSxVQUNGO0FBQUEsVUFDQSxZQUFZO0FBQUEsWUFDVixhQUFhLGFBQWE7QUFBQSxZQUMxQixhQUFhLGFBQWE7QUFBQSxZQUMxQixlQUFlO0FBQUEsWUFDZjtBQUFBLFlBQ0E7QUFBQSxZQUNBLFlBQVk7QUFBQSxVQUNkO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBRUEsZUFBUyxvQkFBb0IsUUFBUTtBQUNuQyxjQUFNLElBQUksT0FBTztBQUNqQixjQUFNLElBQUksT0FBTztBQUNqQixjQUFNLFFBQVEsQ0FBQztBQUNmLGNBQU0sS0FBSywyQ0FBc0MsT0FBTyxLQUFLO0FBQzdELGNBQU0sS0FBSyxFQUFFO0FBQ2IsY0FBTSxLQUFLLHdCQUF3QixPQUFPLEtBQUs7QUFDL0MsY0FBTSxLQUFLLDRCQUE0QixVQUFVLEVBQUUsV0FBVyxDQUFDO0FBQy9ELGNBQU0sS0FBSyw4QkFBOEIsVUFBVSxFQUFFLFlBQVksS0FBSyxFQUFFLG9CQUFvQixPQUFPLFFBQVEsRUFBRSxtQkFBbUIsSUFBSSxNQUFNLE1BQU0sRUFBRSxrQkFBa0IscUJBQXFCLEdBQUc7QUFDNUwsY0FBTSxLQUFLLDZDQUE2QyxVQUFVLEVBQUUsZ0JBQWdCLElBQUksT0FBTyxFQUFFLGNBQWMsSUFBSTtBQUNuSCxjQUFNLEtBQUsscUNBQXFDLFVBQVUsRUFBRSxhQUFhLElBQUksT0FBTztBQUNwRixjQUFNLEtBQUssc0RBQXNELFVBQVUsRUFBRSxjQUFjLElBQUksaUJBQWlCLEVBQUUsZ0JBQWdCLFFBQVE7QUFDMUksY0FBTSxLQUFLLG9DQUFvQyxFQUFFLGNBQWMsTUFBTTtBQUNyRSxjQUFNLEtBQUssRUFBRTtBQUNiLGNBQU0sS0FBSywwQkFBMEI7QUFDckMsY0FBTSxLQUFLLCtDQUEwQyxFQUFFLFdBQVcsUUFBUSxVQUFVLEVBQUUsV0FBVyxJQUFJLEdBQUc7QUFDeEcsY0FBTSxLQUFLLCtDQUEwQyxFQUFFLFdBQVcsUUFBUSxVQUFVLEVBQUUsV0FBVyxJQUFJLEdBQUc7QUFDeEcsY0FBTSxLQUFLLGdEQUEyQyxFQUFFLGFBQWEsUUFBUSxVQUFVLEVBQUUsYUFBYSxJQUFJLEdBQUc7QUFDN0csY0FBTSxLQUFLLEVBQUU7QUFDYixjQUFNLEtBQUssc0NBQXNDO0FBQ2pELFlBQUksT0FBTyxrQkFBa0IsV0FBVyxHQUFHO0FBQ3pDLGdCQUFNLEtBQUssbUNBQW1DO0FBQUEsUUFDaEQsT0FBTztBQUNMLGlCQUFPLGtCQUFrQixRQUFRLFNBQVUsR0FBRyxLQUFLO0FBQ2pELGtCQUFNLGFBQWEsRUFBRSxTQUFTLElBQUksZ0JBQWdCLFVBQVUsRUFBRSxNQUFNLElBQUksT0FBTyxFQUFFLGdCQUFnQixPQUFPO0FBQ3hHLGtCQUFNLEtBQU0sTUFBTSxJQUFLLE9BQU8sRUFBRSxPQUFPLFFBQVEsRUFBRSxPQUFPLFNBQVMsVUFBVSxFQUFFLE1BQU0sSUFBSSxPQUFPLEVBQUUsV0FBVyxRQUFRLEVBQUUsUUFBUSxPQUFPLFVBQVU7QUFBQSxVQUNoSixDQUFDO0FBQUEsUUFDSDtBQUNBLGNBQU0sS0FBSyxFQUFFO0FBQ2IsY0FBTSxLQUFLLDJCQUEyQjtBQUN0QyxlQUFPLGdCQUFnQixRQUFRLFNBQVUsS0FBSyxLQUFLO0FBQ2pELGdCQUFNLEtBQU0sTUFBTSxJQUFLLFVBQVUsSUFBSSxTQUFTLFlBQVksSUFBSSxPQUFPLElBQUksUUFBUSxJQUFJO0FBQ3JGLGdCQUFNLEtBQUssbUJBQW1CLElBQUksT0FBTztBQUN6QyxnQkFBTSxLQUFLLG1CQUFtQixJQUFJLE1BQU07QUFBQSxRQUMxQyxDQUFDO0FBQ0QsWUFBSSxPQUFPLGNBQWMsU0FBUyxHQUFHO0FBQ25DLGdCQUFNLEtBQUssRUFBRTtBQUNiLGdCQUFNLEtBQUssb0NBQW9DO0FBQy9DLGlCQUFPLGNBQWMsUUFBUSxTQUFVLEdBQUc7QUFDeEMsa0JBQU0sS0FBSyxPQUFPLEVBQUUsT0FBTyxRQUFRLEVBQUUsT0FBTyxTQUFTLFVBQVUsRUFBRSxlQUFlLElBQUksT0FBTyxFQUFFLFlBQVksR0FBRztBQUFBLFVBQzlHLENBQUM7QUFBQSxRQUNIO0FBQ0EsZUFBTyxNQUFNLEtBQUssSUFBSTtBQUFBLE1BQ3hCO0FBRUEsYUFBTztBQUFBLFFBQ0w7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQTtBQUFBOzs7QUN4aUJEO0FBQUE7QUFBQTtBQUVBLFFBQU0sS0FBSyxVQUFRLElBQUk7QUFDdkIsUUFBTSxPQUFPLFVBQVEsTUFBTTtBQUMzQixRQUFNLFNBQVMsVUFBUSxRQUFRO0FBQy9CLFFBQU1BLGFBQVk7QUFFbEIsUUFBTSxXQUFXLFFBQVEsSUFBSSxZQUFZLEtBQUssS0FBSyxXQUFXLE1BQU0sTUFBTTtBQUUxRSxhQUFTLGdCQUFnQjtBQUN2QixVQUFJLENBQUMsR0FBRyxXQUFXLFFBQVEsR0FBRztBQUM1QixXQUFHLFVBQVUsVUFBVSxFQUFFLFdBQVcsS0FBSyxDQUFDO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBRUEsYUFBUyxvQkFBb0IsTUFBTTtBQUNqQyxZQUFNLFFBQVEsT0FBTyxRQUFRLFNBQVMsRUFDbkMsWUFBWSxFQUNaLFFBQVEsZ0JBQWdCLEVBQUUsRUFDMUIsTUFBTSxHQUFHLEVBQUU7QUFDZCxhQUFPLFNBQVM7QUFBQSxJQUNsQjtBQUVBLGFBQVMsUUFBUSxLQUFLO0FBQ3BCLFVBQUksQ0FBQyxJQUFLLFFBQU87QUFDakIsYUFBTyxPQUFPLFdBQVcsUUFBUSxFQUFFLE9BQU8sWUFBWSxPQUFPLEdBQUcsQ0FBQyxFQUFFLE9BQU8sS0FBSztBQUFBLElBQ2pGO0FBRUEsYUFBUyx1QkFBdUIsTUFBTTtBQUNwQyxhQUFPO0FBQUEsUUFDTCxhQUFhLG9CQUFvQixJQUFJO0FBQUEsUUFDckMsVUFBVTtBQUFBLFFBQ1YsWUFBVyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUFBLFFBQ2xDLG1CQUFtQjtBQUFBLFFBQ25CLFNBQVM7QUFBQSxRQUNULFlBQVlBLFdBQVU7QUFBQSxRQUN0QixTQUFTQSxXQUFVO0FBQUEsUUFDbkIsU0FBUztBQUFBLFVBQ1AsT0FBTztBQUFBLFVBQ1AsTUFBTTtBQUFBLFVBQ04sV0FBVztBQUFBLFVBQ1gsU0FBUztBQUFBLFVBQ1QsU0FBUztBQUFBLFVBQ1QsU0FBUztBQUFBLFFBQ1g7QUFBQSxRQUNBLGNBQWMsQ0FBQztBQUFBLE1BQ2pCO0FBQUEsSUFDRjtBQUVBLGFBQVMsaUJBQWlCLE1BQU07QUFDOUIsb0JBQWM7QUFDZCxhQUFPLEtBQUssS0FBSyxVQUFVLG9CQUFvQixJQUFJLElBQUksT0FBTztBQUFBLElBQ2hFO0FBRUEsYUFBUyxjQUFjLE1BQU07QUFDM0IsWUFBTSxVQUFVLG9CQUFvQixJQUFJO0FBQ3hDLFlBQU0sV0FBVyxpQkFBaUIsT0FBTztBQUN6QyxVQUFJLENBQUMsR0FBRyxXQUFXLFFBQVEsR0FBRztBQUM1QixjQUFNLFFBQVEsdUJBQXVCLE9BQU87QUFDNUMsNkJBQXFCLFNBQVMsS0FBSztBQUNuQyxlQUFPO0FBQUEsTUFDVDtBQUNBLFVBQUk7QUFDRixjQUFNLE1BQU0sR0FBRyxhQUFhLFVBQVUsTUFBTTtBQUM1QyxjQUFNLFNBQVMsS0FBSyxNQUFNLEdBQUc7QUFDN0IsWUFBSSxDQUFDLE1BQU0sUUFBUSxPQUFPLFlBQVksRUFBRyxRQUFPLGVBQWUsQ0FBQztBQUNoRSxZQUFJLENBQUMsTUFBTSxRQUFRLE9BQU8sVUFBVSxLQUFLLENBQUMsT0FBTyxXQUFXLE9BQVEsUUFBTyxhQUFhQSxXQUFVO0FBQ2xHLFlBQUksQ0FBQyxNQUFNLFFBQVEsT0FBTyxPQUFPLEtBQUssQ0FBQyxPQUFPLFFBQVEsT0FBUSxRQUFPLFVBQVVBLFdBQVU7QUFDekYsWUFBSSxDQUFDLE9BQU8sV0FBVyxPQUFPLE9BQU8sWUFBWSxTQUFVLFFBQU8sVUFBVSxDQUFDO0FBQzdFLFlBQUksQ0FBQyxPQUFPLFNBQVUsUUFBTyxXQUFXO0FBQ3hDLGVBQU8sY0FBYztBQUNyQixlQUFPO0FBQUEsTUFDVCxTQUFTLEtBQUs7QUFDWixjQUFNLFdBQVcsdUJBQXVCLE9BQU87QUFDL0MsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsYUFBUyxxQkFBcUIsTUFBTSxNQUFNO0FBQ3hDLFlBQU0sVUFBVSxvQkFBb0IsSUFBSTtBQUN4QyxZQUFNLFdBQVcsaUJBQWlCLE9BQU87QUFDekMsWUFBTSxVQUFVLFdBQVcsTUFBTSxRQUFRLE1BQU0sTUFBTSxLQUFLLElBQUksSUFBSTtBQUNsRSxTQUFHLGNBQWMsU0FBUyxLQUFLLFVBQVUsTUFBTSxNQUFNLENBQUMsR0FBRyxNQUFNO0FBQy9ELFNBQUcsV0FBVyxTQUFTLFFBQVE7QUFBQSxJQUNqQztBQUVBLGFBQVMsbUJBQW1CLElBQUk7QUFDOUIsYUFBTztBQUFBLFFBQ0wsYUFBYSxHQUFHO0FBQUEsUUFDaEIsVUFBVSxHQUFHO0FBQUEsUUFDYixXQUFXLEdBQUc7QUFBQSxRQUNkLFFBQVEsUUFBUSxHQUFHLE9BQU87QUFBQSxRQUMxQixtQkFBbUIsR0FBRyxxQkFBcUI7QUFBQSxRQUMzQyxZQUFZLEdBQUc7QUFBQSxRQUNmLFNBQVMsR0FBRztBQUFBLFFBQ1osU0FBUyxHQUFHO0FBQUEsUUFDWixjQUFjLEdBQUcsYUFBYSxPQUFPLFNBQVUsR0FBRztBQUFFLGlCQUFPLENBQUMsRUFBRTtBQUFBLFFBQVMsQ0FBQztBQUFBLFFBQ3hFLFlBQVksR0FBRyxhQUFhLE9BQU8sU0FBVSxHQUFHO0FBQUUsaUJBQU8sRUFBRTtBQUFBLFFBQVMsQ0FBQyxFQUFFLElBQUksU0FBVSxHQUFHO0FBQ3RGLGlCQUFPLEVBQUUsSUFBSSxFQUFFLElBQUksV0FBVyxFQUFFLFdBQVcsU0FBUyxLQUFLO0FBQUEsUUFDM0QsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBRUEsYUFBUyxxQkFBcUIsSUFBSTtBQUNoQyxZQUFNLFVBQVMsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDdEMsWUFBTSxLQUFLLE9BQU8sR0FBRyxNQUFPLFFBQVEsT0FBTyxXQUFXLENBQUUsRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUNyRSxZQUFNLE9BQU8sQ0FBQyxXQUFXLFVBQVUsVUFBVSxFQUFFLFNBQVMsR0FBRyxJQUFJLElBQUksR0FBRyxPQUFPO0FBQzdFLFlBQU0sU0FBUyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sT0FBTyxHQUFHLE1BQU0sS0FBSyxDQUFDLENBQUM7QUFDN0QsWUFBTSxPQUFPLE9BQU8sR0FBRyxTQUFTLFlBQVkscUJBQXFCLEtBQUssR0FBRyxJQUFJLElBQ3pFLEdBQUcsS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUNuQixPQUFPLE1BQU0sR0FBRyxFQUFFO0FBRXRCLGFBQU87QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLFVBQVUsT0FBTyxHQUFHLGFBQWEsU0FBUyxXQUFXLFNBQVMsVUFBVSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsUUFDckYsUUFBUSxPQUFPLEdBQUcsVUFBVSxPQUFPLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxRQUNoRCxVQUFVLFNBQVMsYUFBYSxPQUFPLEdBQUcsWUFBWSxNQUFNLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSTtBQUFBLFFBQzdFO0FBQUEsUUFDQSxNQUFNLE9BQU8sR0FBRyxRQUFRLEVBQUUsRUFBRSxNQUFNLEdBQUcsR0FBRztBQUFBLFFBQ3hDLFFBQVEsT0FBTyxHQUFHLFVBQVUsS0FBSyxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsUUFDOUMsU0FBUyxRQUFRLEdBQUcsT0FBTztBQUFBLFFBQzNCLFdBQVcsR0FBRyxhQUFhO0FBQUEsUUFDM0IsV0FBVyxHQUFHLGFBQWE7QUFBQSxNQUM3QjtBQUFBLElBQ0Y7QUFFQSxhQUFTLGtCQUFrQixVQUFVLFVBQVU7QUFDN0MsWUFBTSxNQUFNLG9CQUFJLElBQUk7QUFDcEIsZUFBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztBQUN4QyxZQUFJLElBQUksU0FBUyxDQUFDLEVBQUUsSUFBSSxTQUFTLENBQUMsQ0FBQztBQUFBLE1BQ3JDO0FBQ0EsVUFBSSxVQUFVO0FBQ2QsZUFBUyxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztBQUN4QyxjQUFNLE9BQU8scUJBQXFCLFNBQVMsQ0FBQyxDQUFDO0FBQzdDLGNBQU0sT0FBTyxJQUFJLElBQUksS0FBSyxFQUFFO0FBQzVCLFlBQUksQ0FBQyxRQUFRLE9BQU8sS0FBSyxTQUFTLElBQUksT0FBTyxLQUFLLFNBQVMsR0FBRztBQUM1RCxjQUFJLElBQUksS0FBSyxJQUFJLElBQUk7QUFDckIsb0JBQVU7QUFBQSxRQUNaO0FBQUEsTUFDRjtBQUNBLFlBQU0sU0FBUyxNQUFNLEtBQUssSUFBSSxPQUFPLENBQUMsRUFBRSxLQUFLLFNBQVUsR0FBRyxHQUFHO0FBQzNELFlBQUksRUFBRSxTQUFTLEVBQUUsS0FBTSxRQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sSUFBSTtBQUNwRCxlQUFPLE9BQU8sRUFBRSxTQUFTLElBQUksT0FBTyxFQUFFLFNBQVMsSUFBSSxJQUFJO0FBQUEsTUFDekQsQ0FBQztBQUNELGFBQU8sRUFBRSxRQUFnQixRQUFpQjtBQUFBLElBQzVDO0FBRUEsYUFBUyxrQkFBa0IsTUFBTSxTQUFTO0FBQ3hDLFlBQU0sS0FBSyxjQUFjLElBQUk7QUFDN0IsWUFBTSxVQUFTLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ3RDLFlBQU0sS0FBSyxxQkFBcUIsT0FBTyxPQUFPLENBQUMsR0FBRyxTQUFTLEVBQUUsV0FBVyxPQUFPLENBQUMsQ0FBQztBQUNqRixZQUFNLE1BQU0sa0JBQWtCLEdBQUcsY0FBYyxDQUFDLEVBQUUsQ0FBQztBQUNuRCxTQUFHLGVBQWUsSUFBSTtBQUN0QixTQUFHLFlBQVk7QUFDZixTQUFHLFlBQVk7QUFDZiwyQkFBcUIsTUFBTSxFQUFFO0FBQzdCLGFBQU8sRUFBRSxXQUFXLElBQUksYUFBYSxHQUFHO0FBQUEsSUFDMUM7QUFFQSxhQUFTLGtCQUFrQixNQUFNLE1BQU07QUFDckMsWUFBTSxLQUFLLGNBQWMsSUFBSTtBQUM3QixZQUFNLFVBQVMsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDdEMsWUFBTSxXQUFXLEdBQUcsYUFBYSxLQUFLLFNBQVUsR0FBRztBQUFFLGVBQU8sRUFBRSxPQUFPO0FBQUEsTUFBTSxDQUFDO0FBQzVFLFVBQUksQ0FBQyxTQUFVLFFBQU8sRUFBRSxXQUFXLElBQUksU0FBUyxNQUFNO0FBQ3RELGVBQVMsVUFBVTtBQUNuQixlQUFTLFlBQVk7QUFDckIsU0FBRyxZQUFZO0FBQ2YsU0FBRyxZQUFZO0FBQ2YsMkJBQXFCLE1BQU0sRUFBRTtBQUM3QixhQUFPLEVBQUUsV0FBVyxJQUFJLFNBQVMsS0FBSztBQUFBLElBQ3hDO0FBRUEsYUFBUyxVQUFVLE1BQU0sU0FBUztBQUNoQyxZQUFNLEtBQUssY0FBYyxJQUFJO0FBQzdCLFlBQU0sVUFBUyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUN0QyxZQUFNLGFBQWEsTUFBTSxRQUFRLFFBQVEsWUFBWSxJQUFJLFFBQVEsZUFBZSxDQUFDO0FBQ2pGLFlBQU0sTUFBTSxrQkFBa0IsR0FBRyxjQUFjLFVBQVU7QUFDekQsVUFBSSxjQUFjO0FBRWxCLFVBQUksUUFBUSxXQUFXLE9BQU8sUUFBUSxZQUFZLFVBQVU7QUFDMUQsV0FBRyxVQUFVLE9BQU8sT0FBTyxDQUFDLEdBQUcsR0FBRyxTQUFTLFFBQVEsT0FBTztBQUMxRCxzQkFBYztBQUFBLE1BQ2hCO0FBQ0EsVUFBSSxRQUFRLHNCQUFzQixRQUFXO0FBQzNDLGNBQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxPQUFPLFFBQVEsaUJBQWlCLEtBQUssRUFBRSxDQUFDO0FBQzlFLFdBQUcsb0JBQW9CO0FBQ3ZCLHNCQUFjO0FBQUEsTUFDaEI7QUFDQSxVQUFJLE1BQU0sUUFBUSxRQUFRLE9BQU8sS0FBSyxRQUFRLFFBQVEsU0FBUyxHQUFHO0FBQ2hFLFdBQUcsVUFBVSxRQUFRO0FBQ3JCLHNCQUFjO0FBQUEsTUFDaEI7QUFFQSxVQUFJLElBQUksV0FBVyxhQUFhO0FBQzlCLFdBQUcsZUFBZSxJQUFJO0FBQ3RCLFdBQUcsWUFBWTtBQUNmLFdBQUcsWUFBWTtBQUNmLDZCQUFxQixNQUFNLEVBQUU7QUFBQSxNQUMvQjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxlQUFlLE1BQU0sU0FBUztBQUNyQyxZQUFNLEtBQUssY0FBYyxJQUFJO0FBQzdCLFlBQU0sVUFBUyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUN0QyxVQUFJLFFBQVEsV0FBVyxPQUFPLFFBQVEsWUFBWSxVQUFVO0FBQzFELGNBQU0sZUFBZSxDQUFDO0FBQ3RCLGVBQU8sS0FBSyxRQUFRLE9BQU8sRUFBRSxRQUFRLFNBQVUsR0FBRztBQUNoRCxnQkFBTSxJQUFJLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxPQUFPLFFBQVEsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakUsY0FBSSxJQUFJLEVBQUcsY0FBYSxDQUFDLElBQUk7QUFBQSxRQUMvQixDQUFDO0FBQ0QsV0FBRyxVQUFVO0FBQUEsTUFDZjtBQUNBLFVBQUksUUFBUSxzQkFBc0IsUUFBVztBQUMzQyxXQUFHLG9CQUFvQixLQUFLLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxPQUFPLFFBQVEsaUJBQWlCLEtBQUssRUFBRSxDQUFDO0FBQUEsTUFDMUY7QUFDQSxVQUFJLE1BQU0sUUFBUSxRQUFRLE9BQU8sS0FBSyxRQUFRLFFBQVEsU0FBUyxHQUFHO0FBQ2hFLFdBQUcsVUFBVSxRQUFRLFFBQVEsSUFBSSxTQUFVLEdBQUc7QUFDNUMsaUJBQU87QUFBQSxZQUNMLElBQUksT0FBTyxFQUFFLE1BQU0sUUFBUSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsWUFDeEMsTUFBTSxPQUFPLEVBQUUsUUFBUSxRQUFRLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxZQUM1QyxNQUFNLE9BQU8sRUFBRSxRQUFRLFdBQUksRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUFBLFlBQ3ZDLGdCQUFnQixPQUFPLEVBQUUsY0FBYyxLQUFLO0FBQUEsVUFDOUM7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQ0EsVUFBSSxRQUFRLFdBQVcsUUFBVztBQUNoQyxXQUFHLFVBQVUsUUFBUSxTQUFTLFFBQVEsUUFBUSxNQUFNLElBQUk7QUFBQSxNQUMxRDtBQUNBLFNBQUcsWUFBWTtBQUNmLFNBQUcsWUFBWTtBQUNmLDJCQUFxQixNQUFNLEVBQUU7QUFDN0IsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLGlCQUFpQixTQUFTO0FBQ2pDLFlBQU0sTUFBTSxtQkFBbUIsT0FBTyxVQUFVLG9CQUFJLEtBQUs7QUFDekQsWUFBTSxLQUFLLElBQUksWUFBWSxJQUFJLE1BQU0sT0FBTyxJQUFJLFNBQVMsSUFBSSxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUc7QUFDL0UsWUFBTSxXQUFXLElBQUksS0FBSyxJQUFJLFlBQVksR0FBRyxJQUFJLFNBQVMsSUFBSSxHQUFHLEVBQUU7QUFDbkUsWUFBTSxTQUFTLFNBQVMsWUFBWSxJQUFJLE1BQU0sT0FBTyxTQUFTLFNBQVMsSUFBSSxDQUFDLEVBQUUsU0FBUyxHQUFHLEdBQUc7QUFDN0YsWUFBTSxNQUFNLFNBQVUsR0FBRyxHQUFHO0FBQzFCLGNBQU0sT0FBTyxJQUFJLEtBQUssT0FBTyxFQUFFLE1BQU0sR0FBRyxDQUFDLENBQUMsR0FBRyxPQUFPLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxRQUFRO0FBQy9FLGNBQU0sUUFBUSxLQUFLLElBQUksR0FBRyxJQUFJO0FBQzlCLGVBQU8sSUFBSSxNQUFNLE9BQU8sS0FBSyxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQUEsTUFDaEQ7QUFFQSxhQUFPO0FBQUE7QUFBQSxRQUVMLEVBQUUsSUFBSSxXQUFXLE1BQU0sVUFBVSxRQUFRLE1BQVMsVUFBVSxRQUFRLFFBQVEsUUFBUSxNQUFNLElBQUksUUFBUSxDQUFDLEdBQUcsTUFBTSxnQkFBZ0IsUUFBUSxVQUFVO0FBQUEsUUFDbEosRUFBRSxJQUFJLFdBQVcsTUFBTSxXQUFXLFFBQVEsTUFBUyxVQUFVLFdBQVcsUUFBUSxRQUFRLE1BQU0sSUFBSSxRQUFRLENBQUMsR0FBRyxNQUFNLGlCQUFpQixRQUFRLFVBQVU7QUFBQSxRQUN2SixFQUFFLElBQUksV0FBVyxNQUFNLFdBQVcsUUFBUSxNQUFTLFVBQVUsU0FBUyxRQUFRLFdBQVcsTUFBTSxJQUFJLFFBQVEsRUFBRSxHQUFHLE1BQU0seUJBQXlCLFFBQVEsVUFBVTtBQUFBLFFBQ2pLLEVBQUUsSUFBSSxXQUFXLE1BQU0sV0FBVyxRQUFRLE1BQVEsVUFBVSxRQUFRLFFBQVEsV0FBVyxNQUFNLElBQUksUUFBUSxFQUFFLEdBQUcsTUFBTSxxQkFBcUIsUUFBUSxVQUFVO0FBQUEsUUFDM0osRUFBRSxJQUFJLFdBQVcsTUFBTSxXQUFXLFFBQVEsTUFBUSxVQUFVLGFBQWEsUUFBUSxXQUFXLE1BQU0sSUFBSSxRQUFRLEVBQUUsR0FBRyxNQUFNLGlCQUFpQixRQUFRLFVBQVU7QUFBQSxRQUM1SixFQUFFLElBQUksV0FBVyxNQUFNLFdBQVcsUUFBUSxLQUFTLFVBQVUsWUFBWSxRQUFRLFFBQVEsTUFBTSxJQUFJLFFBQVEsRUFBRSxHQUFHLE1BQU0sc0JBQXNCLFFBQVEsVUFBVTtBQUFBO0FBQUEsUUFHOUosRUFBRSxJQUFJLFdBQVcsTUFBTSxVQUFVLFFBQVEsTUFBUyxVQUFVLFFBQVEsUUFBUSxRQUFRLE1BQU0sSUFBSSxJQUFJLENBQUMsR0FBRyxNQUFNLGdCQUFnQixRQUFRLFVBQVU7QUFBQSxRQUM5SSxFQUFFLElBQUksV0FBVyxNQUFNLFVBQVUsUUFBUSxNQUFRLFVBQVUsU0FBUyxRQUFRLFFBQVEsTUFBTSxJQUFJLElBQUksQ0FBQyxHQUFHLE1BQU0sd0JBQXdCLFFBQVEsVUFBVTtBQUFBLFFBQ3RKLEVBQUUsSUFBSSxXQUFXLE1BQU0sWUFBWSxRQUFRLE1BQVMsVUFBVSxXQUFXLFFBQVEsUUFBUSxVQUFVLFdBQVcsTUFBTSxJQUFJLElBQUksQ0FBQyxHQUFHLE1BQU0sMkJBQTJCLFFBQVEsVUFBVTtBQUFBLFFBQ25MLEVBQUUsSUFBSSxXQUFXLE1BQU0sWUFBWSxRQUFRLEtBQVEsVUFBVSxXQUFXLFFBQVEsUUFBUSxVQUFVLFNBQVMsTUFBTSxJQUFJLElBQUksQ0FBQyxHQUFHLE1BQU0sbUJBQW1CLFFBQVEsVUFBVTtBQUFBLFFBQ3hLLEVBQUUsSUFBSSxXQUFXLE1BQU0sV0FBVyxRQUFRLE9BQVMsVUFBVSxXQUFXLFFBQVEsUUFBUSxNQUFNLElBQUksSUFBSSxDQUFDLEdBQUcsTUFBTSx1QkFBdUIsUUFBUSxVQUFVO0FBQUEsUUFDekosRUFBRSxJQUFJLFdBQVcsTUFBTSxXQUFXLFFBQVEsTUFBUSxVQUFVLFdBQVcsUUFBUSxXQUFXLE1BQU0sSUFBSSxJQUFJLENBQUMsR0FBRyxNQUFNLGtDQUFrQyxRQUFRLFVBQVU7QUFBQSxRQUN0SyxFQUFFLElBQUksV0FBVyxNQUFNLFdBQVcsUUFBUSxNQUFRLFVBQVUsU0FBUyxRQUFRLFdBQVcsTUFBTSxJQUFJLElBQUksQ0FBQyxHQUFHLE1BQU0sK0JBQStCLFFBQVEsVUFBVTtBQUFBLFFBQ2pLLEVBQUUsSUFBSSxXQUFXLE1BQU0sV0FBVyxRQUFRLE1BQU8sVUFBVSxRQUFRLFFBQVEsV0FBVyxNQUFNLElBQUksSUFBSSxDQUFDLEdBQUcsTUFBTSxvQkFBb0IsUUFBUSxVQUFVO0FBQUEsUUFDcEosRUFBRSxJQUFJLFdBQVcsTUFBTSxXQUFXLFFBQVEsTUFBTyxVQUFVLFFBQVEsUUFBUSxXQUFXLE1BQU0sSUFBSSxJQUFJLENBQUMsR0FBRyxNQUFNLGdCQUFnQixRQUFRLFVBQVU7QUFBQSxRQUNoSixFQUFFLElBQUksWUFBWSxNQUFNLFdBQVcsUUFBUSxNQUFRLFVBQVUsYUFBYSxRQUFRLFdBQVcsTUFBTSxJQUFJLElBQUksQ0FBQyxHQUFHLE1BQU0seUJBQXlCLFFBQVEsVUFBVTtBQUFBLFFBQ2hLLEVBQUUsSUFBSSxZQUFZLE1BQU0sV0FBVyxRQUFRLE9BQVEsVUFBVSxXQUFXLFFBQVEsUUFBUSxNQUFNLElBQUksSUFBSSxFQUFFLEdBQUcsTUFBTSxxQkFBcUIsUUFBUSxVQUFVO0FBQUEsUUFDeEosRUFBRSxJQUFJLFlBQVksTUFBTSxXQUFXLFFBQVEsTUFBUSxVQUFVLFNBQVMsUUFBUSxTQUFTLE1BQU0sSUFBSSxJQUFJLEVBQUUsR0FBRyxNQUFNLHlCQUF5QixRQUFRLFVBQVU7QUFBQSxRQUMzSixFQUFFLElBQUksWUFBWSxNQUFNLFdBQVcsUUFBUSxNQUFPLFVBQVUsUUFBUSxRQUFRLFdBQVcsTUFBTSxJQUFJLElBQUksRUFBRSxHQUFHLE1BQU0sa0JBQWtCLFFBQVEsVUFBVTtBQUFBLFFBQ3BKLEVBQUUsSUFBSSxZQUFZLE1BQU0sV0FBVyxRQUFRLE1BQU8sVUFBVSxRQUFRLFFBQVEsV0FBVyxNQUFNLElBQUksSUFBSSxFQUFFLEdBQUcsTUFBTSxpQkFBaUIsUUFBUSxVQUFVO0FBQUEsUUFDbkosRUFBRSxJQUFJLFlBQVksTUFBTSxXQUFXLFFBQVEsTUFBUSxVQUFVLGFBQWEsUUFBUSxTQUFTLE1BQU0sSUFBSSxJQUFJLEVBQUUsR0FBRyxNQUFNLHVCQUF1QixRQUFRLFVBQVU7QUFBQSxRQUM3SixFQUFFLElBQUksWUFBWSxNQUFNLFdBQVcsUUFBUSxNQUFRLFVBQVUsU0FBUyxRQUFRLFdBQVcsTUFBTSxJQUFJLElBQUksRUFBRSxHQUFHLE1BQU0sNkJBQTZCLFFBQVEsVUFBVTtBQUFBLFFBQ2pLLEVBQUUsSUFBSSxZQUFZLE1BQU0sV0FBVyxRQUFRLE9BQVEsVUFBVSxXQUFXLFFBQVEsV0FBVyxNQUFNLElBQUksSUFBSSxFQUFFLEdBQUcsTUFBTSwwQkFBMEIsUUFBUSxVQUFVO0FBQUEsUUFDaEssRUFBRSxJQUFJLFlBQVksTUFBTSxXQUFXLFFBQVEsTUFBTyxVQUFVLFFBQVEsUUFBUSxXQUFXLE1BQU0sSUFBSSxJQUFJLEVBQUUsR0FBRyxNQUFNLHlCQUF5QixRQUFRLFVBQVU7QUFBQSxRQUMzSixFQUFFLElBQUksWUFBWSxNQUFNLFdBQVcsUUFBUSxNQUFTLFVBQVUsWUFBWSxRQUFRLFFBQVEsTUFBTSxJQUFJLElBQUksRUFBRSxHQUFHLE1BQU0sNkJBQTZCLFFBQVEsVUFBVTtBQUFBLE1BQ3BLO0FBQUEsSUFDRjtBQUVBLGFBQVMsYUFBYSxNQUFNLFNBQVM7QUFDbkMsWUFBTSxLQUFLLFVBQVUsTUFBTSxFQUFFLGNBQWMsaUJBQWlCLE9BQU8sRUFBRSxDQUFDO0FBQ3RFLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTyxVQUFVO0FBQUEsTUFDZjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQTtBQUFBOzs7QUMzU0E7QUFBQTtBQUFBO0FBRUEsUUFBTSxFQUFFLFlBQVksSUFBSSxVQUFRLG1CQUFtQjtBQUNuRCxRQUFNQyxXQUFVO0FBRWhCLFFBQUksYUFBYTtBQUVqQixhQUFTLFFBQVE7QUFDZixVQUFJLENBQUMsWUFBWTtBQUNmLHFCQUFhLFlBQVk7QUFBQSxNQUMzQjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxTQUFTLEtBQUs7QUFDckIsYUFBTztBQUFBLFFBQ0wsSUFBSSxJQUFJO0FBQUEsUUFDUixNQUFNLElBQUk7QUFBQSxRQUNWLFFBQVEsT0FBTyxJQUFJLE1BQU0sS0FBSztBQUFBLFFBQzlCLFVBQVUsSUFBSTtBQUFBLFFBQ2QsUUFBUSxJQUFJO0FBQUEsUUFDWixVQUFVLElBQUksYUFBYTtBQUFBLFFBQzNCLE1BQU0sSUFBSTtBQUFBLFFBQ1YsTUFBTSxJQUFJLFFBQVE7QUFBQSxRQUNsQixRQUFRLElBQUksVUFBVTtBQUFBLFFBQ3RCLFNBQVMsUUFBUSxJQUFJLE9BQU87QUFBQSxRQUM1QixXQUFXLElBQUk7QUFBQSxRQUNmLFdBQVcsSUFBSTtBQUFBLE1BQ2pCO0FBQUEsSUFDRjtBQUVBLGFBQVMsZ0JBQWdCLEtBQUssY0FBYztBQUMxQyxZQUFNLE1BQU1BLFNBQVEsdUJBQXVCLElBQUksWUFBWTtBQUMzRCxhQUFPO0FBQUEsUUFDTCxhQUFhLElBQUk7QUFBQSxRQUNqQixVQUFVLE9BQU8sSUFBSSxRQUFRLEtBQUs7QUFBQSxRQUNsQyxXQUFXLElBQUksS0FBSyxJQUFJLFVBQVUsRUFBRSxZQUFZO0FBQUEsUUFDaEQsbUJBQW1CLE9BQU8sSUFBSSxtQkFBbUIsS0FBSztBQUFBLFFBQ3RELFNBQVMsSUFBSSxZQUFZO0FBQUEsUUFDekIsWUFBWSxNQUFNLFFBQVEsSUFBSSxVQUFVLEtBQUssSUFBSSxXQUFXLFNBQVMsSUFBSSxhQUFhLElBQUk7QUFBQSxRQUMxRixTQUFTLE1BQU0sUUFBUSxJQUFJLE9BQU8sS0FBSyxJQUFJLFFBQVEsU0FBUyxJQUFJLFVBQVUsSUFBSTtBQUFBLFFBQzlFLFNBQVMsSUFBSSxXQUFXLE9BQU8sSUFBSSxZQUFZLFdBQVcsSUFBSSxVQUFVLENBQUM7QUFBQSxRQUN6RSxjQUFjLGdCQUFnQixDQUFDO0FBQUEsTUFDakM7QUFBQSxJQUNGO0FBRUEsbUJBQWUsbUJBQW1CLFFBQVEsTUFBTSxlQUFlO0FBQzdELFlBQU0sVUFBVUEsU0FBUSxvQkFBb0IsSUFBSTtBQUNoRCxZQUFNLE1BQU1BLFNBQVEsdUJBQXVCLE9BQU87QUFFbEQsWUFBTSxPQUFPO0FBQUEsUUFDWDtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSUE7QUFBQSxVQUNFO0FBQUEsVUFDQSxJQUFJO0FBQUEsVUFDSixJQUFJO0FBQUEsVUFDSixJQUFJO0FBQUEsVUFDSixJQUFJO0FBQUEsVUFDSixLQUFLLFVBQVUsSUFBSSxVQUFVO0FBQUEsVUFDN0IsS0FBSyxVQUFVLElBQUksT0FBTztBQUFBLFVBQzFCLEtBQUssVUFBVSxJQUFJLE9BQU87QUFBQSxRQUM1QjtBQUFBLE1BQ0Y7QUFFQSxZQUFNLFNBQVMsZ0JBQWdCLGdCQUFnQjtBQUMvQyxZQUFNLE1BQU0sTUFBTSxPQUFPO0FBQUEsUUFDdkI7QUFBQSw4Q0FDMEMsTUFBTTtBQUFBLFFBQ2hELENBQUMsT0FBTztBQUFBLE1BQ1Y7QUFDQSxhQUFPLElBQUksS0FBSyxDQUFDO0FBQUEsSUFDbkI7QUFFQSxtQkFBZSx3QkFBd0IsUUFBUSxNQUFNO0FBQ25ELFlBQU0sUUFBUSxNQUFNLG1CQUFtQixRQUFRLE1BQU0sS0FBSztBQUMxRCxZQUFNLFFBQVEsTUFBTSxPQUFPO0FBQUEsUUFDekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlBLENBQUMsTUFBTSxZQUFZO0FBQUEsTUFDckI7QUFDQSxhQUFPLGdCQUFnQixPQUFPLE1BQU0sS0FBSyxJQUFJLFFBQVEsQ0FBQztBQUFBLElBQ3hEO0FBRUEsbUJBQWUsZ0JBQWdCLElBQUk7QUFDakMsWUFBTSxLQUFLLE1BQU07QUFDakIsWUFBTSxTQUFTLE1BQU0sR0FBRyxLQUFLLFFBQVE7QUFDckMsVUFBSTtBQUNGLGNBQU0sT0FBTyxNQUFNLE9BQU87QUFDMUIsY0FBTSxTQUFTLE1BQU0sR0FBRyxNQUFNO0FBQzlCLGNBQU0sT0FBTyxNQUFNLFFBQVE7QUFDM0IsZUFBTztBQUFBLE1BQ1QsU0FBUyxLQUFLO0FBQ1osY0FBTSxPQUFPLE1BQU0sVUFBVTtBQUM3QixjQUFNO0FBQUEsTUFDUixVQUFFO0FBQ0EsZUFBTyxRQUFRO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBRUEsbUJBQWUsWUFBWSxRQUFRLE1BQU0sSUFBSTtBQUMzQyxZQUFNLE1BQU0sTUFBTSxPQUFPO0FBQUEsUUFDdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQWdCQTtBQUFBLFVBQ0U7QUFBQSxVQUNBLEdBQUc7QUFBQSxVQUNILEdBQUc7QUFBQSxVQUNILEdBQUc7QUFBQSxVQUNILEdBQUc7QUFBQSxVQUNILEdBQUc7QUFBQSxVQUNILEdBQUcsWUFBWTtBQUFBLFVBQ2YsR0FBRztBQUFBLFVBQ0gsR0FBRztBQUFBLFVBQ0gsR0FBRztBQUFBLFVBQ0gsR0FBRztBQUFBLFVBQ0gsR0FBRztBQUFBLFVBQ0gsR0FBRztBQUFBLFFBQ0w7QUFBQSxNQUNGO0FBQ0EsYUFBTyxJQUFJLFdBQVc7QUFBQSxJQUN4QjtBQUVBLG1CQUFlLGtCQUFrQixNQUFNO0FBQ3JDLFlBQU0sS0FBSyxNQUFNO0FBQ2pCLFlBQU0sU0FBUyxNQUFNLEdBQUcsS0FBSyxRQUFRO0FBQ3JDLFVBQUk7QUFDRixjQUFNLE1BQU0sTUFBTSxtQkFBbUIsUUFBUSxNQUFNLEtBQUs7QUFDeEQsZUFBTyxnQkFBZ0IsS0FBSyxDQUFDLENBQUM7QUFBQSxNQUNoQyxVQUFFO0FBQ0EsZUFBTyxRQUFRO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBRUEsbUJBQWUsY0FBYyxNQUFNO0FBQ2pDLFlBQU0sS0FBSyxNQUFNO0FBQ2pCLFlBQU0sU0FBUyxNQUFNLEdBQUcsS0FBSyxRQUFRO0FBQ3JDLFVBQUk7QUFDRixlQUFPLE1BQU0sd0JBQXdCLFFBQVEsSUFBSTtBQUFBLE1BQ25ELFVBQUU7QUFDQSxlQUFPLFFBQVE7QUFBQSxNQUNqQjtBQUFBLElBQ0Y7QUFFQSxtQkFBZSxrQkFBa0IsTUFBTSxTQUFTO0FBQzlDLFlBQU0sVUFBVUEsU0FBUSxvQkFBb0IsSUFBSTtBQUNoRCxZQUFNLFVBQVMsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDdEMsWUFBTSxLQUFLQSxTQUFRLHFCQUFxQixPQUFPLE9BQU8sQ0FBQyxHQUFHLFNBQVMsRUFBRSxXQUFXLE9BQU8sQ0FBQyxDQUFDO0FBRXpGLGFBQU8sZ0JBQWdCLGVBQWdCLFFBQVE7QUFDN0MsY0FBTSxRQUFRLE1BQU0sbUJBQW1CLFFBQVEsU0FBUyxJQUFJO0FBQzVELGNBQU0sWUFBWSxRQUFRLFNBQVMsRUFBRTtBQUNyQyxjQUFNLFVBQVUsT0FBTyxNQUFNLFFBQVEsSUFBSTtBQUN6QyxjQUFNLE9BQU87QUFBQSxVQUNYO0FBQUEsVUFDQSxDQUFDLFNBQVMsU0FBUyxNQUFNO0FBQUEsUUFDM0I7QUFDQSxjQUFNLFdBQVc7QUFDakIsY0FBTSxhQUFhO0FBQ25CLGVBQU8sRUFBRSxXQUFXLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxHQUFHLGFBQWEsR0FBRztBQUFBLE1BQ2xFLENBQUM7QUFBQSxJQUNIO0FBRUEsbUJBQWUsa0JBQWtCLE1BQU0sTUFBTTtBQUMzQyxZQUFNLFVBQVVBLFNBQVEsb0JBQW9CLElBQUk7QUFDaEQsWUFBTSxVQUFTLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBRXRDLGFBQU8sZ0JBQWdCLGVBQWdCLFFBQVE7QUFDN0MsY0FBTSxRQUFRLE1BQU0sbUJBQW1CLFFBQVEsU0FBUyxJQUFJO0FBQzVELGNBQU0sU0FBUyxNQUFNLE9BQU87QUFBQSxVQUMxQjtBQUFBO0FBQUE7QUFBQSxVQUdBLENBQUMsU0FBUyxNQUFNLE1BQU07QUFBQSxRQUN4QjtBQUNBLGNBQU0sVUFBVSxPQUFPLFdBQVc7QUFDbEMsWUFBSSxTQUFTO0FBQ1gsZ0JBQU0sVUFBVSxPQUFPLE1BQU0sUUFBUSxJQUFJO0FBQ3pDLGdCQUFNLE9BQU87QUFBQSxZQUNYO0FBQUEsWUFDQSxDQUFDLFNBQVMsU0FBUyxNQUFNO0FBQUEsVUFDM0I7QUFDQSxnQkFBTSxXQUFXO0FBQ2pCLGdCQUFNLGFBQWE7QUFBQSxRQUNyQjtBQUNBLGVBQU8sRUFBRSxXQUFXLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxHQUFHLFFBQWlCO0FBQUEsTUFDbkUsQ0FBQztBQUFBLElBQ0g7QUFFQSxtQkFBZSxVQUFVLE1BQU0sU0FBUztBQUN0QyxZQUFNLFVBQVVBLFNBQVEsb0JBQW9CLElBQUk7QUFDaEQsWUFBTSxVQUFTLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQ3RDLFlBQU0sYUFBYSxNQUFNLFFBQVEsUUFBUSxZQUFZLElBQUksUUFBUSxlQUFlLENBQUM7QUFFakYsYUFBTyxnQkFBZ0IsZUFBZ0IsUUFBUTtBQUM3QyxjQUFNLFFBQVEsTUFBTSxtQkFBbUIsUUFBUSxTQUFTLElBQUk7QUFDNUQsY0FBTSxVQUFVLGdCQUFnQixPQUFPLENBQUMsQ0FBQztBQUN6QyxZQUFJLFVBQVU7QUFFZCxpQkFBUyxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztBQUMxQyxnQkFBTSxPQUFPQSxTQUFRLHFCQUFxQixXQUFXLENBQUMsQ0FBQztBQUN2RCxnQkFBTSxVQUFVLE1BQU0sWUFBWSxRQUFRLFNBQVMsSUFBSTtBQUN2RCxjQUFJLFFBQVMsV0FBVTtBQUFBLFFBQ3pCO0FBRUEsWUFBSSxjQUFjO0FBQ2xCLFlBQUksUUFBUSxXQUFXLE9BQU8sUUFBUSxZQUFZLFVBQVU7QUFDMUQsa0JBQVEsVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLFFBQVEsU0FBUyxRQUFRLE9BQU87QUFDcEUsd0JBQWM7QUFBQSxRQUNoQjtBQUNBLFlBQUksUUFBUSxzQkFBc0IsUUFBVztBQUMzQyxrQkFBUSxvQkFBb0IsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLElBQUksT0FBTyxRQUFRLGlCQUFpQixLQUFLLEVBQUUsQ0FBQztBQUM3Rix3QkFBYztBQUFBLFFBQ2hCO0FBQ0EsWUFBSSxNQUFNLFFBQVEsUUFBUSxPQUFPLEtBQUssUUFBUSxRQUFRLFNBQVMsR0FBRztBQUNoRSxrQkFBUSxVQUFVLFFBQVE7QUFDMUIsd0JBQWM7QUFBQSxRQUNoQjtBQUVBLFlBQUksV0FBVyxhQUFhO0FBQzFCLGdCQUFNLFVBQVUsUUFBUSxXQUFXO0FBQ25DLGdCQUFNLE9BQU87QUFBQSxZQUNYO0FBQUE7QUFBQTtBQUFBLFlBR0E7QUFBQSxjQUNFO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBLFFBQVE7QUFBQSxjQUNSLEtBQUssVUFBVSxRQUFRLE9BQU87QUFBQSxjQUM5QixLQUFLLFVBQVUsUUFBUSxPQUFPO0FBQUEsWUFDaEM7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUVBLGVBQU8sd0JBQXdCLFFBQVEsT0FBTztBQUFBLE1BQ2hELENBQUM7QUFBQSxJQUNIO0FBRUEsbUJBQWUsZUFBZSxNQUFNLFNBQVM7QUFDM0MsWUFBTSxVQUFVQSxTQUFRLG9CQUFvQixJQUFJO0FBQ2hELFlBQU0sVUFBUyxvQkFBSSxLQUFLLEdBQUUsWUFBWTtBQUV0QyxhQUFPLGdCQUFnQixlQUFnQixRQUFRO0FBQzdDLGNBQU0sUUFBUSxNQUFNLG1CQUFtQixRQUFRLFNBQVMsSUFBSTtBQUM1RCxjQUFNLFVBQVUsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDO0FBRXpDLFlBQUksUUFBUSxXQUFXLE9BQU8sUUFBUSxZQUFZLFVBQVU7QUFDMUQsZ0JBQU0sZUFBZSxDQUFDO0FBQ3RCLGlCQUFPLEtBQUssUUFBUSxPQUFPLEVBQUUsUUFBUSxTQUFVLEdBQUc7QUFDaEQsa0JBQU0sSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sT0FBTyxRQUFRLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2pFLGdCQUFJLElBQUksRUFBRyxjQUFhLENBQUMsSUFBSTtBQUFBLFVBQy9CLENBQUM7QUFDRCxrQkFBUSxVQUFVO0FBQUEsUUFDcEI7QUFDQSxZQUFJLFFBQVEsc0JBQXNCLFFBQVc7QUFDM0Msa0JBQVEsb0JBQW9CLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxJQUFJLE9BQU8sUUFBUSxpQkFBaUIsS0FBSyxFQUFFLENBQUM7QUFBQSxRQUMvRjtBQUNBLFlBQUksTUFBTSxRQUFRLFFBQVEsT0FBTyxLQUFLLFFBQVEsUUFBUSxTQUFTLEdBQUc7QUFDaEUsa0JBQVEsVUFBVSxRQUFRLFFBQVEsSUFBSSxTQUFVLEdBQUc7QUFDakQsbUJBQU87QUFBQSxjQUNMLElBQUksT0FBTyxFQUFFLE1BQU0sUUFBUSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBQUEsY0FDeEMsTUFBTSxPQUFPLEVBQUUsUUFBUSxRQUFRLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxjQUM1QyxNQUFNLE9BQU8sRUFBRSxRQUFRLFdBQUksRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUFBLGNBQ3ZDLGdCQUFnQixPQUFPLEVBQUUsY0FBYyxLQUFLO0FBQUEsWUFDOUM7QUFBQSxVQUNGLENBQUM7QUFBQSxRQUNIO0FBQ0EsWUFBSSxRQUFRLFdBQVcsUUFBVztBQUNoQyxrQkFBUSxVQUFVLFFBQVEsU0FBU0EsU0FBUSxRQUFRLFFBQVEsTUFBTSxJQUFJO0FBQUEsUUFDdkU7QUFFQSxjQUFNLFVBQVUsUUFBUSxXQUFXO0FBQ25DLGNBQU0sT0FBTztBQUFBLFVBQ1g7QUFBQTtBQUFBO0FBQUEsVUFHQTtBQUFBLFlBQ0U7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0EsUUFBUTtBQUFBLFlBQ1IsUUFBUTtBQUFBLFlBQ1IsS0FBSyxVQUFVLFFBQVEsT0FBTztBQUFBLFlBQzlCLEtBQUssVUFBVSxRQUFRLE9BQU87QUFBQSxVQUNoQztBQUFBLFFBQ0Y7QUFFQSxlQUFPLHdCQUF3QixRQUFRLE9BQU87QUFBQSxNQUNoRCxDQUFDO0FBQUEsSUFDSDtBQUVBLG1CQUFlLGFBQWEsTUFBTSxTQUFTO0FBQ3pDLGFBQU8sVUFBVSxNQUFNLEVBQUUsY0FBY0EsU0FBUSxpQkFBaUIsT0FBTyxFQUFFLENBQUM7QUFBQSxJQUM1RTtBQUVBLFdBQU8sVUFBVTtBQUFBLE1BQ2Y7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUE7QUFBQTs7O0FDbFVBLHFCQUFvQjtBQUNwQix3QkFBc0I7QUFDdEIsdUJBQXNCO0FBRXRCLFNBQVMsYUFBYSxRQUFnQixNQUF5QjtBQUM3RCxTQUFPLElBQUksU0FBUyxLQUFLLFVBQVUsSUFBSSxHQUFHO0FBQUEsSUFDeEM7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQLGdCQUFnQjtBQUFBLE1BQ2hCLGlCQUFpQjtBQUFBLElBQ25CO0FBQUEsRUFDRixDQUFDO0FBQ0g7QUFFQSxTQUFTLFNBQVMsSUFBZ0MsS0FBYyxLQUFtQjtBQUNqRixNQUFJLENBQUMsR0FBRyxRQUFTLFFBQU87QUFDeEIsUUFBTSxNQUFNLElBQUksUUFBUSxJQUFJLGlCQUFpQixLQUFLLElBQUksYUFBYSxJQUFJLEtBQUssS0FBSztBQUNqRixTQUFPLGVBQUFDLFFBQVEsUUFBUSxHQUFHLE1BQU0sR0FBRztBQUNyQztBQUVBLGVBQWUsY0FBYyxLQUFnRDtBQUMzRSxRQUFNLE1BQU0sTUFBTSxJQUFJLEtBQUs7QUFDM0IsTUFBSSxDQUFDLElBQUssUUFBTyxDQUFDO0FBQ2xCLE1BQUksSUFBSSxTQUFTLElBQUksT0FBTyxNQUFNO0FBQ2hDLFVBQU0sSUFBSSxNQUFNLG1CQUFtQjtBQUFBLEVBQ3JDO0FBQ0EsTUFBSTtBQUNGLFdBQU8sS0FBSyxNQUFNLEdBQUc7QUFBQSxFQUN2QixRQUFRO0FBQ04sVUFBTSxJQUFJLE1BQU0sbUJBQW1CO0FBQUEsRUFDckM7QUFDRjtBQUVBLElBQU8sY0FBUSxPQUFPLFFBQW9DO0FBQ3hELFFBQU0sTUFBTSxJQUFJLElBQUksSUFBSSxHQUFHO0FBQzNCLFFBQU0sV0FBVyxJQUFJO0FBQ3JCLFFBQU0sT0FBTyxlQUFBQSxRQUFRLG9CQUFvQixJQUFJLGFBQWEsSUFBSSxJQUFJLEtBQUssU0FBUztBQUVoRixNQUFJO0FBQ0YsUUFBSSxhQUFhLGlCQUFpQixJQUFJLFdBQVcsT0FBTztBQUN0RCxhQUFPLGFBQWEsS0FBSztBQUFBLFFBQ3ZCLElBQUk7QUFBQSxRQUNKLFNBQVM7QUFBQSxRQUNULFNBQVM7QUFBQSxRQUNULE9BQU0sb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFBQSxRQUM3QixTQUFTLENBQUM7QUFBQSxNQUNaLENBQUM7QUFBQSxJQUNIO0FBRUEsUUFBSSxhQUFhLGlCQUFpQixJQUFJLFdBQVcsT0FBTztBQUN0RCxZQUFNLEtBQUssTUFBTSxrQkFBQUMsUUFBVSxrQkFBa0IsSUFBSTtBQUNqRCxVQUFJLENBQUMsU0FBUyxJQUFJLEtBQUssR0FBRyxHQUFHO0FBQzNCLGVBQU8sYUFBYSxLQUFLLEVBQUUsT0FBTyx1Q0FBdUMsYUFBYSxLQUFLLENBQUM7QUFBQSxNQUM5RjtBQUdBLGFBQU8sSUFBSSxTQUFTLE1BQU07QUFBQSxRQUN4QixRQUFRO0FBQUEsUUFDUixTQUFTLEVBQUUsaUJBQWlCLFdBQVc7QUFBQSxNQUN6QyxDQUFDO0FBQUEsSUFDSDtBQUVBLFFBQUksYUFBYSxvQkFBb0IsSUFBSSxXQUFXLE9BQU87QUFDekQsWUFBTSxLQUFLLE1BQU0sa0JBQUFBLFFBQVUsY0FBYyxJQUFJO0FBQzdDLFVBQUksQ0FBQyxTQUFTLElBQUksS0FBSyxHQUFHLEdBQUc7QUFDM0IsZUFBTyxhQUFhLEtBQUssRUFBRSxPQUFPLHVDQUF1QyxhQUFhLEtBQUssQ0FBQztBQUFBLE1BQzlGO0FBQ0EsWUFBTSxRQUFRLElBQUksYUFBYSxJQUFJLE9BQU8sS0FBSztBQUMvQyxZQUFNLE9BQU8sZUFBQUQsUUFBUSxtQkFBbUIsRUFBRTtBQUMxQyxXQUFLLFNBQVMsaUJBQUFFLFFBQVUsYUFBYSxJQUFJLEtBQUs7QUFDOUMsYUFBTyxhQUFhLEtBQUssSUFBSTtBQUFBLElBQy9CO0FBRUEsUUFBSSxhQUFhLGdCQUFnQixJQUFJLFdBQVcsT0FBTztBQUNyRCxZQUFNLEtBQUssTUFBTSxrQkFBQUQsUUFBVSxjQUFjLElBQUk7QUFDN0MsVUFBSSxDQUFDLFNBQVMsSUFBSSxLQUFLLEdBQUcsR0FBRztBQUMzQixlQUFPLGFBQWEsS0FBSyxFQUFFLE9BQU8sdUNBQXVDLGFBQWEsS0FBSyxDQUFDO0FBQUEsTUFDOUY7QUFDQSxZQUFNLFFBQVEsSUFBSSxhQUFhLElBQUksT0FBTyxLQUFLO0FBQy9DLFlBQU0sU0FBUyxJQUFJLGFBQWEsSUFBSSxRQUFRLEtBQUs7QUFDakQsWUFBTSxTQUFTLGlCQUFBQyxRQUFVLGFBQWEsSUFBSSxLQUFLO0FBQy9DLFVBQUksV0FBVyxRQUFRLFdBQVcsWUFBWTtBQUM1QyxlQUFPLElBQUksU0FBUyxpQkFBQUEsUUFBVSxvQkFBb0IsTUFBTSxHQUFHO0FBQUEsVUFDekQsUUFBUTtBQUFBLFVBQ1IsU0FBUztBQUFBLFlBQ1AsZ0JBQWdCO0FBQUEsWUFDaEIsaUJBQWlCO0FBQUEsVUFDbkI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQ0EsYUFBTyxhQUFhLEtBQUssTUFBTTtBQUFBLElBQ2pDO0FBRUEsUUFBSSxhQUFhLHVCQUF1QixJQUFJLFdBQVcsUUFBUTtBQUM3RCxZQUFNLFVBQVUsTUFBTSxrQkFBQUQsUUFBVSxrQkFBa0IsSUFBSTtBQUN0RCxVQUFJLENBQUMsU0FBUyxTQUFTLEtBQUssR0FBRyxHQUFHO0FBQ2hDLGVBQU8sYUFBYSxLQUFLLEVBQUUsT0FBTyx1Q0FBdUMsYUFBYSxLQUFLLENBQUM7QUFBQSxNQUM5RjtBQUNBLFlBQU0sT0FBTyxNQUFNLGNBQWMsR0FBRztBQUNwQyxZQUFNLFNBQVMsTUFBTSxrQkFBQUEsUUFBVSxrQkFBa0IsTUFBTSxJQUFJO0FBQzNELGFBQU8sYUFBYSxLQUFLO0FBQUEsUUFDdkIsSUFBSTtBQUFBLFFBQ0osYUFBYSxPQUFPO0FBQUEsUUFDcEIsVUFBVSxPQUFPLFVBQVU7QUFBQSxRQUMzQixXQUFXLE9BQU8sVUFBVTtBQUFBLE1BQzlCLENBQUM7QUFBQSxJQUNIO0FBRUEsUUFBSSxTQUFTLFdBQVcsb0JBQW9CLEtBQUssSUFBSSxXQUFXLFVBQVU7QUFDeEUsWUFBTSxVQUFVLE1BQU0sa0JBQUFBLFFBQVUsa0JBQWtCLElBQUk7QUFDdEQsVUFBSSxDQUFDLFNBQVMsU0FBUyxLQUFLLEdBQUcsR0FBRztBQUNoQyxlQUFPLGFBQWEsS0FBSyxFQUFFLE9BQU8sdUNBQXVDLGFBQWEsS0FBSyxDQUFDO0FBQUEsTUFDOUY7QUFDQSxZQUFNLE9BQU8sbUJBQW1CLFNBQVMsTUFBTSxxQkFBcUIsTUFBTSxDQUFDO0FBQzNFLFlBQU0sU0FBUyxNQUFNLGtCQUFBQSxRQUFVLGtCQUFrQixNQUFNLElBQUk7QUFDM0QsYUFBTyxhQUFhLEtBQUs7QUFBQSxRQUN2QixJQUFJO0FBQUEsUUFDSixTQUFTLE9BQU87QUFBQSxRQUNoQixVQUFVLE9BQU8sVUFBVTtBQUFBLE1BQzdCLENBQUM7QUFBQSxJQUNIO0FBRUEsUUFBSSxhQUFhLGVBQWUsSUFBSSxXQUFXLFFBQVE7QUFDckQsWUFBTSxVQUFVLE1BQU0sa0JBQUFBLFFBQVUsa0JBQWtCLElBQUk7QUFDdEQsVUFBSSxDQUFDLFNBQVMsU0FBUyxLQUFLLEdBQUcsR0FBRztBQUNoQyxlQUFPLGFBQWEsS0FBSyxFQUFFLE9BQU8sdUNBQXVDLGFBQWEsS0FBSyxDQUFDO0FBQUEsTUFDOUY7QUFDQSxZQUFNLE9BQU8sTUFBTSxjQUFjLEdBQUc7QUFDcEMsWUFBTSxLQUFLLE1BQU0sa0JBQUFBLFFBQVUsVUFBVSxNQUFNLElBQUk7QUFDL0MsWUFBTSxRQUFRLElBQUksYUFBYSxJQUFJLE9BQU8sS0FBSztBQUMvQyxZQUFNLE9BQU8sZUFBQUQsUUFBUSxtQkFBbUIsRUFBRTtBQUMxQyxXQUFLLFNBQVMsaUJBQUFFLFFBQVUsYUFBYSxJQUFJLEtBQUs7QUFDOUMsYUFBTyxhQUFhLEtBQUssSUFBSTtBQUFBLElBQy9CO0FBRUEsUUFBSSxhQUFhLG1CQUFtQixJQUFJLFdBQVcsUUFBUTtBQUN6RCxZQUFNLFVBQVUsTUFBTSxrQkFBQUQsUUFBVSxrQkFBa0IsSUFBSTtBQUN0RCxVQUFJLENBQUMsU0FBUyxTQUFTLEtBQUssR0FBRyxHQUFHO0FBQ2hDLGVBQU8sYUFBYSxLQUFLLEVBQUUsT0FBTyx1Q0FBdUMsYUFBYSxLQUFLLENBQUM7QUFBQSxNQUM5RjtBQUNBLFlBQU0sT0FBTyxNQUFNLGNBQWMsR0FBRztBQUNwQyxZQUFNLEtBQUssTUFBTSxrQkFBQUEsUUFBVSxlQUFlLE1BQU0sSUFBSTtBQUNwRCxhQUFPLGFBQWEsS0FBSyxlQUFBRCxRQUFRLG1CQUFtQixFQUFFLENBQUM7QUFBQSxJQUN6RDtBQUVBLFFBQUksYUFBYSxlQUFlLElBQUksV0FBVyxRQUFRO0FBQ3JELFlBQU0sVUFBVSxNQUFNLGtCQUFBQyxRQUFVLGtCQUFrQixJQUFJO0FBQ3RELFVBQUksQ0FBQyxTQUFTLFNBQVMsS0FBSyxHQUFHLEdBQUc7QUFDaEMsZUFBTyxhQUFhLEtBQUssRUFBRSxPQUFPLHVDQUF1QyxhQUFhLEtBQUssQ0FBQztBQUFBLE1BQzlGO0FBQ0EsWUFBTSxLQUFLLE1BQU0sa0JBQUFBLFFBQVUsYUFBYSxJQUFJO0FBQzVDLFlBQU0sT0FBTyxlQUFBRCxRQUFRLG1CQUFtQixFQUFFO0FBQzFDLFdBQUssU0FBUyxpQkFBQUUsUUFBVSxhQUFhLElBQUksRUFBRTtBQUMzQyxhQUFPLGFBQWEsS0FBSyxJQUFJO0FBQUEsSUFDL0I7QUFFQSxXQUFPLGFBQWEsS0FBSyxFQUFFLE9BQU8sMkJBQTJCLENBQUM7QUFBQSxFQUNoRSxTQUFTLEtBQWM7QUFDckIsVUFBTSxVQUFVLGVBQWUsUUFBUSxJQUFJLFVBQVU7QUFDckQsV0FBTyxhQUFhLEtBQUssRUFBRSxPQUFPLFFBQVEsQ0FBQztBQUFBLEVBQzdDO0FBQ0Y7QUFFTyxJQUFNLFNBQWlCO0FBQUEsRUFDNUIsTUFBTTtBQUNSOyIsCiAgIm5hbWVzIjogWyJhbmFseXRpY3MiLCAic3RvcmFnZSIsICJzdG9yYWdlIiwgInBnU3RvcmFnZSIsICJhbmFseXRpY3MiXQp9Cg==
