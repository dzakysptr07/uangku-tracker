'use strict';

const fs = require('fs');
const path = require('path');

const rootDir = path.join(__dirname, '..');
const publicDir = path.join(rootDir, 'public');
const distDir = path.join(rootDir, 'dist');
const analyticsSrc = path.join(rootDir, 'src', 'analytics.js');
const analyticsDest = path.join(distDir, 'analytics.js');

fs.rmSync(distDir, { recursive: true, force: true });
fs.cpSync(publicDir, distDir, { recursive: true });
fs.copyFileSync(analyticsSrc, analyticsDest);

console.log('Netlify static build ready in:', distDir);
